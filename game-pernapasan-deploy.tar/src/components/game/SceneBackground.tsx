"use client";

import React from "react";
import { OrganData } from "@/lib/game-data";

interface SceneBackgroundProps {
  organ: OrganData;
  progress: number;
}

export default function SceneBackground({ organ, progress }: SceneBackgroundProps) {
  return (
    <div
      className="absolute inset-0 overflow-hidden"
      style={{ background: organ.bgColor }}
    >
      {/* Ambient gradient glow behind organ */}
      <div
        className="absolute pointer-events-none"
        style={{
          top: "5%",
          left: "50%",
          transform: "translateX(-50%)",
          width: "90%",
          height: "80%",
          background: `radial-gradient(ellipse at center, ${organ.accentColor}15 0%, transparent 70%)`,
        }}
      />

      {/* Floating particles */}
      <ParticleField organId={organ.id} accentColor={organ.accentColor} />

      {/* Main organ illustration - LARGE and centered */}
      <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
        <OrganIllustration organId={organ.id} accentColor={organ.accentColor} organName={organ.name} organEmoji={organ.iconEmoji} />
      </div>

      {/* Ground / platform where character stands */}
      <div
        className="absolute left-0 right-0 pointer-events-none"
        style={{
          bottom: "18%",
          height: "2px",
          background: `linear-gradient(90deg, transparent 5%, ${organ.accentColor}30 30%, ${organ.accentColor}50 50%, ${organ.accentColor}30 70%, transparent 95%)`,
        }}
      />
      <div
        className="absolute left-0 right-0 pointer-events-none"
        style={{
          bottom: 0,
          height: "18%",
          background: `linear-gradient(180deg, transparent, ${organ.bgColor}dd 40%)`,
        }}
      />

      {/* Path dots at bottom */}
      <PathIndicator organId={organ.id} progress={progress} />
    </div>
  );
}

// ========== Seeded PRNG ==========
function seededRandom(seed: number) {
  let s = seed;
  return () => {
    s |= 0; s = s + 0x6D2B79F5 | 0;
    let t = Math.imul(s ^ s >>> 15, 1 | s);
    t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t;
    return ((t ^ t >>> 14) >>> 0) / 4294967296;
  };
}

const PARTICLES_BY_ORGAN: Record<string, Array<{ id: number; x: number; y: number; size: number; duration: number; delay: number; opacity: number }>> = (() => {
  const organs = ["hidung", "faring", "laring", "trakea", "bronkus", "bronkiolus", "alveolus"];
  const result: Record<string, Array<{ id: number; x: number; y: number; size: number; duration: number; delay: number; opacity: number }>> = {};
  organs.forEach((organ) => {
    const seed = organ.split("").reduce((acc, c) => acc + c.charCodeAt(0), 0);
    const rng = seededRandom(seed);
    result[organ] = Array.from({ length: 20 }, (_, i) => ({
      id: i, x: rng() * 100, y: rng() * 70,
      size: 2 + rng() * 4, duration: 3 + rng() * 5,
      delay: rng() * 5, opacity: 0.15 + rng() * 0.3,
    }));
  });
  return result;
})();

function ParticleField({ organId, accentColor }: { organId: string; accentColor: string }) {
  const particles = PARTICLES_BY_ORGAN[organId] || PARTICLES_BY_ORGAN["hidung"];
  return (
    <div className="absolute inset-0 overflow-hidden pointer-events-none">
      {particles.map((p) => (
        <div
          key={p.id}
          className="absolute rounded-full"
          style={{
            left: `${p.x}%`, top: `${p.y}%`, width: p.size, height: p.size,
            backgroundColor: accentColor, opacity: p.opacity,
            animation: `float ${p.duration}s ease-in-out ${p.delay}s infinite`,
          }}
        />
      ))}
    </div>
  );
}

// ========== LARGE Organ Illustrations ==========
function OrganIllustration({ organId, accentColor, organName, organEmoji }: {
  organId: string; accentColor: string; organName: string; organEmoji: string;
}) {
  return (
    <div className="relative w-full h-full flex items-center justify-center">
      {/* Organ SVG - LARGE */}
      <div className="w-[85%] h-[65%] relative" style={{ marginTop: "-5%" }}>
        <OrganSVG organId={organId} accentColor={accentColor} />
      </div>

      {/* Organ label */}
      <div
        className="absolute pointer-events-none"
        style={{ top: "8%", left: "50%", transform: "translateX(-50%)" }}
      >
        <div
          className="flex items-center gap-2 px-4 py-2 rounded-full"
          style={{
            background: `${accentColor}18`,
            border: `1px solid ${accentColor}40`,
            boxShadow: `0 0 20px ${accentColor}15`,
          }}
        >
          <span className="text-xl">{organEmoji}</span>
          <span className="text-white text-sm font-bold" style={{ fontFamily: "monospace" }}>
            {organName}
          </span>
        </div>
      </div>
    </div>
  );
}

function OrganSVG({ organId, accentColor }: { organId: string; accentColor: string }) {
  // Color helpers
  const fill = `${accentColor}25`;
  const stroke = `${accentColor}`;
  const strokeLight = `${accentColor}80`;
  const glow = `${accentColor}40`;

  return (
    <svg viewBox="0 0 400 400" className="w-full h-full" preserveAspectRatio="xMidYMid meet">
      <defs>
        <filter id={`glow-${organId}`}>
          <feGaussianBlur stdDeviation="4" result="blur" />
          <feMerge><feMergeNode in="blur" /><feMergeNode in="SourceGraphic" /></feMerge>
        </filter>
        <radialGradient id={`organGrad-${organId}`}>
          <stop offset="0%" stopColor={`${accentColor}35`} />
          <stop offset="100%" stopColor={`${accentColor}08`} />
        </radialGradient>
      </defs>

      {organId === "hidung" && (
        <g filter={`url(#glow-${organId})`}>
          {/* Face outline - nose area */}
          <path d="M130 30 Q140 10 170 8 Q200 5 230 8 Q260 10 270 30 Q280 60 275 90 Q270 120 260 140 Q250 155 230 165 L230 175 Q225 200 200 210 Q175 200 170 175 L170 165 Q150 155 140 140 Q130 120 125 90 Q120 60 130 30Z"
            fill={`url(#organGrad-${organId})`} stroke={stroke} strokeWidth="2.5" />
          {/* Nostrils */}
          <ellipse cx="175" cy="185" rx="18" ry="25" fill={`${accentColor}20`} stroke={strokeLight} strokeWidth="1.5" />
          <ellipse cx="225" cy="185" rx="18" ry="25" fill={`${accentColor}20`} stroke={strokeLight} strokeWidth="1.5" />
          {/* Nasal cavity inside */}
          <path d="M175 160 L175 120 Q175 90 190 70" fill="none" stroke={strokeLight} strokeWidth="1" strokeDasharray="3 3" />
          <path d="M225 160 L225 120 Q225 90 210 70" fill="none" stroke={strokeLight} strokeWidth="1" strokeDasharray="3 3" />
          {/* Nasal turbinates (conchae) */}
          <path d="M160 100 Q200 85 240 100" fill="none" stroke={stroke} strokeWidth="2" />
          <path d="M155 130 Q200 115 245 130" fill="none" stroke={stroke} strokeWidth="2" />
          <path d="M158 160 Q200 145 242 160" fill="none" stroke={stroke} strokeWidth="1.5" />
          {/* Cilia lines */}
          {[0,1,2,3,4,5].map(i => (
            <line key={i} x1={162 + i * 15} y1={168 + (i%2)*8} x2={162 + i * 15} y2={178 + (i%2)*8}
              stroke={glow} strokeWidth="1.5" />
          ))}
          {/* Label arrows */}
          <text x="85" y="105" fill={stroke} fontSize="9" fontFamily="monospace">↑ Konka</text>
          <text x="85" y="168" fill={strokeLight} fontSize="8" fontFamily="monospace">↑ Silia</text>
        </g>
      )}

      {organId === "faring" && (
        <g filter={`url(#glow-${organId})`}>
          {/* Pharynx tube - vertical */}
          <rect x="160" y="30" width="80" height="300" rx="40" fill={`url(#organGrad-${organId})`} stroke={stroke} strokeWidth="2.5" />
          {/* Inner wall lines */}
          <rect x="175" y="50" width="50" height="260" rx="25" fill="none" stroke={strokeLight} strokeWidth="1" />
          {/* Nasopharynx section */}
          <rect x="140" y="20" width="120" height="60" rx="15" fill={`${accentColor}12`} stroke={strokeLight} strokeWidth="1" strokeDasharray="4 2" />
          <text x="148" y="55" fill={strokeLight} fontSize="8" fontFamily="monospace">Nasofaring</text>
          {/* Oropharynx section */}
          <rect x="140" y="100" width="120" height="70" rx="15" fill={`${accentColor}12`} stroke={strokeLight} strokeWidth="1" strokeDasharray="4 2" />
          <text x="148" y="140" fill={strokeLight} fontSize="8" fontFamily="monospace">Orofaring</text>
          {/* Laryngopharynx section */}
          <rect x="140" y="190" width="120" height="70" rx="15" fill={`${accentColor}12`} stroke={strokeLight} strokeWidth="1" strokeDasharray="4 2" />
          <text x="142" y="230" fill={strokeLight} fontSize="8" fontFamily="monospace">Laringofaring</text>
          {/* Epiglotis */}
          <path d="M165 155 Q200 120 235 155" fill={`${accentColor}30`} stroke={stroke} strokeWidth="2" />
          <text x="205" y="132" fill={stroke} fontSize="8" fontFamily="monospace">Epiglotis →</text>
          {/* Tonsils */}
          <circle cx="155" cy="130" r="12" fill={`${accentColor}18`} stroke={strokeLight} strokeWidth="1" />
          <circle cx="245" cy="130" r="12" fill={`${accentColor}18`} stroke={strokeLight} strokeWidth="1" />
          <text x="115" y="147" fill={strokeLight} fontSize="7" fontFamily="monospace">Amandel</text>
          {/* Arrows showing air flow */}
          <path d="M200 10 L200 30" stroke={glow} strokeWidth="1.5" markerEnd="url(#arrowhead)" />
          <text x="208" y="15" fill={strokeLight} fontSize="7" fontFamily="monospace">Udara ↓</text>
        </g>
      )}

      {organId === "laring" && (
        <g filter={`url(#glow-${organId})`}>
          {/* Thyroid cartilage (Adam's apple) */}
          <path d="M155 60 Q145 120 155 180 Q170 220 200 230 Q230 220 245 180 Q255 120 245 60 Q230 30 200 25 Q170 30 155 60Z"
            fill={`url(#organGrad-${organId})`} stroke={stroke} strokeWidth="2.5" />
          {/* Inner structure */}
          <path d="M170 70 Q165 120 175 170 Q185 200 200 205 Q215 200 225 170 Q235 120 230 70"
            fill="none" stroke={strokeLight} strokeWidth="1" />
          {/* Vocal cords */}
          <path d="M175 150 Q185 145 200 148 Q215 145 225 150" fill={`${accentColor}30`} stroke={stroke} strokeWidth="2.5" />
          <path d="M175 170 Q185 175 200 172 Q215 175 225 170" fill={`${accentColor}30`} stroke={stroke} strokeWidth="2.5" />
          {/* Glottis label */}
          <text x="130" y="165" fill={strokeLight} fontSize="8" fontFamily="monospace">→ Pita Suara</text>
          {/* True vocal cords label */}
          <text x="130" y="185" fill={glow} fontSize="7" fontFamily="monospace">→ Glottis</text>
          {/* Cricoid cartilage below */}
          <rect x="165" y="230" width="70" height="25" rx="12" fill={`${accentColor}15`} stroke={strokeLight} strokeWidth="1.5" />
          <text x="170" y="246" fill={strokeLight} fontSize="7" fontFamily="monospace">Krikoid</text>
          {/* Arytenoid cartilages */}
          <circle cx="185" cy="145" r="6" fill={`${accentColor}35`} stroke={stroke} strokeWidth="1" />
          <circle cx="215" cy="145" r="6" fill={`${accentColor}35`} stroke={stroke} strokeWidth="1" />
          {/* Sound waves */}
          <path d="M260 155 Q275 160 260 165" fill="none" stroke={glow} strokeWidth="1" />
          <path d="M270 150 Q290 160 270 170" fill="none" stroke={glow} strokeWidth="1" />
          <path d="M280 145 Q305 160 280 175" fill="none" stroke={glow} strokeWidth="1" />
          <text x="275" y="140" fill={strokeLight} fontSize="7" fontFamily="monospace">Suara →</text>
        </g>
      )}

      {organId === "trakea" && (
        <g filter={`url(#glow-${organId})`}>
          {/* Trachea tube body */}
          <rect x="165" y="20" width="70" height="320" rx="10" fill={`url(#organGrad-${organId})`} stroke={stroke} strokeWidth="2" />
          {/* C-shaped cartilage rings */}
          {[0,1,2,3,4,5,6,7,8].map(i => (
            <g key={i}>
              <path d={`M170 ${40 + i * 34} L170 ${64 + i * 34}`} stroke={stroke} strokeWidth="5" fill="none" strokeLinecap="round" />
              <path d={`M170 ${40 + i * 34} A30 12 0 0 1 230 ${40 + i * 34}`} stroke={stroke} strokeWidth="5" fill="none" />
              <path d={`M170 ${64 + i * 34} A30 12 0 0 1 230 ${64 + i * 34}`} stroke={stroke} strokeWidth="5" fill="none" />
              {/* Posterior membrane (dashed) */}
              <line x1="230" y1={40 + i * 34} x2="230" y2={64 + i * 34} stroke={strokeLight} strokeWidth="2" strokeDasharray="3 3" />
            </g>
          ))}
          {/* Label */}
          <text x="85" y={110} fill={strokeLight} fontSize="8" fontFamily="monospace">← Tulang Rawan</text>
          <text x="85" y={122} fill={strokeLight} fontSize="8" fontFamily="monospace">   (bentuk C)</text>
          <text x="238" y={110} fill={glow} fontSize="8" fontFamily="monospace">Membran →</text>
          <text x="238" y={122} fill={glow} fontSize="8" fontFamily="monospace">Belakang</text>
          {/* Mucus layer indication */}
          <rect x="178" y="35" width="4" height="290" rx="2" fill={`${accentColor}20`} />
          <rect x="218" y="35" width="4" height="290" rx="2" fill={`${accentColor}20`} />
          {/* Cilia */}
          {[0,1,2,3,4,5,6].map(i => (
            <line key={i} x1={182} y1={55 + i * 40} x2={175} y2={50 + i * 40} stroke={glow} strokeWidth="1" />
          ))}
        </g>
      )}

      {organId === "bronkus" && (
        <g filter={`url(#glow-${organId})`}>
          {/* Trachea top */}
          <rect x="170" y="10" width="60" height="100" rx="10" fill={`url(#organGrad-${organId})`} stroke={stroke} strokeWidth="2" />
          {/* Trachea rings */}
          {[0,1,2].map(i => (
            <path key={i} d={`M175 ${25 + i * 25} A25 10 0 0 1 225 ${25 + i * 25}`} fill="none" stroke={strokeLight} strokeWidth="3" />
          ))}
          {/* Carina (bifurcation point) */}
          <path d="M170 105 L200 120 L230 105" fill={`${accentColor}35`} stroke={stroke} strokeWidth="2" />
          <text x="195" y="135" fill={stroke} fontSize="9" fontFamily="monospace" textAnchor="middle">Karina</text>
          {/* Right bronchus (shorter, wider) */}
          <path d="M200 120 Q205 170 260 230 Q290 280 310 340" stroke={stroke} strokeWidth="28" fill="none" strokeLinecap="round" opacity="0.25" />
          <path d="M200 120 Q205 170 260 230 Q290 280 310 340" stroke={stroke} strokeWidth="3" fill="none" strokeLinecap="round" />
          {/* Right bronchus rings */}
          {[0,1,2,3].map(i => {
            const t = 0.15 + i * 0.2;
            const cx = 200 + t * 110;
            const cy = 120 + t * 220;
            return <circle key={i} cx={cx} cy={cy} r={16 - i} fill="none" stroke={strokeLight} strokeWidth="1.5" />;
          })}
          {/* Left bronchus (longer, narrower) */}
          <path d="M200 120 Q195 170 140 240 Q110 290 80 340" stroke={stroke} strokeWidth="22" fill="none" strokeLinecap="round" opacity="0.25" />
          <path d="M200 120 Q195 170 140 240 Q110 290 80 340" stroke={stroke} strokeWidth="3" fill="none" strokeLinecap="round" />
          {/* Left bronchus rings */}
          {[0,1,2,3].map(i => {
            const t = 0.15 + i * 0.2;
            const cx = 200 - t * 120;
            const cy = 120 + t * 220;
            return <circle key={i} cx={cx} cy={cy} r={14 - i} fill="none" stroke={strokeLight} strokeWidth="1.5" />;
          })}
          {/* Labels */}
          <text x="320" y="290" fill={strokeLight} fontSize="8" fontFamily="monospace">Bronkus →</text>
          <text x="320" y="302" fill={glow} fontSize="7" fontFamily="monospace">Kanan</text>
          <text x="18" y="290" fill={strokeLight} fontSize="8" fontFamily="monospace">← Bronkus</text>
          <text x="18" y="302" fill={glow} fontSize="7" fontFamily="monospace">  Kiri</text>
        </g>
      )}

      {organId === "bronkiolus" && (
        <g filter={`url(#glow-${organId})`}>
          {/* Main bronchiole trunk */}
          <rect x="190" y="10" width="20" height="60" rx="10" fill={`${accentColor}30`} stroke={stroke} strokeWidth="2" />
          {/* First branching */}
          <path d="M200 70 Q200 80 200 100" stroke={stroke} strokeWidth="10" fill="none" />
          <path d="M200 100 Q180 130 130 180" stroke={stroke} strokeWidth="7" fill="none" strokeLinecap="round" opacity="0.3" />
          <path d="M200 100 Q180 130 130 180" stroke={stroke} strokeWidth="2" fill="none" strokeLinecap="round" />
          <path d="M200 100 Q220 130 270 180" stroke={stroke} strokeWidth="7" fill="none" strokeLinecap="round" opacity="0.3" />
          <path d="M200 100 Q220 130 270 180" stroke={stroke} strokeWidth="2" fill="none" strokeLinecap="round" />
          {/* Second branching */}
          <path d="M130 180 Q110 220 80 280" stroke={stroke} strokeWidth="5" fill="none" opacity="0.25" />
          <path d="M130 180 Q110 220 80 280" stroke={stroke} strokeWidth="1.5" fill="none" />
          <path d="M130 180 Q140 230 120 300" stroke={stroke} strokeWidth="5" fill="none" opacity="0.25" />
          <path d="M130 180 Q140 230 120 300" stroke={stroke} strokeWidth="1.5" fill="none" />
          <path d="M270 180 Q290 220 310 280" stroke={stroke} strokeWidth="5" fill="none" opacity="0.25" />
          <path d="M270 180 Q290 220 310 280" stroke={stroke} strokeWidth="1.5" fill="none" />
          <path d="M270 180 Q260 230 280 300" stroke={stroke} strokeWidth="5" fill="none" opacity="0.25" />
          <path d="M270 180 Q260 230 280 300" stroke={stroke} strokeWidth="1.5" fill="none" />
          {/* Terminal bronchioles */}
          <path d="M80 280 Q65 320 55 360" stroke={stroke} strokeWidth="3" fill="none" opacity="0.2" />
          <path d="M80 280 Q95 320 90 360" stroke={stroke} strokeWidth="3" fill="none" opacity="0.2" />
          <path d="M120 300 Q105 340 95 370" stroke={stroke} strokeWidth="3" fill="none" opacity="0.2" />
          <path d="M310 280 Q325 320 335 360" stroke={stroke} strokeWidth="3" fill="none" opacity="0.2" />
          <path d="M310 280 Q295 320 300 360" stroke={stroke} strokeWidth="3" fill="none" opacity="0.2" />
          <path d="M280 300 Q295 340 305 370" stroke={stroke} strokeWidth="3" fill="none" opacity="0.2" />
          {/* Smooth muscle indicator */}
          <path d="M115 190 Q130 185 145 190" fill="none" stroke={glow} strokeWidth="1.5" strokeDasharray="2 2" />
          <text x="60" y="400" fill={strokeLight} fontSize="7" fontFamily="monospace">→ Bronkiolus Terminal</text>
          {/* Label */}
          <text x="155" y="140" fill={stroke} fontSize="9" fontFamily="monospace">← Percabangan</text>
        </g>
      )}

      {organId === "alveolus" && (
        <g filter={`url(#glow-${organId})`}>
          {/* Connecting bronchiole */}
          <rect x="192" y="5" width="16" height="50" rx="8" fill={`${accentColor}25`} stroke={stroke} strokeWidth="1.5" />
          {/* Alveolar duct */}
          <path d="M200 55 L200 90" stroke={stroke} strokeWidth="6" fill="none" />
          {/* Main cluster */}
          {[
            { cx: 160, cy: 110, r: 38 }, { cx: 240, cy: 110, r: 38 },
            { cx: 200, cy: 140, r: 35 },
            { cx: 120, cy: 160, r: 32 }, { cx: 280, cy: 160, r: 32 },
            { cx: 160, cy: 200, r: 30 }, { cx: 240, cy: 200, r: 30 },
            { cx: 200, cy: 230, r: 28 },
            { cx: 130, cy: 250, r: 26 }, { cx: 270, cy: 250, r: 26 },
            { cx: 170, cy: 290, r: 24 }, { cx: 230, cy: 290, r: 24 },
            { cx: 200, cy: 330, r: 22 },
            { cx: 140, cy: 330, r: 20 }, { cx: 260, cy: 330, r: 20 },
          ].map((c, i) => (
            <g key={i}>
              {/* Glow */}
              <circle cx={c.cx} cy={c.cy} r={c.r + 4} fill={`${accentColor}08`} />
              {/* Sac */}
              <circle cx={c.cx} cy={c.cy} r={c.r} fill={`${accentColor}10`} stroke={stroke} strokeWidth="1.8" />
              {/* Inner detail - capillary net */}
              <circle cx={c.cx} cy={c.cy} r={c.r * 0.6} fill="none" stroke={glow} strokeWidth="0.5" strokeDasharray="2 2" />
            </g>
          ))}
          {/* Capillary network illustration */}
          <path d="M160 110 Q180 100 200 110 Q220 120 240 110" fill="none" stroke="#ef444480" strokeWidth="1" />
          <path d="M120 160 Q160 140 200 160 Q240 180 280 160" fill="none" stroke="#ef444480" strokeWidth="1" />
          <path d="M160 200 Q180 190 200 200 Q220 210 240 200" fill="none" stroke="#ef444480" strokeWidth="1" />
          {/* Labels */}
          <text x="55" y="115" fill={strokeLight} fontSize="8" fontFamily="monospace">← Kantong</text>
          <text x="55" y="127" fill={strokeLight} fontSize="8" fontFamily="monospace">   Udara</text>
          <text x="55" y="195" fill="#ef444480" fontSize="7" fontFamily="monospace">← Kapiler</text>
          <text x="55" y="207" fill="#ef444480" fontSize="7" fontFamily="monospace">   Darah</text>
          {/* O2 / CO2 arrows */}
          <text x="200" y="375" fill="#4ade80" fontSize="9" fontFamily="monospace" textAnchor="middle">O₂ ↔ CO₂</text>
          <text x="200" y="390" fill={strokeLight} fontSize="7" fontFamily="monospace" textAnchor="middle">Pertukaran Gas</text>
        </g>
      )}
    </svg>
  );
}

// ========== Path Dots ==========
function PathIndicator({ organId }: { organId: string; progress: number }) {
  const allOrgans = ["hidung", "faring", "laring", "trakea", "bronkus", "bronkiolus", "alveolus"];
  const currentIdx = allOrgans.indexOf(organId);

  return (
    <div className="absolute bottom-3 left-1/2 -translate-x-1/2 flex items-center gap-1 z-20">
      {allOrgans.map((id, i) => (
        <div
          key={id}
          className="w-2.5 h-2.5 rounded-full transition-all duration-300"
          style={{
            backgroundColor: i <= currentIdx ? accentColorForOrgan(id) : "transparent",
            border: `2px solid ${accentColorForOrgan(id)}`,
            transform: i === currentIdx ? "scale(1.5)" : "scale(1)",
            boxShadow: i === currentIdx ? `0 0 8px ${accentColorForOrgan(id)}` : "none",
          }}
        />
      ))}
    </div>
  );
}

function accentColorForOrgan(id: string): string {
  return {
    hidung: "#e94560", faring: "#53d8fb", laring: "#e94560",
    trakea: "#53d8fb", bronkus: "#e94560", bronkiolus: "#53d8fb", alveolus: "#FF6B6B",
  }[id] || "#53d8fb";
}
