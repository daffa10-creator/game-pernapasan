"use client";

import React, { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";

interface MiniMapProps {
  currentOrganIdx: number;
  completedOrgans: string[];
}

const ORGANS = [
  { id: "hidung", name: "Rongga Hidung", shortName: "Hidung" },
  { id: "faring", name: "Faring", shortName: "Faring" },
  { id: "laring", name: "Laring", shortName: "Laring" },
  { id: "trakea", name: "Trakea", shortName: "Trakea" },
  { id: "bronkus", name: "Bronkus", shortName: "Bronkus" },
  { id: "bronkiolus", name: "Bronkiolus", shortName: "Bronkiolus" },
  { id: "alveolus", name: "Alveolus", shortName: "Alveolus" },
];

// Node positions for each organ on the anatomical map (center x, y for label placement)
const ORGAN_NODES: Record<string, { cx: number; cy: number; labelX: number; labelY: number }> = {
  hidung:     { cx: 150, cy: 52,  labelX: 210, labelY: 48 },
  faring:     { cx: 150, cy: 100, labelX: 210, labelY: 96 },
  laring:     { cx: 150, cy: 148, labelX: 210, labelY: 144 },
  trakea:     { cx: 150, cy: 210, labelX: 210, labelY: 206 },
  bronkus:    { cx: 150, cy: 280, labelX: 210, labelY: 276 },
  bronkiolus: { cx: 85,  cy: 370, labelX: 0,   labelY: 366 },
  alveolus:   { cx: 85,  cy: 440, labelX: 0,   labelY: 436 },
};

function getOrganState(id: string, currentId: string, completedOrgans: string[]) {
  if (id === currentId) return "current" as const;
  if (completedOrgans.includes(id)) return "completed" as const;
  return "upcoming" as const;
}

function organColor(id: string, currentId: string, completedOrgans: string[]) {
  const state = getOrganState(id, currentId, completedOrgans);
  switch (state) {
    case "current": return { fill: "rgba(83,216,251,0.18)", stroke: "#53d8fb", glow: "rgba(83,216,251,0.5)", text: "#53d8fb" };
    case "completed": return { fill: "rgba(74,222,128,0.12)", stroke: "#4ade80", glow: "rgba(74,222,128,0.4)", text: "#4ade80" };
    case "upcoming": return { fill: "rgba(180,140,120,0.06)", stroke: "rgba(180,140,120,0.2)", glow: "transparent", text: "rgba(180,140,120,0.5)" };
  }
}

// ===== ANATOMICAL SVG MAP =====
function AnatomicalMapSVG({ currentId, completedOrgans, isExpanded }: {
  currentId: string;
  completedOrgans: string[];
  isExpanded: boolean;
}) {
  const isDone = (id: string) => completedOrgans.includes(id);
  const oc = (id: string) => organColor(id, currentId, completedOrgans);

  // Organ states for coloring
  const nose = oc("hidung");
  const pharynx = oc("faring");
  const larynx = oc("laring");
  const trachea = oc("trakea");
  const bronchi = oc("bronkus");
  const bronchiole = oc("bronkiolus");
  const alveoli = oc("alveolus");

  const labelSize = isExpanded ? 9 : 6.5;
  const labelFont = isExpanded ? "10" : "7";

  return (
    <svg viewBox="0 0 300 520" className="w-full" style={{ display: "block" }}>
      <defs>
        {/* Glow filter */}
        <filter id="amglow">
          <feGaussianBlur stdDeviation="4" result="blur" />
          <feMerge><feMergeNode in="blur" /><feMergeNode in="SourceGraphic" /></feMerge>
        </filter>
        <filter id="amglowSoft">
          <feGaussianBlur stdDeviation="6" result="blur" />
          <feMerge><feMergeNode in="blur" /><feMergeNode in="SourceGraphic" /></feMerge>
        </filter>

        {/* Lung gradients */}
        <radialGradient id="lungGradL" cx="0.4" cy="0.5">
          <stop offset="0%" stopColor="#e94560" stopOpacity="0.18" />
          <stop offset="60%" stopColor="#e94560" stopOpacity="0.08" />
          <stop offset="100%" stopColor="#e94560" stopOpacity="0.02" />
        </radialGradient>
        <radialGradient id="lungGradR" cx="0.6" cy="0.5">
          <stop offset="0%" stopColor="#e94560" stopOpacity="0.2" />
          <stop offset="60%" stopColor="#e94560" stopOpacity="0.1" />
          <stop offset="100%" stopColor="#e94560" stopOpacity="0.03" />
        </radialGradient>

        {/* Nose gradient */}
        <linearGradient id="noseGrad" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor="#f0c8a0" stopOpacity="0.3" />
          <stop offset="100%" stopColor="#d4a07a" stopOpacity="0.15" />
        </linearGradient>

        {/* Trachea gradient */}
        <linearGradient id="tracheaGrad" x1="0" y1="0" x2="1" y2="0">
          <stop offset="0%" stopColor="#f0a8a0" stopOpacity="0.2" />
          <stop offset="50%" stopColor="#f0c8b8" stopOpacity="0.15" />
          <stop offset="100%" stopColor="#f0a8a0" stopOpacity="0.2" />
        </linearGradient>

        {/* Diaphragm gradient */}
        <linearGradient id="diaGrad" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor="#c07060" stopOpacity="0.2" />
          <stop offset="100%" stopColor="#a05040" stopOpacity="0.1" />
        </linearGradient>
      </defs>

      {/* ===== BODY SILHOUETTE ===== */}
      <path
        d="M150 8 Q120 6 100 15 Q80 26 72 50 Q62 80 55 110 Q48 140 46 175
           Q44 210 48 245 Q54 280 65 310 Q80 340 100 362 Q120 378 150 382
           Q180 378 200 362 Q220 340 235 310 Q246 280 252 245 Q256 210 254 175
           Q252 140 245 110 Q238 80 228 50 Q220 26 200 15 Q180 6 150 8Z"
        fill="rgba(255,210,180,0.03)"
        stroke="rgba(255,210,180,0.08)"
        strokeWidth="1.2"
      />

      {/* ===== NASAL CAVITY (HIDUNG) ===== */}
      {/* Head/skull outline */}
      <ellipse cx="150" cy="28" rx="42" ry="26"
        fill="rgba(255,220,195,0.04)" stroke="rgba(255,210,180,0.12)" strokeWidth="0.8" />
      {/* Nose bridge */}
      <path d="M142 14 Q150 10 158 14 L162 24 Q162 32 156 38 Q150 42 144 38 Q138 32 138 24 Z"
        fill={nose.fill} stroke={nose.stroke} strokeWidth={currentId === "hidung" ? 1.5 : 0.8}
        filter={currentId === "hidung" ? "url(#amglow)" : undefined} />
      {/* Nostrils */}
      <ellipse cx="144" cy="38" rx="4" ry="5" fill="none" stroke="rgba(200,150,120,0.2)" strokeWidth="0.6" />
      <ellipse cx="156" cy="38" rx="4" ry="5" fill="none" stroke="rgba(200,150,120,0.2)" strokeWidth="0.6" />
      {/* Turbinates inside nasal cavity */}
      <path d="M140 24 Q150 21 160 24" fill="none" stroke="rgba(220,160,130,0.15)" strokeWidth="0.5" />
      <path d="M139 30 Q150 27 161 30" fill="none" stroke="rgba(220,160,130,0.12)" strokeWidth="0.5" />
      {/* Nasal septum */}
      <line x1="150" y1="16" x2="150" y2="40" stroke="rgba(200,150,120,0.1)" strokeWidth="0.4" />

      {/* ===== PHARYNX (FARING) ===== */}
      {/* Throat tube */}
      <path d="M140 46 Q140 44 150 43 Q160 44 160 46 L162 62 Q162 78 158 88
               Q154 94 150 96 Q146 94 142 88 Q138 78 138 62 Z"
        fill={pharynx.fill} stroke={pharynx.stroke} strokeWidth={currentId === "faring" ? 1.5 : 0.8}
        filter={currentId === "faring" ? "url(#amglow)" : undefined} />
      {/* Epiglottis flap */}
      <path d="M140 68 Q150 62 160 68" fill="none" stroke="rgba(220,160,130,0.2)" strokeWidth="0.8" />

      {/* ===== LARYNX (LARING) ===== */}
      {/* Thyroid cartilage (Adam's apple shape) */}
      <path d="M138 100 Q134 112 138 126 Q142 138 150 142 Q158 138 162 126 Q166 112 162 100 Z"
        fill={larynx.fill} stroke={larynx.stroke} strokeWidth={currentId === "laring" ? 1.5 : 0.8}
        filter={currentId === "laring" ? "url(#amglow)" : undefined} />
      {/* Vocal cords */}
      <line x1="142" y1="122" x2="142" y2="132" stroke="rgba(255,200,200,0.2)" strokeWidth="0.8" />
      <line x1="158" y1="122" x2="158" y2="132" stroke="rgba(255,200,200,0.2)" strokeWidth="0.8" />
      {/* Cricoid cartilage ring */}
      <ellipse cx="150" cy="142" rx="12" ry="3" fill="none" stroke="rgba(200,150,130,0.15)" strokeWidth="0.6" />

      {/* ===== TRACHEA ===== */}
      <rect x="139" y="148" width="22" height="80" rx="5"
        fill={trachea.fill} stroke={trachea.stroke} strokeWidth={currentId === "trakea" ? 1.5 : 0.8}
        filter={currentId === "trakea" ? "url(#amglow)" : undefined} />
      {/* Cartilage rings */}
      {Array.from({ length: 10 }).map((_, i) => (
        <line key={i} x1="139" y1={153 + i * 7.5} x2="161" y2={153 + i * 7.5}
          stroke="rgba(255,220,210,0.1)" strokeWidth="0.5" />
      ))}
      {/* Posterior trachea (membranous wall) */}
      <line x1="139" y1="148" x2="139" y2="228" stroke="rgba(200,150,140,0.08)" strokeWidth="1.5" />

      {/* ===== BRONCHI (Y-BRANCH) ===== */}
      {/* Main left bronchus */}
      <path d="M150 228 Q150 248 100 280 Q90 286 82 290"
        fill="none" stroke={bronchi.stroke} strokeWidth={currentId === "bronkus" ? 5 : 3}
        strokeLinecap="round" opacity={0.25}
        filter={currentId === "bronkus" ? "url(#amglow)" : undefined} />
      <path d="M150 228 Q150 248 100 280 Q90 286 82 290"
        fill="none" stroke={bronchi.stroke} strokeWidth={currentId === "bronkus" ? 1.8 : 1}
        strokeLinecap="round" />
      {/* Main right bronchus */}
      <path d="M150 228 Q150 248 200 280 Q210 286 218 290"
        fill="none" stroke={bronchi.stroke} strokeWidth={currentId === "bronkus" ? 6 : 3.5}
        strokeLinecap="round" opacity={0.25}
        filter={currentId === "bronkus" ? "url(#amglow)" : undefined} />
      <path d="M150 228 Q150 248 200 280 Q210 286 218 290"
        fill="none" stroke={bronchi.stroke} strokeWidth={currentId === "bronkus" ? 1.8 : 1}
        strokeLinecap="round" />
      {/* Cartilage rings on bronchi */}
      {[0, 1, 2].map(i => (
        <React.Fragment key={`br${i}`}>
          <line x1={142 - i * 4} y1={235 + i * 10} x2={144 - i * 4} y2={236 + i * 10}
            stroke="rgba(255,220,210,0.08)" strokeWidth="0.4" />
          <line x1={158 + i * 4} y1={235 + i * 10} x2={156 + i * 4} y2={236 + i * 10}
            stroke="rgba(255,220,210,0.08)" strokeWidth="0.4" />
        </React.Fragment>
      ))}

      {/* ===== LUNGS ===== */}
      {/* Right lung (larger) */}
      <path d="M162 235 Q190 240 218 265 Q238 290 242 325 Q244 355 230 375
               Q215 392 190 398 Q168 400 158 385 Q152 365 155 335 Q156 300 158 270 Z"
        fill="url(#lungGradR)"
        stroke={currentId === "bronkiolus" || currentId === "alveolus" ? "rgba(233,69,96,0.35)" : "rgba(233,69,96,0.12)"}
        strokeWidth="1"
      />
      {/* Left lung (slightly smaller) */}
      <path d="M138 235 Q110 240 82 265 Q62 290 58 325 Q56 355 70 375
               Q85 392 110 398 Q132 400 142 385 Q148 365 145 335 Q144 300 142 270 Z"
        fill="url(#lungGradL)"
        stroke={currentId === "bronkiolus" || currentId === "alveolus" ? "rgba(233,69,96,0.35)" : "rgba(233,69,96,0.12)"}
        strokeWidth="1"
      />
      {/* Lung lobes - right */}
      <path d="M160 310 Q180 308 215 325" fill="none" stroke="rgba(233,69,96,0.08)" strokeWidth="0.5" />
      {/* Lung lobes - left */}
      <path d="M140 310 Q120 308 85 325" fill="none" stroke="rgba(233,69,96,0.08)" strokeWidth="0.5" />

      {/* ===== BRONCHIOLES (tree branching) ===== */}
      {/* Left lung branches */}
      {[
        { d: "M82 290 Q68 310 55 330", w: 1.5 },
        { d: "M82 290 Q75 315 65 340", w: 1.2 },
        { d: "M82 290 Q90 315 82 340", w: 1.2 },
        { d: "M82 290 Q95 310 100 335", w: 1 },
        { d: "M55 330 Q48 345 42 360", w: 0.8 },
        { d: "M55 330 Q58 348 52 368", w: 0.8 },
        { d: "M65 340 Q60 355 55 375", w: 0.7 },
        { d: "M65 340 Q70 358 68 378", w: 0.7 },
        { d: "M82 340 Q78 358 75 380", w: 0.7 },
        { d: "M82 340 Q88 358 90 380", w: 0.7 },
        { d: "M100 335 Q95 355 92 375", w: 0.8 },
        { d: "M100 335 Q108 350 115 370", w: 0.8 },
      ].map((b, i) => (
        <path key={`bl${i}`} d={b.d} fill="none"
          stroke={bronchiole.stroke} strokeWidth={b.w}
          strokeLinecap="round" opacity={currentId === "bronkiolus" ? 0.8 : 0.4}
          filter={currentId === "bronkiolus" ? "url(#amglow)" : undefined} />
      ))}
      {/* Right lung branches */}
      {[
        { d: "M218 290 Q232 310 245 330", w: 1.5 },
        { d: "M218 290 Q225 315 235 340", w: 1.2 },
        { d: "M218 290 Q210 315 218 340", w: 1.2 },
        { d: "M218 290 Q205 310 200 335", w: 1 },
        { d: "M245 330 Q252 345 258 360", w: 0.8 },
        { d: "M245 330 Q242 348 248 368", w: 0.8 },
        { d: "M235 340 Q240 358 238 378", w: 0.7 },
        { d: "M235 340 Q230 358 232 378", w: 0.7 },
        { d: "M218 340 Q222 358 225 380", w: 0.7 },
        { d: "M200 335 Q195 355 192 375", w: 0.8 },
        { d: "M200 335 Q205 350 198 370", w: 0.8 },
      ].map((b, i) => (
        <path key={`br${i}`} d={b.d} fill="none"
          stroke={bronchiole.stroke} strokeWidth={b.w}
          strokeLinecap="round" opacity={currentId === "bronkiolus" ? 0.8 : 0.4}
          filter={currentId === "bronkiolus" ? "url(#amglow)" : undefined} />
      ))}

      {/* ===== ALVEOLI CLUSTERS ===== */}
      {[
        // Left lung alveoli
        { cx: 40, cy: 365, r: 6 }, { cx: 50, cy: 375, r: 5 }, { cx: 58, cy: 385, r: 5.5 },
        { cx: 48, cy: 370, r: 4 }, { cx: 55, cy: 380, r: 4.5 }, { cx: 42, cy: 378, r: 3.5 },
        { cx: 70, cy: 385, r: 5 }, { cx: 65, cy: 380, r: 4 }, { cx: 75, cy: 390, r: 4.5 },
        { cx: 72, cy: 388, r: 3.5 }, { cx: 80, cy: 388, r: 4 }, { cx: 88, cy: 385, r: 5 },
        { cx: 92, cy: 380, r: 4 }, { cx: 95, cy: 390, r: 4.5 }, { cx: 115, cy: 375, r: 5 },
        { cx: 110, cy: 380, r: 4 }, { cx: 120, cy: 385, r: 3.5 },
        // Right lung alveoli
        { cx: 260, cy: 365, r: 6 }, { cx: 250, cy: 375, r: 5 }, { cx: 242, cy: 385, r: 5.5 },
        { cx: 252, cy: 370, r: 4 }, { cx: 245, cy: 380, r: 4.5 }, { cx: 258, cy: 378, r: 3.5 },
        { cx: 230, cy: 385, r: 5 }, { cx: 235, cy: 380, r: 4 }, { cx: 225, cy: 390, r: 4.5 },
        { cx: 228, cy: 388, r: 3.5 }, { cx: 220, cy: 388, r: 4 }, { cx: 212, cy: 385, r: 5 },
        { cx: 208, cy: 380, r: 4 }, { cx: 205, cy: 390, r: 4.5 }, { cx: 185, cy: 375, r: 5 },
        { cx: 190, cy: 380, r: 4 }, { cx: 180, cy: 385, r: 3.5 },
      ].map((a, i) => (
        <circle key={`av${i}`} cx={a.cx} cy={a.cy} r={a.r}
          fill={alveoli.fill} stroke={alveoli.stroke} strokeWidth="0.5"
          filter={currentId === "alveolus" ? "url(#amglow)" : undefined} />
      ))}

      {/* ===== DIAPHRAGM ===== */}
      <path d="M55 400 Q80 420 120 425 Q150 427 180 425 Q220 420 245 400"
        fill="none" stroke="rgba(200,120,100,0.15)" strokeWidth="2"
        strokeDasharray="4 2" />
      <path d="M58 402 Q85 425 120 430 Q150 432 180 430 Q215 425 242 402"
        fill="url(#diaGrad)" stroke="none" opacity="0.3" />

      {/* ===== ORGAN LABELS WITH CONNECTORS ===== */}
      {ORGANS.map((organ) => {
        const state = getOrganState(organ.id, currentId, completedOrgans);
        const node = ORGAN_NODES[organ.id];
        const isCurrent = state === "current";
        const isDone = state === "completed";
        const color = organColor(organ.id, currentId, completedOrgans);

        // For bronkiolus and alveolus, use left side label position
        const labelX = node.labelX === 0 ? 12 : node.labelX;
        const labelAlign = node.labelX === 0 ? "start" : "start";

        return (
          <g key={organ.id}>
            {/* Connector line from organ to label */}
            {(isCurrent || isExpanded) && (
              <line x1={node.cx} y1={node.cy} x2={labelX - 3} y2={node.labelY + 2}
                stroke={color.stroke} strokeWidth="0.5" strokeDasharray="2 1" opacity="0.5" />
            )}

            {/* Current organ pulsing indicator */}
            {isCurrent && (
              <>
                <motion.circle
                  cx={node.cx} cy={node.cy} r="12"
                  fill="none" stroke={color.stroke} strokeWidth="1.5"
                  filter="url(#amglowSoft)"
                  animate={{ r: [12, 18, 12], opacity: [0.4, 0.8, 0.4] }}
                  transition={{ repeat: Infinity, duration: 2, ease: "easeInOut" }}
                />
                <motion.circle
                  cx={node.cx} cy={node.cy} r="6"
                  fill={color.fill} stroke={color.stroke} strokeWidth="1.2"
                  filter="url(#amglow)"
                />
                <motion.g
                  animate={{ y: [-2, 1, -2] }}
                  transition={{ repeat: Infinity, duration: 1.2, ease: "easeInOut" }}
                >
                  <text x={node.cx} y={node.cy - 8} textAnchor="middle" dominantBaseline="central" fontSize="10">
                    🧑
                  </text>
                </motion.g>
              </>
            )}

            {/* Completed checkmark */}
            {isDone && (
              <circle cx={node.cx} cy={node.cy} r="6"
                fill="rgba(74,222,128,0.15)" stroke="#4ade80" strokeWidth="0.8" />
            )}

            {/* Label badge */}
            {(isCurrent || isDone || isExpanded) && (
              <motion.g
                initial={{ opacity: 0, x: -3 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.3 }}
              >
                <rect
                  x={labelX - 3} y={node.labelY - 7}
                  width={isExpanded ? 80 : 58} height={isExpanded ? 16 : 13}
                  rx="3"
                  fill="rgba(5,5,20,0.92)"
                  stroke={color.stroke} strokeWidth="0.5"
                />
                <text
                  x={labelX} y={node.labelY + 2}
                  dominantBaseline="central"
                  fill={color.text}
                  fontSize={labelSize}
                  fontFamily="monospace"
                  fontWeight="bold"
                >
                  {isDone ? "✓ " : isCurrent ? "▶ " : "○ "}
                  {isExpanded ? organ.name : organ.shortName}
                </text>
              </motion.g>
            )}
          </g>
        );
      })}

      {/* Air direction arrows */}
      <text x="168" y="8" fill="rgba(83,216,251,0.3)" fontSize="8" fontFamily="monospace">↓ Udara</text>
      <text x="100" y="460" fill="rgba(255,150,130,0.25)" fontSize="6" fontFamily="monospace">
        {isExpanded ? "O₂ ↔ CO₂" : ""}
      </text>
    </svg>
  );
}

// ===== MAIN COMPONENT =====
export default function MiniMap({ currentOrganIdx, completedOrgans }: MiniMapProps) {
  const [expanded, setExpanded] = useState(false);
  const currentId = ORGANS[currentOrganIdx]?.id || "hidung";

  return (
    <>
      {/* Mini map - small version, top-right corner */}
      <motion.div
        initial={{ opacity: 0, x: 20 }}
        animate={{ opacity: 1, x: 0 }}
        className="absolute z-30 cursor-pointer select-none"
        style={{ top: 54, right: 8 }}
        onClick={() => setExpanded(true)}
      >
        <div
          className="rounded-xl overflow-hidden transition-transform hover:scale-105"
          style={{
            background: "rgba(5, 5, 20, 0.94)",
            border: "1.5px solid rgba(83, 216, 251, 0.25)",
            boxShadow: "0 2px 20px rgba(0,0,0,0.7), inset 0 1px 0 rgba(83,216,251,0.08)",
            backdropFilter: "blur(12px)",
            width: "130px",
          }}
        >
          {/* Header */}
          <div
            className="flex items-center justify-center px-2 py-1"
            style={{
              background: "linear-gradient(90deg, rgba(83,216,251,0.1), rgba(233,69,96,0.06))",
              borderBottom: "1px solid rgba(83,216,251,0.12)",
            }}
          >
            <span className="text-[8px] font-bold" style={{ color: "#53d8fb", fontFamily: "monospace" }}>
              📍 Peta Perjalanan
            </span>
          </div>

          {/* Anatomical map */}
          <div className="px-1 py-1">
            <AnatomicalMapSVG currentId={currentId} completedOrgans={completedOrgans} isExpanded={false} />
          </div>

          {/* Bottom progress + expand hint */}
          <div
            className="flex items-center justify-between px-2.5 py-1"
            style={{ borderTop: "1px solid rgba(83,216,251,0.08)" }}
          >
            <span className="text-[7px]" style={{ color: "#4b5563", fontFamily: "monospace" }}>
              {completedOrgans.length}/{ORGANS.length}
            </span>
            <div className="flex gap-0.5 items-center">
              {ORGANS.map((o, i) => (
                <div
                  key={o.id}
                  className="w-1.5 h-1.5 rounded-full transition-all duration-300"
                  style={{
                    backgroundColor: i < currentOrganIdx ? "#4ade80" : i === currentOrganIdx ? "#53d8fb" : "rgba(255,255,255,0.08)",
                    boxShadow: i === currentOrganIdx ? "0 0 4px #53d8fb" : "none",
                  }}
                />
              ))}
              <span className="text-[6px] ml-1" style={{ color: "rgba(83,216,251,0.4)", fontFamily: "monospace" }}>
                ⤢
              </span>
            </div>
          </div>
        </div>
      </motion.div>

      {/* ===== EXPANDED OVERLAY ===== */}
      <AnimatePresence>
        {expanded && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.2 }}
            className="absolute inset-0 z-50 flex items-center justify-center"
            style={{ background: "rgba(0,0,0,0.75)", backdropFilter: "blur(4px)" }}
            onClick={() => setExpanded(false)}
          >
            <motion.div
              initial={{ scale: 0.6, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.6, opacity: 0 }}
              transition={{ type: "spring", damping: 20, stiffness: 300 }}
              onClick={(e) => e.stopPropagation()}
              className="relative"
              style={{ maxHeight: "90vh" }}
            >
              <div
                className="rounded-2xl overflow-hidden"
                style={{
                  background: "rgba(5, 5, 20, 0.97)",
                  border: "2px solid rgba(83, 216, 251, 0.3)",
                  boxShadow: "0 8px 40px rgba(0,0,0,0.8), 0 0 60px rgba(83,216,251,0.05)",
                  width: "340px",
                }}
              >
                {/* Header */}
                <div
                  className="flex items-center justify-between px-4 py-2"
                  style={{
                    background: "linear-gradient(90deg, rgba(83,216,251,0.12), rgba(233,69,96,0.08))",
                    borderBottom: "1px solid rgba(83,216,251,0.15)",
                  }}
                >
                  <span className="text-xs font-bold" style={{ color: "#53d8fb", fontFamily: "monospace" }}>
                    📍 Peta Sistem Pernapasan
                  </span>
                  <button
                    onClick={() => setExpanded(false)}
                    className="w-6 h-6 rounded-full flex items-center justify-center cursor-pointer transition-colors"
                    style={{ background: "rgba(255,255,255,0.08)" }}
                  >
                    <span className="text-xs" style={{ color: "#999" }}>✕</span>
                  </button>
                </div>

                {/* Expanded map */}
                <div className="px-3 py-2">
                  <AnatomicalMapSVG currentId={currentId} completedOrgans={completedOrgans} isExpanded={true} />
                </div>

                {/* Legend */}
                <div
                  className="px-4 py-2"
                  style={{ borderTop: "1px solid rgba(83,216,251,0.1)" }}
                >
                  <div className="flex items-center gap-4 justify-center">
                    <div className="flex items-center gap-1.5">
                      <div className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: "#53d8fb", boxShadow: "0 0 6px #53d8fb" }} />
                      <span className="text-[9px]" style={{ color: "#888", fontFamily: "monospace" }}>Sekarang</span>
                    </div>
                    <div className="flex items-center gap-1.5">
                      <div className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: "#4ade80" }} />
                      <span className="text-[9px]" style={{ color: "#888", fontFamily: "monospace" }}>Selesai</span>
                    </div>
                    <div className="flex items-center gap-1.5">
                      <div className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: "rgba(180,140,120,0.3)" }} />
                      <span className="text-[9px]" style={{ color: "#888", fontFamily: "monospace" }}>Berikutnya</span>
                    </div>
                  </div>
                </div>

                {/* Progress */}
                <div
                  className="flex items-center justify-between px-4 py-2"
                  style={{ borderTop: "1px solid rgba(83,216,251,0.08)" }}
                >
                  <span className="text-[9px]" style={{ color: "#4b5563", fontFamily: "monospace" }}>
                    Progres: {completedOrgans.length}/{ORGANS.length} organ
                  </span>
                  <div className="flex gap-1">
                    {ORGANS.map((o, i) => (
                      <div
                        key={o.id}
                        className="w-2 h-2 rounded-full transition-all duration-300"
                        style={{
                          backgroundColor: i < currentOrganIdx ? "#4ade80" : i === currentOrganIdx ? "#53d8fb" : "rgba(255,255,255,0.08)",
                          boxShadow: i === currentOrganIdx ? "0 0 6px #53d8fb" : "none",
                        }}
                      />
                    ))}
                  </div>
                </div>
              </div>

              {/* Tap to close hint */}
              <p className="text-center mt-2 text-[10px]" style={{ color: "rgba(255,255,255,0.3)", fontFamily: "monospace" }}>
                Ketuk di luar untuk menutup
              </p>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}
