"use client";

import React, { useState, useCallback, useEffect, useRef } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Question } from "@/lib/game-data";
import {
  getRandomQuestion,
  MIN_CORRECT_TO_PASS,
} from "@/lib/question-bank";

interface QuizOverlayProps {
  organId: string;
  organName: string;
  organEmoji: string;
  onComplete: (result: { correct: number; wrong: number; total: number }) => void;
  onClose: () => void;
}

function initQuestion(organId: string): { question: Question | null; usedIds: string[] } {
  const q = getRandomQuestion(organId, []);
  return { question: q, usedIds: q ? [q.id] : [] };
}

export default function QuizOverlay({
  organId,
  organName,
  organEmoji,
  onComplete,
  onClose,
}: QuizOverlayProps) {
  const [questionData, setQuestionData] = useState(() => initQuestion(organId));
  const [selectedAnswer, setSelectedAnswer] = useState<number | null>(null);
  const [isCorrect, setIsCorrect] = useState<boolean | null>(null);
  const [correctCount, setCorrectCount] = useState(0);
  const [wrongCount, setWrongCount] = useState(0);
  const [totalAttempts, setTotalAttempts] = useState(0);
  const [showExplanation, setShowExplanation] = useState(false);
  const [canSkip, setCanSkip] = useState(false);
  const [wrongFlash, setWrongFlash] = useState(false);

  // Countdown states
  const [questionCountdown, setQuestionCountdown] = useState<number | null>(null);
  const [finishCountdown, setFinishCountdown] = useState<number | null>(null);

  // Timer refs
  const questionTimerRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const finishTimerRef = useRef<ReturnType<typeof setInterval> | null>(null);

  const currentQuestion = questionData.question;
  const usedIds = questionData.usedIds;
  const remaining = Math.max(MIN_CORRECT_TO_PASS - correctCount, 0);

  // Keep onComplete ref up to date
  const onCompleteRef = useRef(onComplete);
  useEffect(() => { onCompleteRef.current = onComplete; });

  // Cleanup timers on unmount
  useEffect(() => {
    return () => {
      if (questionTimerRef.current) clearInterval(questionTimerRef.current);
      if (finishTimerRef.current) clearInterval(finishTimerRef.current);
    };
  }, []);

  // ===== CLEAR HELPERS =====
  const clearQuestionTimer = useCallback(() => {
    if (questionTimerRef.current) {
      clearInterval(questionTimerRef.current);
      questionTimerRef.current = null;
    }
    setQuestionCountdown(null);
  }, []);

  const clearFinishTimer = useCallback(() => {
    if (finishTimerRef.current) {
      clearInterval(finishTimerRef.current);
      finishTimerRef.current = null;
    }
    setFinishCountdown(null);
  }, []);

  // ===== LOAD NEXT QUESTION =====
  const loadNextQuestion = useCallback(() => {
    clearQuestionTimer();
    setQuestionData((prev) => {
      const q = getRandomQuestion(organId, prev.usedIds);
      if (q) {
        return { question: q, usedIds: [...prev.usedIds, q.id] };
      }
      return prev;
    });
    setSelectedAnswer(null);
    setIsCorrect(null);
    setShowExplanation(false);
  }, [organId, clearQuestionTimer]);

  // ===== DO FINISH =====
  const doFinish = useCallback(() => {
    clearFinishTimer();
    clearQuestionTimer();
    onCompleteRef.current({ correct: correctCount, wrong: wrongCount, total: totalAttempts });
  }, [correctCount, wrongCount, totalAttempts, clearFinishTimer, clearQuestionTimer]);

  // ===== WATCH: When per-question countdown hits 0 → load next =====
  const loadNextRef = useRef(loadNextQuestion);
  useEffect(() => { loadNextRef.current = loadNextQuestion; });

  useEffect(() => {
    if (questionCountdown === 0) {
      // Use setTimeout to avoid calling setState during render cycle
      const id = setTimeout(() => loadNextRef.current(), 0);
      return () => clearTimeout(id);
    }
  }, [questionCountdown]);

  // ===== WATCH: When finish countdown hits 0 → do finish =====
  const doFinishRef = useRef(doFinish);
  useEffect(() => { doFinishRef.current = doFinish; });

  useEffect(() => {
    if (finishCountdown === 0) {
      const id = setTimeout(() => doFinishRef.current(), 0);
      return () => clearTimeout(id);
    }
  }, [finishCountdown]);

  // ===== START PER-QUESTION COUNTDOWN (5s → auto next question) =====
  const startQuestionCountdown = useCallback(() => {
    clearQuestionTimer();
    setQuestionCountdown(5);
    questionTimerRef.current = setInterval(() => {
      setQuestionCountdown((prev) => {
        if (prev === null || prev <= 1) {
          // Clear timer here, but don't call loadNext — useEffect handles it
          if (questionTimerRef.current) {
            clearInterval(questionTimerRef.current);
            questionTimerRef.current = null;
          }
          return 0;
        }
        return prev - 1;
      });
    }, 1000);
  }, [clearQuestionTimer]);

  // ===== START FINISH COUNTDOWN (5s → auto advance organ) =====
  const startFinishCountdown = useCallback(() => {
    clearFinishTimer();
    setFinishCountdown(5);
    finishTimerRef.current = setInterval(() => {
      setFinishCountdown((prev) => {
        if (prev === null || prev <= 1) {
          if (finishTimerRef.current) {
            clearInterval(finishTimerRef.current);
            finishTimerRef.current = null;
          }
          return 0;
        }
        return prev - 1;
      });
    }, 1000);
  }, [clearFinishTimer]);

  // ===== HANDLE ANSWER =====
  const handleAnswer = useCallback(
    (answerIdx: number) => {
      if (isCorrect !== null || !currentQuestion) return;

      setSelectedAnswer(answerIdx);
      setTotalAttempts((a) => a + 1);

      if (answerIdx === currentQuestion.correctAnswer) {
        setIsCorrect(true);
        setShowExplanation(true);
        const newCorrect = correctCount + 1;
        setCorrectCount(newCorrect);

        if (newCorrect >= MIN_CORRECT_TO_PASS) {
          // Reached 5 — after delay, show skip + start finish countdown
          setTimeout(() => {
            setCanSkip(true);
            startFinishCountdown();
          }, 1500);
        } else {
          // Not yet 5 — after delay, start per-question countdown
          setTimeout(() => {
            startQuestionCountdown();
          }, 1500);
        }
      } else {
        setIsCorrect(false);
        setWrongCount((w) => w + 1);
        setWrongFlash(true);
        setTimeout(() => {
          setWrongFlash(false);
          loadNextQuestion();
        }, 1500);
      }
    },
    [currentQuestion, isCorrect, correctCount, loadNextQuestion, startQuestionCountdown, startFinishCountdown]
  );

  // ===== BUTTON HANDLERS =====
  const handleNextQuestion = useCallback(() => {
    clearQuestionTimer();
    loadNextQuestion();
  }, [clearQuestionTimer, loadNextQuestion]);

  const handleSkipNow = useCallback(() => {
    clearFinishTimer();
    doFinish();
  }, [clearFinishTimer, doFinish]);

  if (!currentQuestion) return null;

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="absolute inset-0 z-50 flex items-center justify-center p-4"
        style={{ backgroundColor: "rgba(0,0,0,0.75)" }}
      >
        <motion.div
          initial={{ scale: 0.8, y: 30 }}
          animate={{ scale: 1, y: 0 }}
          exit={{ scale: 0.8, y: 30 }}
          transition={{ type: "spring", damping: 20 }}
          className="w-full max-w-lg rounded-2xl overflow-hidden"
          style={{
            background: "linear-gradient(135deg, #1a1a2e 0%, #16213e 50%, #0f3460 100%)",
            border: "3px solid #53d8fb",
            boxShadow: "0 0 30px rgba(83, 216, 251, 0.3)",
          }}
        >
          {/* Header */}
          <div
            className="px-4 py-3 flex items-center justify-between"
            style={{
              background: "linear-gradient(90deg, #0f3460, #16213e)",
              borderBottom: "2px solid #53d8fb",
            }}
          >
            <div className="flex items-center gap-2">
              <span className="text-xl">{organEmoji}</span>
              <div>
                <h3 className="text-white font-bold text-sm">{organName}</h3>
                <p className="text-cyan-300 text-[10px]">
                  Jawab benar minimal {MIN_CORRECT_TO_PASS} soal
                </p>
              </div>
            </div>
            <div className="flex items-center gap-2">
              {wrongCount > 0 && (
                <motion.span
                  initial={{ scale: 0 }}
                  animate={{ scale: 1 }}
                  className="text-red-400 text-[10px] font-bold bg-red-900/50 px-2 py-0.5 rounded-full"
                >
                  Salah: {wrongCount}x
                </motion.span>
              )}
              <div className="flex items-center gap-1 bg-cyan-900/40 px-2 py-0.5 rounded-full">
                <span className="text-cyan-400 text-xs font-bold">{correctCount}</span>
                <span className="text-gray-500 text-[10px]">/</span>
                <span className="text-gray-400 text-[10px]">{MIN_CORRECT_TO_PASS}</span>
              </div>
              <button
                onClick={onClose}
                className="w-7 h-7 rounded-full flex items-center justify-center text-sm transition-all hover:scale-110 cursor-pointer"
                style={{ background: "rgba(239, 68, 68, 0.2)", color: "#ef4444" }}
                title="Batalkan"
              >
                ✕
              </button>
            </div>
          </div>

          {/* Progress bar */}
          <div className="h-1 w-full" style={{ background: "rgba(255,255,255,0.05)" }}>
            <motion.div
              className="h-full"
              style={{
                background: correctCount >= MIN_CORRECT_TO_PASS
                  ? "linear-gradient(90deg, #4ade80, #FFD700)"
                  : "linear-gradient(90deg, #53d8fb, #4ade80)",
                width: `${Math.min((correctCount / MIN_CORRECT_TO_PASS) * 100, 100)}%`,
              }}
              transition={{ duration: 0.4 }}
            />
          </div>

          {/* Question */}
          <div className="px-5 py-4">
            <motion.p
              key={`q-${currentQuestion.id}`}
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              className="text-white text-sm sm:text-base font-semibold leading-relaxed"
            >
              {currentQuestion.question}
            </motion.p>

            {/* Options */}
            <div className="mt-3 space-y-2.5">
              {currentQuestion.options.map((option, idx) => {
                let optionStyle: React.CSSProperties = {
                  background: "rgba(255,255,255,0.05)",
                  border: "2px solid rgba(255,255,255,0.15)",
                  cursor: isCorrect !== null ? "default" : "pointer",
                };

                if (isCorrect !== null && selectedAnswer === idx) {
                  if (isCorrect) {
                    optionStyle = { ...optionStyle, background: "rgba(74, 222, 128, 0.15)", border: "2px solid #4ade80" };
                  } else {
                    optionStyle = { ...optionStyle, background: "rgba(239, 68, 68, 0.15)", border: "2px solid #ef4444" };
                  }
                }

                if (isCorrect === false && idx === currentQuestion.correctAnswer) {
                  optionStyle = { ...optionStyle, background: "rgba(74, 222, 128, 0.15)", border: "2px solid #4ade80" };
                }

                return (
                  <motion.button
                    key={idx}
                    whileHover={isCorrect === null ? { scale: 1.02 } : undefined}
                    whileTap={isCorrect === null ? { scale: 0.98 } : undefined}
                    onClick={() => handleAnswer(idx)}
                    disabled={isCorrect !== null}
                    className="w-full text-left px-3 py-2.5 rounded-xl transition-all duration-200"
                    style={optionStyle}
                  >
                    <div className="flex items-center gap-3">
                      <span
                        className="w-6 h-6 rounded-full flex items-center justify-center text-[10px] font-bold shrink-0"
                        style={{
                          background: isCorrect && selectedAnswer === idx ? "#4ade80" : isCorrect === false && selectedAnswer === idx ? "#ef4444" : "rgba(255,255,255,0.1)",
                          color: isCorrect && selectedAnswer === idx ? "#000" : isCorrect === false && selectedAnswer === idx ? "#fff" : "#aaa",
                        }}
                      >
                        {String.fromCharCode(65 + idx)}
                      </span>
                      <span
                        className="text-xs sm:text-sm font-medium flex-1"
                        style={{
                          color: isCorrect && selectedAnswer === idx ? "#4ade80" : isCorrect === false && selectedAnswer === idx ? "#ef4444" : "#e0e0e0",
                        }}
                      >
                        {option}
                      </span>
                      {isCorrect && selectedAnswer === idx && (
                        <motion.span initial={{ scale: 0 }} animate={{ scale: 1 }} className="ml-auto text-base">✅</motion.span>
                      )}
                      {isCorrect === false && selectedAnswer === idx && (
                        <motion.span initial={{ scale: 0 }} animate={{ scale: 1 }} className="ml-auto text-base">❌</motion.span>
                      )}
                    </div>
                  </motion.button>
                );
              })}
            </div>
          </div>

          {/* Explanation + Buttons */}
          <AnimatePresence>
            {showExplanation && isCorrect && (
              <motion.div
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: "auto" }}
                exit={{ opacity: 0, height: 0 }}
                className="overflow-hidden"
              >
                <div
                  className="px-5 py-2.5 mx-4 mb-2 rounded-xl text-xs sm:text-sm leading-relaxed"
                  style={{ background: "rgba(74, 222, 128, 0.1)", border: "1px solid rgba(74, 222, 128, 0.3)", color: "#86efac" }}
                >
                  <span className="font-bold">💡 Penjelasan: </span>
                  {currentQuestion.explanation}
                </div>

                <div className="px-5 pb-4">
                  {canSkip ? (
                    /* ===== REACHED 5 CORRECT ===== */
                    <div className="space-y-2">
                      <motion.div
                        initial={{ opacity: 0, y: -10 }}
                        animate={{ opacity: 1, y: 0 }}
                        className="text-center py-1.5 rounded-xl"
                        style={{ background: "rgba(255, 215, 0, 0.1)", border: "1px solid rgba(255, 215, 0, 0.3)" }}
                      >
                        <span className="text-yellow-400 text-sm font-bold">
                          🎉 {correctCount} Jawaban Benar! Bagus sekali!
                        </span>
                      </motion.div>

                      <motion.button
                        initial={{ opacity: 0, y: 10 }}
                        animate={{ opacity: 1, y: 0 }}
                        whileHover={{ scale: 1.03 }}
                        whileTap={{ scale: 0.97 }}
                        onClick={handleSkipNow}
                        className="w-full py-3 rounded-xl font-bold text-sm text-black cursor-pointer"
                        style={{ background: "linear-gradient(90deg, #FFD700, #F18F01)", boxShadow: "0 4px 15px rgba(255, 215, 0, 0.3)" }}
                      >
                        ⏩ Lanjut ke Organ Berikutnya
                      </motion.button>

                      {finishCountdown !== null && finishCountdown > 0 && (
                        <>
                          <div className="flex items-center justify-center gap-2 pt-1">
                            <div className="w-full h-1 rounded-full overflow-hidden" style={{ background: "rgba(255,255,255,0.1)" }}>
                              <motion.div
                                className="h-full rounded-full"
                                style={{ background: "#FFD700" }}
                                initial={{ width: "100%" }}
                                animate={{ width: "0%" }}
                                transition={{ duration: 5, ease: "linear" }}
                              />
                            </div>
                            <span className="text-yellow-400 text-xs font-mono font-bold w-5 text-right">{finishCountdown}</span>
                          </div>
                          <p className="text-center text-gray-500 text-[10px]">
                            Otomatis lanjut dalam {finishCountdown} detik
                          </p>
                        </>
                      )}
                    </div>
                  ) : (
                    /* ===== NOT YET 5 CORRECT ===== */
                    <div className="space-y-2">
                      <motion.button
                        whileHover={{ scale: 1.03 }}
                        whileTap={{ scale: 0.97 }}
                        onClick={handleNextQuestion}
                        className="w-full py-3 rounded-xl font-bold text-sm text-black cursor-pointer"
                        style={{ background: "linear-gradient(90deg, #4ade80, #22c55e)", boxShadow: "0 4px 15px rgba(74, 222, 128, 0.3)" }}
                      >
                        ➡️ Lanjut Sekarang
                        <span className="ml-2 text-xs opacity-70">
                          ({remaining} lagi)
                        </span>
                      </motion.button>

                      {questionCountdown !== null && questionCountdown > 0 && (
                        <>
                          <div className="flex items-center justify-center gap-2">
                            <div className="w-full h-1 rounded-full overflow-hidden" style={{ background: "rgba(255,255,255,0.1)" }}>
                              <motion.div
                                className="h-full rounded-full"
                                style={{ background: "#4ade80" }}
                                initial={{ width: "100%" }}
                                animate={{ width: "0%" }}
                                transition={{ duration: 5, ease: "linear" }}
                              />
                            </div>
                            <span className="text-green-400 text-xs font-mono font-bold w-5 text-right">{questionCountdown}</span>
                          </div>
                          <p className="text-center text-gray-500 text-[10px]">
                            Otomatis lanjut dalam {questionCountdown} detik
                          </p>
                        </>
                      )}
                    </div>
                  )}
                </div>
              </motion.div>
            )}
          </AnimatePresence>

          {/* Wrong answer feedback */}
          <AnimatePresence>
            {wrongFlash && isCorrect === false && (
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                className="px-5 pb-4 text-center"
              >
                <p className="text-red-400 text-sm font-medium animate-pulse">
                  😅 Jawaban salah! Soal diganti ya...
                </p>
              </motion.div>
            )}
          </AnimatePresence>
        </motion.div>
      </motion.div>
    </AnimatePresence>
  );
}
