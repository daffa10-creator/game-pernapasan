"use client";

import React from "react";
import { motion } from "framer-motion";
import { OrganData } from "@/lib/game-data";

interface GameHUDProps {
  currentOrgan: OrganData;
  completedOrgans: string[];
  score: number;
  onStartQuiz: () => void;
  showInfo: boolean;
  onToggleInfo: () => void;
}

export default function GameHUD({
  currentOrgan,
  completedOrgans,
  score,
  onStartQuiz,
  showInfo,
  onToggleInfo,
}: GameHUDProps) {
  const organIcons: Record<string, string> = {
    hidung: "👃",
    faring: "🔹",
    laring: "🎤",
    trakea: "🔧",
    bronkus: "🌿",
    bronkiolus: "🌲",
    alveolus: "🫁",
  };

  const isCompleted = completedOrgans.includes(currentOrgan.id);

  return (
    <>
      {/* Top HUD bar */}
      <motion.div
        initial={{ y: -60 }}
        animate={{ y: 0 }}
        className="absolute top-0 left-0 right-0 z-30"
        style={{
          background: "linear-gradient(180deg, rgba(0,0,0,0.85) 0%, rgba(0,0,0,0.4) 80%, transparent 100%)",
        }}
      >
        <div className="flex items-center justify-between px-4 py-3">
          {/* Organ progress */}
          <div className="flex items-center gap-2">
            <div className="flex gap-1">
              {["hidung", "faring", "laring", "trakea", "bronkus", "bronkiolus", "alveolus"].map(
                (id) => (
                  <div
                    key={id}
                    className="relative"
                  >
                    <div
                      className="w-8 h-8 rounded-lg flex items-center justify-center text-xs transition-all duration-300"
                      style={{
                        background: completedOrgans.includes(id)
                          ? "rgba(74, 222, 128, 0.2)"
                          : id === currentOrgan.id
                          ? "rgba(83, 216, 251, 0.2)"
                          : "rgba(255,255,255,0.05)",
                        border: `2px solid ${completedOrgans.includes(id)
                          ? "#4ade80"
                          : id === currentOrgan.id
                          ? "#53d8fb"
                          : "rgba(255,255,255,0.15)"}`,
                        boxShadow:
                          id === currentOrgan.id
                            ? "0 0 10px rgba(83, 216, 251, 0.4)"
                            : "none",
                      }}
                    >
                      {completedOrgans.includes(id) ? "✅" : organIcons[id] || ""}
                    </div>
                  </div>
                )
              )}
            </div>
          </div>

          {/* Score */}
          <motion.div
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            className="flex items-center gap-2 bg-yellow-500/20 border border-yellow-500/50 rounded-full px-3 py-1"
          >
            <span className="text-yellow-400 text-sm">⭐</span>
            <span className="text-yellow-300 text-sm font-bold">{score}</span>
          </motion.div>
        </div>
      </motion.div>

      {/* Bottom controls */}
      <motion.div
        initial={{ y: 80 }}
        animate={{ y: 0 }}
        className="absolute bottom-0 left-0 right-0 z-30 p-4"
        style={{
          background: "linear-gradient(0deg, rgba(0,0,0,0.85) 0%, rgba(0,0,0,0.4) 80%, transparent 100%)",
        }}
      >
        {/* Current organ label */}
        <div className="flex items-center justify-center mb-3">
          <div
            className="flex items-center gap-2 rounded-full px-4 py-2"
            style={{
              background: `${currentOrgan.accentColor}20`,
              border: `1px solid ${currentOrgan.accentColor}50`,
            }}
          >
            <span className="text-lg">{currentOrgan.iconEmoji}</span>
            <div>
              <p className="text-white text-xs font-bold leading-tight">
                {currentOrgan.name}
              </p>
              <p className="text-gray-400 text-[10px] leading-tight">
                {currentOrgan.englishName}
              </p>
            </div>
          </div>
        </div>

        {/* Action buttons */}
        <div className="flex items-center justify-center gap-3">
          <motion.button
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            onClick={onToggleInfo}
            className="px-4 py-3 rounded-xl text-sm font-bold text-cyan-300"
            style={{
              background: "rgba(83, 216, 251, 0.15)",
              border: "2px solid rgba(83, 216, 251, 0.4)",
            }}
          >
            📖 Info Organ
          </motion.button>

          {!isCompleted ? (
            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              onClick={onStartQuiz}
              className="px-6 py-3 rounded-xl text-sm font-bold text-black"
              style={{
                background: "linear-gradient(90deg, #4ade80, #22c55e)",
                boxShadow: "0 4px 15px rgba(74, 222, 128, 0.3)",
              }}
            >
              🧪 Jawab Pertanyaan
            </motion.button>
          ) : (
            <div
              className="px-6 py-3 rounded-xl text-sm font-bold text-green-300"
              style={{
                background: "rgba(74, 222, 128, 0.1)",
                border: "2px solid rgba(74, 222, 128, 0.3)",
              }}
            >
              ✅ Selesai!
            </div>
          )}
        </div>
      </motion.div>

      {/* Organ Info Panel */}
      {showInfo && <OrganInfoPanel organ={currentOrgan} onClose={onToggleInfo} />}
    </>
  );
}

function OrganInfoPanel({
  organ,
  onClose,
}: {
  organ: OrganData;
  onClose: () => void;
}) {
  return (
    <motion.div
      initial={{ opacity: 0, x: 300 }}
      animate={{ opacity: 1, x: 0 }}
      exit={{ opacity: 0, x: 300 }}
      className="absolute top-14 right-3 bottom-20 z-40 w-[85%] max-w-sm rounded-2xl overflow-y-auto"
      style={{
        background: "linear-gradient(180deg, #1a1a2e, #16213e)",
        border: "2px solid #53d8fb50",
        boxShadow: "-4px 0 20px rgba(0,0,0,0.5)",
        maxHeight: "calc(100vh - 160px)",
      }}
    >
      {/* Header */}
      <div
        className="sticky top-0 px-4 py-3 flex items-center justify-between z-10"
        style={{
          background: "linear-gradient(90deg, #0f3460, #16213e)",
          borderBottom: "1px solid #53d8fb30",
        }}
      >
        <div className="flex items-center gap-2">
          <span className="text-xl">{organ.iconEmoji}</span>
          <div>
            <h3 className="text-white text-sm font-bold">{organ.name}</h3>
            <p className="text-cyan-400 text-[10px]">{organ.englishName}</p>
          </div>
        </div>
        <motion.button
          whileHover={{ scale: 1.1 }}
          whileTap={{ scale: 0.9 }}
          onClick={onClose}
          className="w-8 h-8 rounded-full flex items-center justify-center text-white text-sm"
          style={{ background: "rgba(255,255,255,0.1)" }}
        >
          ✕
        </motion.button>
      </div>

      {/* Content */}
      <div className="px-4 py-4 space-y-4">
        {/* Description */}
        <div>
          <h4 className="text-cyan-300 text-xs font-bold mb-2 uppercase tracking-wider">
            📋 Deskripsi
          </h4>
          <p className="text-gray-300 text-xs leading-relaxed">
            {organ.description}
          </p>
        </div>

        {/* Functions */}
        <div>
          <h4 className="text-cyan-300 text-xs font-bold mb-2 uppercase tracking-wider">
            ⚙️ Fungsi
          </h4>
          <div className="text-gray-300 text-xs leading-relaxed whitespace-pre-line">
            {organ.functionDetail}
          </div>
        </div>

        {/* Fun Fact */}
        <div
          className="rounded-xl p-3"
          style={{
            background: "rgba(241, 143, 1, 0.1)",
            border: "1px solid rgba(241, 143, 1, 0.3)",
          }}
        >
          <h4 className="text-yellow-400 text-xs font-bold mb-1">
            🌟 Tahukah Kamu?
          </h4>
          <p className="text-yellow-200/80 text-xs leading-relaxed">
            {organ.funFact}
          </p>
        </div>
      </div>
    </motion.div>
  );
}
