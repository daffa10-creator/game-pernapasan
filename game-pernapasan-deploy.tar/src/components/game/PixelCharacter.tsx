"use client";

import React, { useEffect, useState } from "react";
import { PIXEL_COLORS } from "@/lib/game-data";

interface PixelCharacterProps {
  x: number;
  y: number;
  direction: "left" | "right" | "idle";
  isWalking: boolean;
  scale?: number;
}

export default function PixelCharacter({
  x,
  y,
  direction,
  isWalking,
  scale = 1,
}: PixelCharacterProps) {
  const [animState, setAnimState] = useState({ frame: 0, bounce: 0 });

  useEffect(() => {
    if (!isWalking) return;
    setAnimState({ frame: 0, bounce: 0 });
    let tick = 0;
    const interval = setInterval(() => {
      tick++;
      const f = tick % 4;
      const b = f === 0 ? -3 : f === 2 ? -2 : 0;
      setAnimState({ frame: f, bounce: b });
    }, 200);
    return () => clearInterval(interval);
  }, [isWalking]);

  const frame = isWalking ? animState.frame : 0;
  const bounce = isWalking ? animState.bounce : 0;

  const flipX = direction === "left" ? -1 : 1;

  return (
    <div
      style={{
        position: "absolute",
        left: x,
        top: y + bounce,
        transform: `scaleX(${flipX}) scale(${scale})`,
        transition: "left 0.05s linear, top 0.05s linear",
        imageRendering: "pixelated",
        zIndex: 10,
      }}
    >
      <svg
        width="32"
        height="48"
        viewBox="0 0 32 48"
        style={{ imageRendering: "pixelated" }}
      >
        {/* === FEMALE CHARACTER: FAZA === */}

        {/* Hair - longer, with side hair flowing down */}
        {/* Top hair */}
        <rect x="9" y="0" width="14" height="3" fill={PIXEL_COLORS.hair} />
        <rect x="8" y="1" width="16" height="2" fill={PIXEL_COLORS.hair} />
        <rect x="7" y="2" width="3" height="3" fill={PIXEL_COLORS.hair} />
        <rect x="22" y="2" width="3" height="3" fill={PIXEL_COLORS.hair} />
        {/* Side hair - left (longer) */}
        <rect x="6" y="4" width="2" height="8" fill={PIXEL_COLORS.hair} />
        <rect x="7" y="4" width="1" height="10" fill={PIXEL_COLORS.hair} />
        {/* Side hair - right (longer) */}
        <rect x="24" y="4" width="2" height="8" fill={PIXEL_COLORS.hair} />
        <rect x="23" y="4" width="1" height="10" fill={PIXEL_COLORS.hair} />
        {/* Hair bangs */}
        <rect x="9" y="3" width="3" height="2" fill={PIXEL_COLORS.hair} />
        <rect x="14" y="3" width="4" height="1" fill={PIXEL_COLORS.hair} />
        <rect x="20" y="3" width="3" height="2" fill={PIXEL_COLORS.hair} />
        {/* Hair bow / ribbon */}
        <rect x="20" y="0" width="2" height="2" fill="#FF69B4" />
        <rect x="22" y="1" width="2" height="1" fill="#FF69B4" />
        <rect x="21" y="1" width="1" height="1" fill="#FF1493" />

        {/* Face */}
        <rect x="9" y="5" width="14" height="1" fill={PIXEL_COLORS.skin} />
        <rect x="8" y="6" width="1" height="3" fill={PIXEL_COLORS.skin} />
        <rect x="23" y="6" width="1" height="3" fill={PIXEL_COLORS.skin} />
        <rect x="8" y="9" width="16" height="1" fill={PIXEL_COLORS.skin} />

        {/* Eyes - larger with eyelashes */}
        <rect x="11" y="6" width="2" height="2" fill={PIXEL_COLORS.eyes} />
        <rect x="19" y="6" width="2" height="2" fill={PIXEL_COLORS.eyes} />
        {/* Eye highlights */}
        <rect x="11" y="6" width="1" height="1" fill="#ffffff" />
        <rect x="19" y="6" width="1" height="1" fill="#ffffff" />
        {/* Eyelashes */}
        <rect x="11" y="5" width="2" height="1" fill={PIXEL_COLORS.eyes} />
        <rect x="19" y="5" width="2" height="1" fill={PIXEL_COLORS.eyes} />

        {/* Blush / rosy cheeks */}
        <rect x="9" y="8" width="1" height="1" fill="#FFB5C5" />
        <rect x="22" y="8" width="1" height="1" fill="#FFB5C5" />

        {/* Mouth - small smile */}
        <rect x="14" y="8" width="4" height="1" fill="#FF8888" />

        {/* Neck */}
        <rect x="13" y="10" width="6" height="2" fill={PIXEL_COLORS.skin} />

        {/* Body / Shirt - feminine top */}
        <rect x="9" y="12" width="14" height="1" fill={PIXEL_COLORS.shirt} />
        <rect x="7" y="13" width="18" height="8" fill={PIXEL_COLORS.shirt} />
        {/* Collar - V-neck style */}
        <rect x="13" y="12" width="6" height="1" fill="#2471A3" />
        <rect x="14" y="13" width="4" height="1" fill={PIXEL_COLORS.skin} />
        {/* Shirt detail - small pocket */}
        <rect x="18" y="14" width="2" height="2" fill="#2471A3" />

        {/* Arms */}
        {isWalking ? (
          <>
            {frame === 0 || frame === 2 ? (
              <>
                <rect x="5" y="13" width="2" height="5" fill={PIXEL_COLORS.shirt} />
                <rect x="4" y="13" width="2" height="4" fill={PIXEL_COLORS.skin} />
                <rect x="4" y="17" width="3" height="1" fill={PIXEL_COLORS.skin} />
                <rect x="25" y="13" width="2" height="5" fill={PIXEL_COLORS.shirt} />
                <rect x="26" y="13" width="2" height="4" fill={PIXEL_COLORS.skin} />
                <rect x="25" y="17" width="3" height="1" fill={PIXEL_COLORS.skin} />
              </>
            ) : frame === 1 ? (
              <>
                <rect x="5" y="14" width="2" height="4" fill={PIXEL_COLORS.shirt} />
                <rect x="4" y="14" width="2" height="4" fill={PIXEL_COLORS.skin} />
                <rect x="25" y="12" width="2" height="5" fill={PIXEL_COLORS.shirt} />
                <rect x="26" y="12" width="2" height="4" fill={PIXEL_COLORS.skin} />
              </>
            ) : (
              <>
                <rect x="5" y="12" width="2" height="5" fill={PIXEL_COLORS.shirt} />
                <rect x="4" y="12" width="2" height="4" fill={PIXEL_COLORS.skin} />
                <rect x="25" y="14" width="2" height="4" fill={PIXEL_COLORS.shirt} />
                <rect x="26" y="14" width="2" height="4" fill={PIXEL_COLORS.skin} />
              </>
            )}
          </>
        ) : (
          <>
            <rect x="5" y="13" width="2" height="5" fill={PIXEL_COLORS.shirt} />
            <rect x="4" y="14" width="2" height="4" fill={PIXEL_COLORS.skin} />
            <rect x="25" y="13" width="2" height="5" fill={PIXEL_COLORS.shirt} />
            <rect x="26" y="14" width="2" height="4" fill={PIXEL_COLORS.skin} />
          </>
        )}

        {/* Backpack - small pink/purple school bag */}
        <rect x="7" y="14" width="2" height="5" fill="#C084FC" />
        <rect x="6" y="13" width="2" height="1" fill="#A855F7" />
        <rect x="6" y="15" width="1" height="3" fill="#A855F7" />
        {/* Backpack strap */}
        <rect x="8" y="13" width="1" height="1" fill="#C084FC" />

        {/* Skirt */}
        <rect x="8" y="21" width="16" height="2" fill="#2E4057" />
        <rect x="7" y="23" width="18" height="2" fill="#2E4057" />

        {/* Legs */}
        <rect x="9" y="25" width="5" height="3" fill={PIXEL_COLORS.skin} />
        <rect x="18" y="25" width="5" height="3" fill={PIXEL_COLORS.skin} />

        {/* Legs and Shoes - animated */}
        {isWalking ? (
          <>
            {frame === 0 ? (
              <>
                <rect x="9" y="28" width="5" height="2" fill={PIXEL_COLORS.pants} />
                <rect x="9" y="30" width="5" height="2" fill={PIXEL_COLORS.shoes} />
                <rect x="8" y="31" width="6" height="2" fill={PIXEL_COLORS.shoes} />
                <rect x="18" y="29" width="5" height="1" fill={PIXEL_COLORS.pants} />
                <rect x="18" y="30" width="5" height="2" fill={PIXEL_COLORS.shoes} />
                <rect x="17" y="31" width="6" height="2" fill={PIXEL_COLORS.shoes} />
              </>
            ) : frame === 1 ? (
              <>
                <rect x="9" y="29" width="5" height="1" fill={PIXEL_COLORS.pants} />
                <rect x="9" y="30" width="5" height="2" fill={PIXEL_COLORS.shoes} />
                <rect x="8" y="30" width="6" height="2" fill={PIXEL_COLORS.shoes} />
                <rect x="18" y="28" width="5" height="2" fill={PIXEL_COLORS.pants} />
                <rect x="18" y="30" width="5" height="2" fill={PIXEL_COLORS.shoes} />
                <rect x="17" y="31" width="6" height="2" fill={PIXEL_COLORS.shoes} />
              </>
            ) : frame === 2 ? (
              <>
                <rect x="9" y="30" width="5" height="2" fill={PIXEL_COLORS.shoes} />
                <rect x="8" y="31" width="6" height="2" fill={PIXEL_COLORS.shoes} />
                <rect x="18" y="28" width="5" height="2" fill={PIXEL_COLORS.pants} />
                <rect x="18" y="30" width="5" height="2" fill={PIXEL_COLORS.shoes} />
                <rect x="17" y="31" width="6" height="2" fill={PIXEL_COLORS.shoes} />
              </>
            ) : (
              <>
                <rect x="9" y="28" width="5" height="2" fill={PIXEL_COLORS.pants} />
                <rect x="9" y="30" width="5" height="2" fill={PIXEL_COLORS.shoes} />
                <rect x="8" y="31" width="6" height="2" fill={PIXEL_COLORS.shoes} />
                <rect x="18" y="30" width="5" height="2" fill={PIXEL_COLORS.shoes} />
                <rect x="17" y="30" width="6" height="2" fill={PIXEL_COLORS.shoes} />
              </>
            )}
          </>
        ) : (
          <>
            <rect x="9" y="28" width="5" height="2" fill={PIXEL_COLORS.pants} />
            <rect x="9" y="30" width="5" height="2" fill={PIXEL_COLORS.shoes} />
            <rect x="8" y="31" width="6" height="2" fill={PIXEL_COLORS.shoes} />
            <rect x="18" y="28" width="5" height="2" fill={PIXEL_COLORS.pants} />
            <rect x="18" y="30" width="5" height="2" fill={PIXEL_COLORS.shoes} />
            <rect x="17" y="31" width="6" height="2" fill={PIXEL_COLORS.shoes} />
          </>
        )}
      </svg>

      {/* Name tag */}
      <div
        style={{
          position: "absolute",
          top: -18,
          left: "50%",
          transform: "translateX(-50%)",
          fontSize: "10px",
          fontFamily: "monospace",
          color: "#fff",
          background: "rgba(0,0,0,0.7)",
          padding: "1px 6px",
          borderRadius: "4px",
          whiteSpace: "nowrap",
          fontWeight: "bold",
        }}
      >
        Faza
      </div>
    </div>
  );
}
