"use client";

import React, { useState, useCallback, useEffect, useRef, useMemo } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { RESPIRATORY_ORGANS, GAME_CONFIG } from "@/lib/game-data";
import PixelCharacter from "@/components/game/PixelCharacter";
import SceneBackground from "@/components/game/SceneBackground";
import QuizOverlay from "@/components/game/QuizOverlay";
import GameHUD from "@/components/game/GameHUD";
import MiniMap from "@/components/game/MiniMap";

// Deterministic seeded PRNG
function seededRandom(seed: number) {
  let s = seed;
  return () => {
    s |= 0; s = s + 0x6D2B79F5 | 0;
    let t = Math.imul(s ^ s >>> 15, 1 | s);
    t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t;
    return ((t ^ t >>> 14) >>> 0) / 4294967296;
  };
}

const START_PARTICLES = (() => {
  const rng = seededRandom(42);
  return Array.from({ length: 40 }, (_, i) => ({
    left: rng() * 100, top: rng() * 100,
    width: 2 + rng() * 6, height: 2 + rng() * 6,
    color: i % 2 === 0 ? "#e94560" : "#53d8fb",
    opacity: 0.15 + rng() * 0.25,
    animDuration: 3 + rng() * 6, animDelay: rng() * 3,
  }));
})();

const CONFETTI_PARTICLES = (() => {
  const rng = seededRandom(99);
  return Array.from({ length: 50 }, (_, i) => ({
    left: rng() * 100, top: -10 + rng() * 20,
    width: 4 + rng() * 8, height: 4 + rng() * 8,
    color: ["#FFD700", "#e94560", "#53d8fb", "#4ade80", "#F18F01"][i % 5],
    borderRadius: i % 3 === 0 ? "50%" : "2px",
    opacity: 0.3 + rng() * 0.4,
    animDuration: 3 + rng() * 4, animDelay: rng() * 2,
  }));
})();

type Phase = "start" | "intro" | "walking" | "arrived" | "quiz" | "completed";

// Dialogue data per organ (static, no re-renders)
const ORGAN_DIALOGUES: Record<string, string[]> = {};
RESPIRATORY_ORGANS.forEach((organ) => {
  ORGAN_DIALOGUES[organ.id] = [
    `Halo! Aku Fathna Mafazah! 👋`,
    `Sekarang kita berada di ${organ.iconEmoji} ${organ.name}!`,
    organ.description,
    `Tekan "Jawab Pertanyaan" untuk melanjutkan petualangan! 🧪`,
  ];
});

export default function GamePage() {
  const [phase, setPhase] = useState<Phase>("start");
  const [organIdx, setOrganIdx] = useState(0);
  const [completed, setCompleted] = useState<string[]>([]);
  const [score, setScore] = useState(0);
  const [showQuiz, setShowQuiz] = useState(false);
  const [showInfo, setShowInfo] = useState(false);
  const [charX, setCharX] = useState(-80);
  const [charY, setCharY] = useState(0);
  const [walking, setWalking] = useState(false);
  const [dialogueIdx, setDialogueIdx] = useState(-1);
  const [typedText, setTypedText] = useState("");
  const [typingDone, setTypingDone] = useState(false);
  const gameRef = useRef<HTMLDivElement>(null);
  const walkFrameRef = useRef<number>(0);
  const typingIntervalRef = useRef<ReturnType<typeof setInterval> | null>(null);

  const organ = RESPIRATORY_ORGANS[organIdx];
  const dialogues = ORGAN_DIALOGUES[organ.id];

  // ========== START ==========
  const handleStart = useCallback(() => {
    setOrganIdx(0);
    setDialogueIdx(0);
    setTypedText("");
    setCharX(-80);
    setCharY(0);
    setPhase("intro");
  }, []);

  // ========== TYPEWRITER ==========
  const dialogueIdxRef = useRef(dialogueIdx);
  dialogueIdxRef.current = dialogueIdx;
  const phaseRef = useRef(phase);
  phaseRef.current = phase;

  // Keep dialogues ref for skip
  const dialoguesRef = useRef(dialogues);
  dialoguesRef.current = dialogues;

  useEffect(() => {
    if (phase !== "intro" || dialogueIdx < 0 || dialogueIdx >= dialogues.length) return;

    const fullText = dialogues[dialogueIdx];
    let charIdx = 0;
    setTypedText("");
    setTypingDone(false);

    typingIntervalRef.current = setInterval(() => {
      charIdx++;
      setTypedText(fullText.slice(0, charIdx));
      if (charIdx >= fullText.length) {
        if (typingIntervalRef.current) clearInterval(typingIntervalRef.current);
        setTypingDone(true);
      }
    }, 25);

    return () => {
      if (typingIntervalRef.current) clearInterval(typingIntervalRef.current);
    };
  }, [phase, dialogueIdx, organ.id, dialogues.length, dialogues]);

  // Skip typewriter: instantly show full text
  const handleSkipTyping = useCallback(() => {
    if (typingIntervalRef.current) clearInterval(typingIntervalRef.current);
    const full = dialoguesRef.current[dialogueIdxRef.current];
    if (full) {
      setTypedText(full);
      setTypingDone(true);
    }
  }, []);

  // Next dialogue: advance to next or start walking
  const handleNextDialogue = useCallback(() => {
    const idx = dialogueIdxRef.current;
    const dials = dialoguesRef.current;
    if (idx + 1 < dials.length) {
      setDialogueIdx(idx + 1);
    } else {
      setDialogueIdx(-1);
      setPhase("walking");
    }
  }, []);

  // ========== WALKING ANIMATION ==========
  useEffect(() => {
    if (phase !== "walking") return;

    const gameEl = gameRef.current;
    if (!gameEl) return;

    setWalking(true);
    // Character stands on the "ground line" of the organ: 82% from top
    const targetX = gameEl.clientWidth / 2 - 32; // center (scaled char is 64px wide)
    const targetY = gameEl.clientHeight * 0.76;    // just above the ground line at 82%
    const speed = 5;

    const animate = () => {
      setCharX((prevX) => {
        const dx = targetX - prevX;
        if (Math.abs(dx) < speed) {
          setWalking(false);
          setPhase("arrived");
          return targetX;
        }
        return prevX + Math.sign(dx) * speed;
      });
      setCharY((prevY) => {
        const dy = targetY - prevY;
        if (Math.abs(dy) < speed) return targetY;
        return prevY + Math.sign(dy) * speed;
      });
      walkFrameRef.current = requestAnimationFrame(animate);
    };

    walkFrameRef.current = requestAnimationFrame(animate);
    return () => {
      cancelAnimationFrame(walkFrameRef.current);
      setWalking(false);
    };
  }, [phase]);

  // ========== QUIZ ==========
  const handleStartQuiz = useCallback(() => {
    setShowQuiz(true);
    setPhase("quiz");
  }, []);

  const handleQuizDone = useCallback(
    (result: { correct: number; wrong: number; total: number }) => {
      setShowQuiz(false);
      const pts = Math.max(100 - result.wrong * 10, 30);
      setScore((s) => s + pts);
      setCompleted((c) => [...c, organ.id]);

      if (organIdx + 1 >= RESPIRATORY_ORGANS.length) {
        // Last organ → completed
        setPhase("completed");
      } else {
        // Walk out: animate character exiting to the right.
        // IMPORTANT: Do NOT set phase to "walking" here — that triggers
        // the walk-in useEffect which would override this animation.
        // Instead, keep phase as-is and just animate directly.
        setWalking(true);
        cancelAnimationFrame(walkFrameRef.current);

        const exitX = (gameRef.current?.clientWidth || 400) + 100;
        let done = false;

        const walkOut = () => {
          setCharX((prev) => {
            if (prev >= exitX && !done) {
              done = true;
              setWalking(false);
              // Small delay, then switch to next organ
              setTimeout(() => {
                setOrganIdx((i) => i + 1);
                setCharX(-80);
                setCharY(0);
                setDialogueIdx(0);
                setTypedText("");
                setShowInfo(false);
                setPhase("intro");
              }, 200);
              return prev;
            }
            return prev + 6;
          });
          if (!done) walkFrameRef.current = requestAnimationFrame(walkOut);
        };
        walkFrameRef.current = requestAnimationFrame(walkOut);
      }
    },
    [organIdx, organ.id],
  );

  // ========== RESTART ==========
  const handleRestart = useCallback(() => {
    cancelAnimationFrame(walkFrameRef.current);
    setPhase("start");
    setOrganIdx(0);
    setCompleted([]);
    setScore(0);
    setShowQuiz(false);
    setShowInfo(false);
    setCharX(-80);
    setCharY(0);
    setWalking(false);
    setDialogueIdx(-1);
    setTypedText("");
  }, []);

  // ========== RENDER ==========
  const isPlaying = phase !== "start" && phase !== "completed";

  return (
    <div className="min-h-screen bg-black flex flex-col items-center justify-center overflow-hidden">
      <div
        ref={gameRef}
        className="relative w-full max-w-lg mx-auto overflow-hidden"
        style={{ height: "100vh", maxHeight: "900px", minHeight: "600px", imageRendering: "pixelated" }}
      >
        {phase === "start" && <StartScreen onStart={handleStart} />}
        {phase === "completed" && <CompletionScreen score={score} onRestart={handleRestart} />}

        {isPlaying && (
          <>
            <SceneBackground organ={organ} progress={organIdx / (RESPIRATORY_ORGANS.length - 1)} />
            <PixelCharacter x={charX} y={charY} direction={walking ? "right" : "idle"} isWalking={walking} scale={2} />

            {/* Mini Map - top right corner */}
            <MiniMap currentOrganIdx={organIdx} completedOrgans={completed} />

            {phase === "intro" && dialogueIdx >= 0 && (
              <DialogueBox
                text={typedText}
                isTypingDone={typingDone}
                onSkip={handleSkipTyping}
                onNext={handleNextDialogue}
              />
            )}

            {(phase === "arrived" || phase === "quiz") && (
              <GameHUD
                currentOrgan={organ}
                completedOrgans={completed}
                score={score}
                onStartQuiz={handleStartQuiz}
                showInfo={showInfo}
                onToggleInfo={() => setShowInfo((s) => !s)}
              />
            )}

            <AnimatePresence>
              {showQuiz && (
                <QuizOverlay
                  key={`q-${organ.id}`}
                  organId={organ.id}
                  organName={organ.name}
                  organEmoji={organ.iconEmoji}
                  onComplete={handleQuizDone}
                  onClose={() => setShowQuiz(false)}
                />
              )}
            </AnimatePresence>
          </>
        )}
      </div>
    </div>
  );
}

// ==========================================
// START SCREEN
// ==========================================
function StartScreen({ onStart }: { onStart: () => void }) {
  const [show, setShow] = useState(false);
  useEffect(() => { const t = setTimeout(() => setShow(true), 600); return () => clearTimeout(t); }, []);

  return (
    <div className="absolute inset-0 flex flex-col items-center justify-center" style={{ background: "linear-gradient(180deg, #0a0a1a 0%, #1a1a2e 30%, #16213e 60%, #0f3460 100%)" }}>
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        {START_PARTICLES.map((p, i) => (
          <div key={i} className="absolute rounded-full" style={{ left: `${p.left}%`, top: `${p.top}%`, width: p.width, height: p.height, backgroundColor: p.color, opacity: p.opacity, animation: `float ${p.animDuration}s ease-in-out ${p.animDelay}s infinite` }} />
        ))}
      </div>
      <div className="absolute inset-0 flex items-center justify-center opacity-[0.06]">
        <svg viewBox="0 0 400 600" className="w-full h-full max-h-[500px]">
          <path d="M200 50 L200 120 L140 200 L100 300 L80 400" stroke="#53d8fb" strokeWidth="8" fill="none" strokeLinecap="round" />
          <path d="M200 120 L260 200 L300 300 L320 400" stroke="#53d8fb" strokeWidth="8" fill="none" strokeLinecap="round" />
          <path d="M170 50 L200 20 L230 50" stroke="#e94560" strokeWidth="6" fill="none" />
          <rect x="180" y="50" width="40" height="70" rx="20" stroke="#e94560" strokeWidth="6" fill="none" />
          {[[80,400,30],[100,430,25],[60,440,20],[320,400,30],[300,430,25],[340,440,20]].map(([cx,cy,r],i) => (
            <circle key={i} cx={cx} cy={cy} r={r as number} stroke="#53d8fb" strokeWidth="3" fill="none" />
          ))}
        </svg>
      </div>
      <div className="relative z-10 flex flex-col items-center px-6 text-center">
        <motion.div initial={{ y: -30, opacity: 0 }} animate={{ y: 0, opacity: 1 }} transition={{ type: "spring", damping: 12 }} className="mb-4">
          <svg width="64" height="96" viewBox="0 0 32 48" style={{ imageRendering: "pixelated" }}>
            {/* Hair */}
            <rect x="9" y="0" width="14" height="3" fill="#4A2800" /><rect x="8" y="1" width="16" height="2" fill="#4A2800" />
            <rect x="7" y="2" width="3" height="3" fill="#4A2800" /><rect x="22" y="2" width="3" height="3" fill="#4A2800" />
            {/* Side hair */}
            <rect x="6" y="4" width="2" height="8" fill="#4A2800" /><rect x="7" y="4" width="1" height="10" fill="#4A2800" />
            <rect x="24" y="4" width="2" height="8" fill="#4A2800" /><rect x="23" y="4" width="1" height="10" fill="#4A2800" />
            {/* Bangs */}
            <rect x="9" y="3" width="3" height="2" fill="#4A2800" /><rect x="14" y="3" width="4" height="1" fill="#4A2800" /><rect x="20" y="3" width="3" height="2" fill="#4A2800" />
            {/* Hair bow */}
            <rect x="20" y="0" width="2" height="2" fill="#FF69B4" /><rect x="22" y="1" width="2" height="1" fill="#FF69B4" /><rect x="21" y="1" width="1" height="1" fill="#FF1493" />
            {/* Face */}
            <rect x="9" y="5" width="14" height="1" fill="#FFD5B8" /><rect x="8" y="6" width="1" height="3" fill="#FFD5B8" /><rect x="23" y="6" width="1" height="3" fill="#FFD5B8" />
            <rect x="8" y="9" width="16" height="1" fill="#FFD5B8" />
            {/* Eyes with lashes */}
            <rect x="11" y="5" width="2" height="1" fill="#222" /><rect x="19" y="5" width="2" height="1" fill="#222" />
            <rect x="11" y="6" width="2" height="2" fill="#222" /><rect x="19" y="6" width="2" height="2" fill="#222" />
            <rect x="11" y="6" width="1" height="1" fill="#fff" /><rect x="19" y="6" width="1" height="1" fill="#fff" />
            {/* Blush */}
            <rect x="9" y="8" width="1" height="1" fill="#FFB5C5" /><rect x="22" y="8" width="1" height="1" fill="#FFB5C5" />
            {/* Mouth */}
            <rect x="14" y="8" width="4" height="1" fill="#FF8888" />
            {/* Neck */}
            <rect x="13" y="10" width="6" height="2" fill="#FFD5B8" />
            {/* Body / Shirt */}
            <rect x="9" y="12" width="14" height="1" fill="#2E86AB" /><rect x="7" y="13" width="18" height="8" fill="#2E86AB" />
            <rect x="13" y="12" width="6" height="1" fill="#2471A3" />
            <rect x="14" y="13" width="4" height="1" fill="#FFD5B8" />
            {/* Arms */}
            <rect x="5" y="13" width="2" height="5" fill="#2E86AB" /><rect x="25" y="13" width="2" height="5" fill="#2E86AB" />
            <rect x="4" y="14" width="2" height="4" fill="#FFD5B8" /><rect x="26" y="14" width="2" height="4" fill="#FFD5B8" />
            {/* Backpack - purple */}
            <rect x="7" y="14" width="2" height="5" fill="#C084FC" /><rect x="6" y="13" width="2" height="1" fill="#A855F7" /><rect x="6" y="15" width="1" height="3" fill="#A855F7" />
            {/* Skirt */}
            <rect x="8" y="21" width="16" height="2" fill="#2E4057" /><rect x="7" y="23" width="18" height="2" fill="#2E4057" />
            {/* Legs */}
            <rect x="9" y="25" width="5" height="3" fill="#FFD5B8" /><rect x="18" y="25" width="5" height="3" fill="#FFD5B8" />
            {/* Socks + Shoes */}
            <rect x="9" y="28" width="5" height="2" fill="#1B4965" /><rect x="18" y="28" width="5" height="2" fill="#1B4965" />
            <rect x="9" y="30" width="5" height="2" fill="#333" /><rect x="8" y="31" width="6" height="2" fill="#333" />
            <rect x="18" y="30" width="5" height="2" fill="#333" /><rect x="17" y="31" width="6" height="2" fill="#333" />
          </svg>
        </motion.div>
        <motion.h1 initial={{ scale: 0.5, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} transition={{ delay: 0.3, type: "spring", damping: 12 }}
          className="text-3xl sm:text-4xl font-black mb-2"
          style={{ background: "linear-gradient(135deg, #e94560, #53d8fb)", WebkitBackgroundClip: "text", WebkitTextFillColor: "transparent", fontFamily: "monospace" }}>
          {GAME_CONFIG.title}
        </motion.h1>
        {show && (
          <motion.p initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="text-gray-400 text-sm mb-8">{GAME_CONFIG.subtitle}</motion.p>
        )}
        {show && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.2 }} className="flex flex-wrap justify-center gap-2 mb-8 max-w-xs">
            {RESPIRATORY_ORGANS.map((o, i) => (
              <motion.div key={o.id} initial={{ scale: 0, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} transition={{ delay: 0.4 + i * 0.1 }}
                className="flex items-center gap-1 px-2 py-1 rounded-full text-[10px]" style={{ background: `${o.accentColor}15`, border: `1px solid ${o.accentColor}30`, color: "#aaa" }}>
                <span>{o.iconEmoji}</span><span>{o.name.split(" ")[0]}</span>
              </motion.div>
            ))}
          </motion.div>
        )}
        {show && (
          <motion.button initial={{ y: 20, opacity: 0 }} animate={{ y: 0, opacity: 1 }} transition={{ delay: 0.8, type: "spring", damping: 12 }}
            whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }} onClick={onStart}
            className="px-8 py-4 rounded-2xl text-lg font-black text-black cursor-pointer"
            style={{ background: "linear-gradient(135deg, #53d8fb, #4ade80)", boxShadow: "0 4px 20px rgba(83,216,251,0.3)" }}>
            🚀 {GAME_CONFIG.startButtonText}
          </motion.button>
        )}
        <motion.p initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 1.2 }} className="text-gray-600 text-[10px] mt-6">
          Game Edukasi IPA - Sistem Pernapasan Manusia
        </motion.p>
        {/* Download button for deploy */}
        <motion.a
          initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 1.5 }}
          href="/api/download-project"
          download="game-pernapasan-deploy.tar.gz"
          className="mt-4 flex items-center gap-2 px-4 py-2 rounded-xl text-[11px] font-bold cursor-pointer transition-all hover:scale-105"
          style={{ background: "rgba(255,255,255,0.06)", border: "1.5px dashed rgba(255,255,255,0.2)", color: "#888" }}
          title="Download file project bersih untuk deploy ke Vercel"
        >
          ⬇️ Download Project (Deploy)
        </motion.a>
      </div>
    </div>
  );
}

// ==========================================
// DIALOGUE BOX
// ==========================================
function DialogueBox({ text, isTypingDone, onSkip, onNext }: { text: string; isTypingDone: boolean; onSkip: () => void; onNext: () => void }) {
  return (
    <motion.div initial={{ y: 80, opacity: 0 }} animate={{ y: 0, opacity: 1 }} className="absolute bottom-0 left-0 right-0 z-40 p-4">
      <div
        className="rounded-2xl p-4"
        style={{ background: "linear-gradient(180deg, #1a1a2e, #0f0f1a)", border: "2px solid #53d8fb50", boxShadow: "0 -4px 20px rgba(0,0,0,0.5)" }}
      >
        <div className="flex items-center gap-2 mb-2">
          <div className="w-6 h-6 rounded-full bg-cyan-500/20 flex items-center justify-center text-xs">👧</div>
          <span className="text-cyan-300 text-xs font-bold">Fathna Mafazah</span>
        </div>
        <p className="text-white text-sm leading-relaxed min-h-[3em]">
          {text}
        </p>
        {/* Skip/Next buttons */}
        <div className="mt-3 flex items-center justify-between">
          {!isTypingDone ? (
            <div className="flex items-center gap-2">
              <div className="flex items-center gap-1">
                <div className="w-1 h-1 rounded-full bg-cyan-400 animate-bounce" />
                <div className="w-1 h-1 rounded-full bg-cyan-400 animate-bounce" style={{ animationDelay: "0.1s" }} />
                <div className="w-1 h-1 rounded-full bg-cyan-400 animate-bounce" style={{ animationDelay: "0.2s" }} />
              </div>
              <span className="text-gray-500 text-[10px]">Mengetik...</span>
            </div>
          ) : (
            <span className="text-gray-600 text-[10px]" />
          )}
          <div className="flex items-center gap-2">
            {!isTypingDone && (
              <motion.button
                initial={{ opacity: 0, scale: 0.8 }}
                animate={{ opacity: 1, scale: 1 }}
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                onClick={onSkip}
                className="px-3 py-1.5 rounded-lg text-[11px] font-bold cursor-pointer"
                style={{ background: "rgba(255,255,255,0.08)", border: "1.5px solid rgba(255,255,255,0.2)", color: "#aaa" }}
              >
                Skip ⏭
              </motion.button>
            )}
            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              onClick={isTypingDone ? onNext : undefined}
              className="px-3 py-1.5 rounded-lg text-[11px] font-bold cursor-pointer transition-all"
              style={{
                background: isTypingDone ? "linear-gradient(90deg, #53d8fb, #4ade80)" : "rgba(255,255,255,0.04)",
                border: isTypingDone ? "none" : "1.5px solid rgba(255,255,255,0.1)",
                color: isTypingDone ? "#000" : "#555",
                boxShadow: isTypingDone ? "0 2px 10px rgba(83,216,251,0.3)" : "none",
              }}
            >
              {isTypingDone ? "Lanjut ▶" : "..."}
            </motion.button>
          </div>
        </div>
      </div>
    </motion.div>
  );
}

// ==========================================
// COMPLETION SCREEN
// ==========================================
function CompletionScreen({ score, onRestart }: { score: number; onRestart: () => void }) {
  const maxScore = RESPIRATORY_ORGANS.length * 100;
  const pct = Math.round((score / maxScore) * 100);
  const stars = pct >= 90 ? 3 : pct >= 70 ? 2 : 1;

  return (
    <div className="absolute inset-0 flex flex-col items-center justify-center px-6" style={{ background: "linear-gradient(180deg, #0a0a1a 0%, #1a1a2e 30%, #16213e 60%, #0f3460 100%)" }}>
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        {CONFETTI_PARTICLES.map((p, i) => (
          <div key={i} className="absolute" style={{ left: `${p.left}%`, top: `${p.top}%`, width: p.width, height: p.height, backgroundColor: p.color, borderRadius: p.borderRadius, opacity: p.opacity, animation: `confetti ${p.animDuration}s ease-out ${p.animDelay}s infinite` }} />
        ))}
      </div>
      <div className="relative z-10 flex flex-col items-center text-center max-w-sm">
        <motion.div initial={{ scale: 0, rotate: -20 }} animate={{ scale: 1, rotate: 0 }} transition={{ type: "spring", damping: 10 }} className="text-7xl mb-4">🏆</motion.div>
        <motion.h2 initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.3 }}
          className="text-2xl font-black mb-2" style={{ background: "linear-gradient(135deg, #FFD700, #F18F01)", WebkitBackgroundClip: "text", WebkitTextFillColor: "transparent" }}>
          Petualangan Selesai!
        </motion.h2>
        <motion.p initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.5 }} className="text-gray-400 text-sm mb-6">
          Kamu telah berhasil menjelajahi seluruh sistem pernapasan manusia!
        </motion.p>
        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.6 }} className="flex gap-2 mb-6">
          {[1, 2, 3].map((i) => (
            <motion.span key={i} initial={{ scale: 0, rotate: -180 }} animate={{ scale: 1, rotate: 0 }} transition={{ delay: 0.8 + i * 0.2, type: "spring" }}
              className="text-4xl" style={{ opacity: i <= stars ? 1 : 0.2 }}>⭐</motion.span>
          ))}
        </motion.div>
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 1 }}
          className="w-full rounded-2xl p-5 mb-6" style={{ background: "rgba(255,255,255,0.05)", border: "1px solid rgba(255,255,255,0.1)" }}>
          <div className="flex items-center justify-between mb-3">
            <span className="text-gray-400 text-sm">Skor Akhir</span>
            <span className="text-yellow-400 text-xl font-black">{score}</span>
          </div>
          <div className="h-3 rounded-full overflow-hidden mb-3" style={{ background: "rgba(255,255,255,0.1)" }}>
            <motion.div initial={{ width: 0 }} animate={{ width: `${pct}%` }} transition={{ delay: 1.2, duration: 1 }} className="h-full rounded-full" style={{ background: "linear-gradient(90deg, #4ade80, #FFD700)" }} />
          </div>
          <p className="text-gray-500 text-xs">{pct}% Akurasi</p>
          <div className="mt-4 pt-4 border-t border-white/10">
            <p className="text-gray-400 text-xs mb-2">Organ yang diselesaikan:</p>
            <div className="flex flex-wrap gap-2">
              {RESPIRATORY_ORGANS.map((o) => (
                <div key={o.id} className="flex items-center gap-1 px-2 py-1 rounded-full text-[10px]" style={{ background: `${o.accentColor}15`, border: `1px solid ${o.accentColor}30`, color: "#ccc" }}>
                  <span>✅</span><span>{o.iconEmoji}</span><span>{o.name.split("(")[0].trim()}</span>
                </div>
              ))}
            </div>
          </div>
        </motion.div>
        <motion.button initial={{ y: 20, opacity: 0 }} animate={{ y: 0, opacity: 1 }} transition={{ delay: 1.4 }}
          whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }} onClick={onRestart}
          className="w-full py-4 rounded-2xl text-base font-black text-black cursor-pointer"
          style={{ background: "linear-gradient(135deg, #53d8fb, #4ade80)", boxShadow: "0 4px 20px rgba(83,216,251,0.3)" }}>
          🔄 Main Lagi
        </motion.button>
        <motion.p initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 1.8 }} className="text-gray-600 text-[10px] mt-4 leading-relaxed">
          Semoga kamu semakin paham tentang sistem pernapasan manusia! 💙
        </motion.p>
      </div>
    </div>
  );
}
