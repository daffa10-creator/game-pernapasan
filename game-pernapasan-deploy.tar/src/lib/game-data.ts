// ==========================================
// GAME DATA: Sistem Pernapasan Manusia
// Interactive Educational Game
// ==========================================

export interface Question {
  id: string;
  question: string;
  options: string[];
  correctAnswer: number; // index of correct option
  explanation: string;
}

export interface OrganData {
  id: string;
  name: string;
  englishName: string;
  description: string;
  functionDetail: string;
  funFact: string;
  bgColor: string;
  accentColor: string;
  textColor: string;
  questions: Question[];
  iconEmoji: string;
}

export const RESPIRATORY_ORGANS: OrganData[] = [
  {
    id: "hidung",
    name: "Hidung (Rongga Hidung)",
    englishName: "Nasal Cavity",
    description:
      "Hidung adalah organ pertama dalam sistem pernapasan. Udara masuk melalui lubang hidung dan melewati rongga hidung.",
    functionDetail:
      "1. Menyaring debu dan kotoran dari udara yang masuk menggunakan rambut halus (silia) dan lendir.\n2. Menghangatkan udara yang dingin sebelum masuk ke paru-paru.\n3. Melembapkan udara yang kering.\n4. Membantu penciuman dengan reseptor bau di atap rongga hidung.",
    funFact:
      "Hidung manusia bisa mengenali lebih dari 1 triliun bau yang berbeda! Selain itu, manusia bisa menghasilkan sekitar 1-2 liter lendir setiap hari.",
    bgColor: "#1a1a2e",
    accentColor: "#e94560",
    textColor: "#eee",
    iconEmoji: "👃",
    questions: [
      {
        id: "h1",
        question: "Apa fungsi utama rambut halus (silia) di dalam hidung?",
        options: [
          "Menyaring debu dan kotoran dari udara",
          "Menghasilkan suara",
          "Membantu pencernaan makanan",
          "Menghasilkan oksigen",
        ],
        correctAnswer: 0,
        explanation:
          "Rambut halus (silia) di dalam hidung berfungsi untuk menyaring debu, kotoran, dan partikel asing dari udara yang kita hirup.",
      },
      {
        id: "h2",
        question: "Apa yang terjadi pada udara di dalam rongga hidung?",
        options: [
          "Udara makin dingin dan kering",
          "Udara dihangatkan dan dilembapkan",
          "Udara berubah menjadi karbon dioksida",
          "Udara langsung masuk ke lambung",
        ],
        correctAnswer: 1,
        explanation:
          "Di dalam rongga hidung, udara dihangatkan oleh pembuluh darah dan dilembapkan oleh lendir agar tidak merusak paru-paru.",
      },
      {
        id: "h3",
        question: "Berapa jumlah lendir yang diproduksi hidung setiap hari?",
        options: ["10-20 ml", "100-200 ml", "1-2 liter", "5-10 liter"],
        correctAnswer: 2,
        explanation:
          "Hidung manusia menghasilkan sekitar 1-2 liter lendir setiap hari untuk menjaga kelembapan dan menangkap partikel asing.",
      },
    ],
  },
  {
    id: "faring",
    name: "Faring (Tenggorokan)",
    englishName: "Pharynx",
    description:
      "Faring atau tenggorokan adalah saluran penghubung antara rongga hidung dan laring (kotak suara) serta kerongkongan.",
    functionDetail:
      "1. Menjadi saluran udara dari rongga hidung ke laring.\n2. Juga berfungsi sebagai saluran makanan dari mulut ke kerongkongan.\n3. Memiliki katup epiglotis yang mencegah makanan masuk ke saluran napas.\n4. Terdiri dari 3 bagian: nasofaring, orofaring, dan laringofaring.",
    funFact:
      "Epiglotis adalah katup kecil yang menutup saluran napas saat kita menelan makanan. Proses ini terjadi secara otomatis! Bayangkan kalau kita harus mengingat untuk menutup saluran napas setiap kali menelan.",
    bgColor: "#16213e",
    accentColor: "#0f3460",
    textColor: "#eee",
    iconEmoji: "🔹",
    questions: [
      {
        id: "f1",
        question: "Apa fungsi utama faring dalam sistem pernapasan?",
        options: [
          "Menghasilkan oksigen",
          "Menjadi saluran penghubung udara dari hidung ke laring",
          "Menyaring udara dari debu",
          "Menghasilkan lendir",
        ],
        correctAnswer: 1,
        explanation:
          "Faring berfungsi sebagai saluran penghubung yang mengalirkan udara dari rongga hidung menuju laring dan selanjutnya ke paru-paru.",
      },
      {
        id: "f2",
        question: "Berapa bagian yang dimiliki faring?",
        options: ["1 bagian", "2 bagian", "3 bagian", "4 bagian"],
        correctAnswer: 2,
        explanation:
          "Faring terdiri dari 3 bagian yaitu nasofaring (atas, dekat hidung), orofaring (tengah, dekat mulut), dan laringofaring (bawah, dekat laring).",
      },
      {
        id: "f3",
        question: "Apa fungsi epiglotis?",
        options: [
          "Menyaring udara",
          "Menutup saluran napas saat menelan makanan",
          "Menghasilkan suara",
          "Menghangatkan udara",
        ],
        correctAnswer: 1,
        explanation:
          "Epiglotis adalah katup kecil yang menutup saluran napas (laring) saat kita menelan makanan, sehingga makanan masuk ke kerongkongan dan tidak ke paru-paru.",
      },
    ],
  },
  {
    id: "laring",
    name: "Laring (Kotak Suara)",
    englishName: "Larynx",
    description:
      "Laring atau kotak suara terletak di bawah faring. Organ ini mengandung pita suara yang memungkinkan kita berbicara.",
    functionDetail:
      "1. Mengalirkan udara dari faring ke trakea.\n2. Menghasilkan suara dengan getaran pita suara.\n3. Melindungi saluran napas bagian bawah dengan epiglotis.\n4. Mempunyai tulang rawan yang bisa diraba sebagai 'Adam's apple'.",
    funFact:
      "Pita suara pria lebih panjang dan tebal dari wanita, itulah mengapa suara pria lebih berat. Saat bayi menangis, pita suaranya bisa bergetar hingga 600 kali per detik!",
    bgColor: "#0f3460",
    accentColor: "#e94560",
    textColor: "#eee",
    iconEmoji: "🎤",
    questions: [
      {
        id: "l1",
        question: "Apa nama lain dari laring?",
        options: [
          "Rongga Hidung",
          "Tenggorokan",
          "Kotak Suara",
          "Batang Tenggorokan",
        ],
        correctAnswer: 2,
        explanation:
          "Laring sering disebut kotak suara karena di dalamnya terdapat pita suara yang berfungsi untuk menghasilkan suara.",
      },
      {
        id: "l2",
        question: "Apa yang menyebabkan kita bisa berbicara?",
        options: [
          "Paru-paru yang bergetar",
          "Getaran pita suara di laring",
          "Hidung yang bergetar",
          "Epiglotis yang bergerak",
        ],
        correctAnswer: 1,
        explanation:
          "Kita bisa berbicara karena udara dari paru-paru melewati pita suara di laring, menyebabkannya bergetar dan menghasilkan suara.",
      },
      {
        id: "l3",
        question: "Mengapa suara pria lebih berat dari suara wanita?",
        options: [
          "Paru-paru pria lebih besar",
          "Pita suara pria lebih panjang dan tebal",
          "Hidung pria lebih besar",
          "Tenggorokan pria lebih panjang",
        ],
        correctAnswer: 1,
        explanation:
          "Pita suara pria lebih panjang dan tebal, sehingga bergetar lebih lambat dan menghasilkan nada suara yang lebih rendah/berat dibandingkan wanita.",
      },
    ],
  },
  {
    id: "trakea",
    name: "Trakea (Batang Tenggorokan)",
    englishName: "Trachea",
    description:
      "Trakea adalah saluran udara berbentuk tabung yang menghubungkan laring dengan bronkus. Panjangnya sekitar 10-12 cm.",
    functionDetail:
      "1. Mengalirkan udara dari laring ke bronkus.\n2. Dindingnya tersusun dari 16-20 cincin tulang rawan berbentuk huruf C.\n3. Dilapisi silia dan lendir untuk menangkap partikel asing.\n4. Cincin tulang rawan menjaga trakea tetap terbuka.",
    funFact:
      "Trakea bisa membesar dan mengecil untuk mengatur aliran udara. Saat berolahraga, trakea membesar agar lebih banyak udara bisa masuk ke paru-paru!",
    bgColor: "#1a1a2e",
    accentColor: "#53d8fb",
    textColor: "#eee",
    iconEmoji: "🔧",
    questions: [
      {
        id: "t1",
        question: "Berapa panjang trakea manusia secara umum?",
        options: ["3-5 cm", "5-8 cm", "10-12 cm", "20-25 cm"],
        correctAnswer: 2,
        explanation:
          "Trakea manusia memiliki panjang sekitar 10-12 cm dan berdiameter sekitar 2,5 cm. Cukup panjang untuk menghubungkan laring dengan bronkus.",
      },
      {
        id: "t2",
        question: "Apa bentuk cincin tulang rawan pada dinding trakea?",
        options: ["Bentuk O (lingkaran penuh)", "Bentuk C (terbuka di belakang)", "Bentuk segitiga", "Bentuk persegi"],
        correctAnswer: 1,
        explanation:
          "Cincin tulang rawan trakea berbentuk huruf C dan terbuka di bagian belakang. Bagian yang terbuka dilapisi otot untuk fleksibilitas saat menelan.",
      },
      {
        id: "t3",
        question: "Mengapa trakea harus tetap terbuka?",
        options: [
          "Agar makanan bisa lewat",
          "Agar udara bisa mengalir dengan lancar ke paru-paru",
          "Agar suara bisa keluar",
          "Agar lendir bisa diproduksi",
        ],
        correctAnswer: 1,
        explanation:
          "Cincin tulang rawan pada trakea berfungsi menjaga saluran tetap terbuka sehingga udara bisa mengalir dengan lancar dari laring menuju paru-paru.",
      },
    ],
  },
  {
    id: "bronkus",
    name: "Bronkus",
    englishName: "Bronchi",
    description:
      "Bronkus adalah percabangan trakea yang menuju ke paru-paru. Trakea bercabang menjadi dua bronkus utama.",
    functionDetail:
      "1. Mengalirkan udara dari trakea ke masing-masing paru-paru.\n2. Bronkus kanan lebih pendek dan lebih lebar dari bronkus kiri.\n3. Dinding bronkus juga memiliki cincin tulang rawan.\n4. Terus bercabang menjadi bronkus yang lebih kecil (bronkiolus).",
    funFact:
      "Bronkus kanan lebih pendek dan lebih lebar dibanding bronkus kiri, sehingga benda asing yang masuk ke saluran napas lebih sering masuk ke paru-paru kanan!",
    bgColor: "#16213e",
    accentColor: "#e94560",
    textColor: "#eee",
    iconEmoji: "🌿",
    questions: [
      {
        id: "b1",
        question: "Trakea bercabang menjadi berapa bronkus utama?",
        options: ["1 bronkus", "2 bronkus", "3 bronkus", "4 bronkus"],
        correctAnswer: 1,
        explanation:
          "Trakea bercabang menjadi 2 bronkus utama: bronkus kiri yang menuju paru-paru kiri, dan bronkus kanan yang menuju paru-paru kanan.",
      },
      {
        id: "b2",
        question: "Bronkus mana yang lebih pendek dan lebih lebar?",
        options: [
          "Bronkus kiri",
          "Bronkus kanan",
          "Keduanya sama besar",
          "Tergantung usia",
        ],
        correctAnswer: 1,
        explanation:
          "Bronkus kanan lebih pendek, lebih lebar, dan lebih vertikal dibanding bronkus kiri. Karena itu, benda asing sering masuk ke paru-paru kanan.",
      },
      {
        id: "b3",
        question: "Apa yang terjadi setelah bronkus masuk ke paru-paru?",
        options: [
          "Bronkus berhenti",
          "Bronkus bercabang menjadi bronkiolus",
          "Bronkus menjadi alveolus",
          "Bronkus berubah menjadi trakea",
        ],
        correctAnswer: 1,
        explanation:
          "Setelah masuk ke paru-paru, bronkus terus bercabang menjadi cabang-cabang yang lebih kecil yang disebut bronkiolus.",
      },
    ],
  },
  {
    id: "bronkiolus",
    name: "Bronkiolus",
    englishName: "Bronchioles",
    description:
      "Bronkiolus adalah cabang-cabang kecil dari bronkus yang berada di dalam paru-paru. Diameter bronkiolus sangat kecil.",
    functionDetail:
      "1. Mengalirkan udara ke bagian terkecil paru-paru.\n2. Tidak memiliki tulang rawan pada dindingnya.\n3. Dinding bronkiolus memiliki otot polos yang bisa mengecil dan membesar.\n4. Bronkiolus bercabang menjadi bronkiolus terminal dan bronkiolus respiratorius.",
    funFact:
      "Jika semua bronkiolus dalam paru-paru direntangkan dan disambungkan, panjangnya bisa mencapai lebih dari 2.400 km! Itu hampir sepanjang jarak dari Jakarta ke Timor Leste bolak-balik!",
    bgColor: "#0f3460",
    accentColor: "#53d8fb",
    textColor: "#eee",
    iconEmoji: "🌲",
    questions: [
      {
        id: "br1",
        question: "Apa perbedaan bronkiolus dengan bronkus?",
        options: [
          "Bronkiolus lebih besar",
          "Bronkiolus tidak memiliki tulang rawan",
          "Bronkiolus hanya ada satu",
          "Bronkiolus berada di luar paru-paru",
        ],
        correctAnswer: 1,
        explanation:
          "Berbeda dengan bronkus yang memiliki cincin tulang rawan, bronkiolus tidak memiliki tulang rawan dan dindingnya hanya terdiri dari otot polos dan jaringan elastis.",
      },
      {
        id: "br2",
        question: "Apa yang menyebabkan serangan asma?",
        options: [
          "Bronkus menyempit",
          "Otot polos bronkiolus berkontraksi sehingga menyempit",
          "Alveolus membengkak",
          "Trakea tersumbat",
        ],
        correctAnswer: 1,
        explanation:
          "Pada serangan asma, otot polos pada dinding bronkiolus berkontraksi secara berlebihan, menyebabkan bronkiolus menyempit dan sulit bernapas.",
      },
      {
        id: "br3",
        question: "Apa yang ada di ujung bronkiolus?",
        options: [
          "Trakea",
          "Bronkus",
          "Alveolus (kantong udara)",
          "Faring",
        ],
        correctAnswer: 2,
        explanation:
          "Di ujung bronkiolus terdapat kumpulan kantong udara kecil yang disebut alveolus. Di sinilah pertukaran gas O₂ dan CO₂ terjadi.",
      },
    ],
  },
  {
    id: "alveolus",
    name: "Alveolus",
    englishName: "Alveoli",
    description:
      "Alveolus adalah kantong udara kecil di ujung bronkiolus. Inilah tempat pertukaran gas oksigen dan karbon dioksida terjadi.",
    functionDetail:
      "1. Pertukaran O₂ (oksigen) dari udara ke darah.\n2. Pertukaran CO₂ (karbon dioksida) dari darah ke udara.\n3. Dikelilingi oleh kapiler darah yang sangat tipis.\n4. Manusia memiliki sekitar 300-500 juta alveolus di kedua paru-paru.",
    funFact:
      "Jika semua alveolus direntangkan, luas permukaannya mencapai sekitar 70 meter persegi! Itu setara dengan luas setengah lapangan bulu tangkis! Dan jumlahnya mencapai sekitar 300-500 juta alveolus.",
    bgColor: "#1a1a2e",
    accentColor: "#e94560",
    textColor: "#eee",
    iconEmoji: "🫁",
    questions: [
      {
        id: "a1",
        question: "Apa yang terjadi di alveolus?",
        options: [
          "Udara disaring dari debu",
          "Pertukaran oksigen dan karbon dioksida",
          "Suara diproduksi",
          "Makanan dicerna",
        ],
        correctAnswer: 1,
        explanation:
          "Di alveolus terjadi pertukaran gas: oksigen (O₂) dari udara masuk ke dalam darah, dan karbon dioksida (CO₂) dari darah keluar untuk dikeluarkan saat kita menghembuskan napas.",
      },
      {
        id: "a2",
        question: "Berapa jumlah alveolus yang dimiliki manusia?",
        options: [
          "Sekitar 100 ribu",
          "Sekitar 1 juta",
          "Sekitar 300-500 juta",
          "Sekitar 1 miliar",
        ],
        correctAnswer: 2,
        explanation:
          "Manusia memiliki sekitar 300-500 juta alveolus di kedua paru-paru. Jumlah yang sangat banyak ini memastikan pertukaran gas berlangsung efisien.",
      },
      {
        id: "a3",
        question: "Gas apa yang kita keluarkan saat menghembuskan napas?",
        options: [
          "Oksigen (O₂)",
          "Nitrogen (N₂)",
          "Karbon Dioksida (CO₂)",
          "Hidrogen (H₂)",
        ],
        correctAnswer: 2,
        explanation:
          "Saat kita menghembuskan napas, kita mengeluarkan karbon dioksida (CO₂) yang merupakan hasil sisa metabolisme tubuh. CO₂ ini ditransfer dari darah ke alveolus, lalu dikeluarkan melalui hidung/mulut.",
      },
    ],
  },
];

export const GAME_CONFIG = {
  title: "Petualangan Sistem Pernapasan",
  subtitle: "Jelajahi organ pernapasan manusia!",
  startButtonText: "Mulai Petualangan",
  characterName: "Fathna Mafazah",
  introText:
    "Halo! Aku Fathna Mafazah! Aku akan mengajakmu berpetualang menjelajahi sistem pernapasan manusia. Kita akan mulai dari hidung sampai ke alveolus. Di setiap organ, aku akan mengajukan pertanyaan. Jawab minimal 5 soal dengan benar agar kita bisa lanjut ke organ berikutnya. Yuk, kita mulai!",
};

// Pixel character colors
export const PIXEL_COLORS = {
  skin: "#FFD5B8",
  hair: "#4A2800",
  shirt: "#2E86AB",
  pants: "#1B4965",
  shoes: "#333333",
  eyes: "#222222",
  mouth: "#FF6B6B",
  backpack: "#F18F01",
  outline: "#111111",
};
