import { Question } from "@/lib/game-data";

// ==========================================
// QUESTION BANK: Sistem Pernapasan Manusia
// Educational Game - Bahasa Indonesia
// ==========================================

export const MIN_CORRECT_TO_PASS = 5;

// ==========================================
// BANK DATA
// ==========================================
const BANK: Record<string, Question[]> = {
  // ==========================================
  // HIDUNG (Rongga Hidung / Nasal Cavity)
  // ==========================================
  hidung: [
    // -- Fungsi --
    {
      id: "hidung_1",
      question: "Apa fungsi utama silia (rambut halus) di dalam hidung?",
      options: [
        "Menyaring debu dan kotoran dari udara",
        "Menghasilkan suara",
        "Membantu pencernaan makanan",
        "Menghasilkan oksigen",
      ],
      correctAnswer: 0,
      explanation:
        "Silia berfungsi untuk menyaring debu, kotoran, dan partikel asing dari udara yang kita hirup agar tidak masuk ke paru-paru.",
    },
    {
      id: "hidung_2",
      question: "Apa yang terjadi pada udara saat melewati rongga hidung?",
      options: [
        "Udara makin dingin dan kering",
        "Udara dihangatkan dan dilembapkan",
        "Udara berubah menjadi karbon dioksida",
        "Udara langsung masuk ke lambung",
      ],
      correctAnswer: 1,
      explanation:
        "Di dalam rongga hidung, udara dihangatkan oleh jaringan pembuluh darah yang kaya dan dilembapkan oleh lendir sehingga aman untuk paru-paru.",
    },
    {
      id: "hidung_3",
      question: "Apa fungsi lendir yang diproduksi rongga hidung?",
      options: [
        "Menghasilkan suara saat berbicara",
        "Menangkap partikel asing dan melembapkan udara",
        "Membunuh bakteri di dalam paru-paru",
        "Mengubah oksigen menjadi karbon dioksida",
      ],
      correctAnswer: 1,
      explanation:
        "Lendir di rongga hidung berfungsi untuk menangkap partikel asing seperti debu, kuman, dan polen, serta melembapkan udara yang masuk.",
    },
    {
      id: "hidung_4",
      question: "Selain pernapasan, apa fungsi lain dari hidung?",
      options: [
        "Pencernaan makanan",
        "Penciuman dan resonansi suara",
        "Pompa darah",
        "Filter getaran suara",
      ],
      correctAnswer: 1,
      explanation:
        "Hidung memiliki fungsi ganda selain pernapasan, yaitu sebagai organ penciuman (terdapat reseptor bau di atap rongga hidung) dan resonansi suara.",
    },
    // -- Struktur --
    {
      id: "hidung_5",
      question: "Apa nama dinding yang membagi rongga hidung menjadi dua bagian?",
      options: [
        "Epiglotis",
        "Septum nasi",
        "Konka",
        "Trakea",
      ],
      correctAnswer: 1,
      explanation:
        "Septum nasi adalah dinding kartilago dan tulang yang membagi rongga hidung menjadi sisi kiri dan kanan.",
    },
    {
      id: "hidung_6",
      question: "Apa nama tonjolan tulang di dalam rongga hidung yang memperbesar permukaan?",
      options: [
        "Tonsil",
        "Konka (turbinates)",
        "Sinus",
        "Vili",
      ],
      correctAnswer: 1,
      explanation:
        "Konka atau turbinates adalah tonjolan tulang di dinding lateral rongga hidung yang berfungsi memperbesar permukaan untuk menghangatkan dan melembapkan udara.",
    },
    {
      id: "hidung_7",
      question: "Di manakah reseptor penciuman berada di dalam hidung?",
      options: [
        "Di bagian bawah rongga hidung",
        "Di lubang hidung (nostril)",
        "Di atap rongga hidung",
        "Di septum nasi",
      ],
      correctAnswer: 2,
      explanation:
        "Reseptor penciuman (sel olfaktori) terletak di atap (langit-langit) rongga hidung, di area yang disebut olfaktori epithelium.",
    },
    {
      id: "hidung_8",
      question: "Apa nama rongga udara di sekitar hidung yang terhubung ke rongga hidung?",
      options: [
        "Ventrikel",
        "Sinus paranasal",
        "Atrium",
        "Kavum",
      ],
      correctAnswer: 1,
      explanation:
        "Sinus paranasal adalah rongga udara di tulang tengkorak wajah yang terhubung ke rongga hidung. Ada 4 pasang sinus paranasal pada manusia.",
    },
    // -- Fakta Angka --
    {
      id: "hidung_9",
      question: "Berapa jumlah lendir yang diproduksi hidung setiap hari?",
      options: [
        "10-20 ml",
        "100-200 ml",
        "1-2 liter",
        "5-10 liter",
      ],
      correctAnswer: 2,
      explanation:
        "Hidung manusia menghasilkan sekitar 1-2 liter lendir setiap hari. Sebagian besar lendir ini kita telan tanpa disadari karena mengalir ke tenggorokan.",
    },
    {
      id: "hidung_10",
      question: "Berapa jumlah bau berbeda yang bisa dikenali oleh hidung manusia?",
      options: [
        "Sekitar 10.000 jenis bau",
        "Sekitar 1 juta jenis bau",
        "Lebih dari 1 triliun jenis bau",
        "Sekitar 100 ribu jenis bau",
      ],
      correctAnswer: 2,
      explanation:
        "Penelitian menunjukkan bahwa hidung manusia dapat membedakan lebih dari 1 triliun bau yang berbeda, jauh lebih banyak dari yang diperkirakan sebelumnya.",
    },
    {
      id: "hidung_11",
      question: "Berapa banyak udara yang bisa dilalui hidung saat bernapas normal per menit?",
      options: [
        "1-2 liter",
        "5-6 liter",
        "10-12 liter",
        "20-25 liter",
      ],
      correctAnswer: 1,
      explanation:
        "Saat bernapas normal dalam istirahat, seseorang menghirup sekitar 5-6 liter udara per menit melalui hidung.",
    },
    // -- Fakta Menarik --
    {
      id: "hidung_12",
      question: "Mengapa kita bisa mencium bau makanan bahkan sebelum memasukkannya ke mulut?",
      options: [
        "Karena mata bisa mendeteksi aroma",
        "Karena ada jalur dari mulut ke reseptor penciuman di hidung",
        "Karena lambung mengirim sinyal ke hidung",
        "Karena telinga membantu mendeteksi bau",
      ],
      correctAnswer: 1,
      explanation:
        "Ada jalur khusus dari belakang mulut (retronasal olfaction) yang menghubungkan ke reseptor penciuman di atap rongga hidung, sehingga kita bisa 'mencium' makanan saat mengunyah.",
    },
    {
      id: "hidung_13",
      question: "Apa yang dimaksud dengan bersin (sneeze)?",
      options: [
        "Cara tubuh mengeluarkan lendir berlebih",
        "Refleks untuk mengeluarkan partikel asing dari rongga hidung",
        "Tanda bahwa seseorang sedang sakit parah",
        "Cara tubuh menyerap lebih banyak oksigen",
      ],
      correctAnswer: 1,
      explanation:
        "Bersin adalah refleks pelindung tubuh untuk mengeluarkan partikel asing, iritan, atau kuman dari rongga hidung secara paksa dan tiba-tiba.",
    },
    {
      id: "hidung_14",
      question: "Mengapa hidung kita berubah bentuk saat kita tersenyum?",
      options: [
        "Karena tulang hidung bergeser",
        "Karena otot-otot wajah menarik lubang hidung ke atas dan melebar",
        "Karena lendir berkurang di dalam hidung",
        "Karena tulang rawan hidung membesar",
      ],
      correctAnswer: 1,
      explanation:
        "Saat tersenyum, otot-otot wajah seperti levator labii superioris dan nasalis menarik alae nasi (sayap hidung) ke atas dan ke luar, mengubah bentuk hidung.",
    },
    // -- Proses --
    {
      id: "hidung_15",
      question: "Bagaimana cara hidung menghangatkan udara yang dingin?",
      options: [
        "Dengan menghasilkan panas dari otot hidung",
        "Dengan jaringan pembuluh darah yang hangat di dinding rongga hidung",
        "Dengan memeras udara melalui lubang yang kecil",
        "Dengan menambahkan uap panas dari paru-paru",
      ],
      correctAnswer: 1,
      explanation:
        "Dinding rongga hidung memiliki banyak pembuluh darah yang hangat. Saat udara dingin melewati rongga hidung, panas dari pembuluh darah ini ditransfer ke udara.",
    },
    {
      id: "hidung_16",
      question: "Apa yang terjadi pada partikel debu yang masuk ke hidung?",
      options: [
        "Partikel debu langsung masuk ke paru-paru",
        "Partikel debu menempel pada lendir dan silia menggerakkannya ke tenggorokan",
        "Partikel debu larut dalam udara",
        "Partikel debu dikeluarkan melalui telinga",
      ],
      correctAnswer: 1,
      explanation:
        "Partikel debu yang masuk ke hidung akan menempel pada lendir. Silia kemudian menggerakkan lendir beserta partikel tersebut ke arah tenggorokan untuk ditelan atau dikeluarkan.",
    },
    // -- Hubungan --
    {
      id: "hidung_17",
      question: "Organ apa yang terletak tepat di belakang rongga hidung?",
      options: [
        "Paru-paru",
        "Faring (tenggorokan)",
        "Lambung",
        "Jantung",
      ],
      correctAnswer: 1,
      explanation:
        "Faring atau tenggorokan terletak tepat di belakang rongga hidung. Udara dari rongga hidung mengalir ke nasofaring (bagian atas faring) sebelum menuju laring.",
    },
    {
      id: "hidung_18",
      question: "Apa hubungan antara sinus paranasal dan rongga hidung?",
      options: [
        "Sinus paranasal tidak terhubung dengan rongga hidung",
        "Sinus paranasal terhubung melalui saluran kecil ke rongga hidung",
        "Sinus paranasal adalah bagian dari paru-paru",
        "Sinus paranasal berada di dalam lambung",
      ],
      correctAnswer: 1,
      explanation:
        "Sinus paranasal terhubung ke rongga hidung melalui saluran kecil (ostia). Lendir dari sinus mengalir ke rongga hidung, dan udara juga bisa masuk ke sinus.",
    },
    {
      id: "hidung_19",
      question: "Hidung terhubung dengan telinga tengah melalui saluran apa?",
      options: [
        "Saluran pencernaan",
        "Tuba Eustachius",
        "Trakea",
        "Bronkus",
      ],
      correctAnswer: 1,
      explanation:
        "Tuba Eustachius (trompa Eustachius) menghubungkan nasofaring dengan telinga tengah. Saluran ini membantu menyeimbangkan tekanan udara di telinga.",
    },
    // -- Penyakit --
    {
      id: "hidung_20",
      question: "Apa yang dimaksud dengan rinitis?",
      options: [
        "Radang pada trakea",
        "Radang pada selaput lendir rongga hidung",
        "Radang pada paru-paru",
        "Radang pada bronkus",
      ],
      correctAnswer: 1,
      explanation:
        "Rinitis adalah radang atau peradangan pada selaput lendir rongga hidung, yang menyebabkan gejala seperti hidung meler, gatal, dan tersumbat.",
    },
    {
      id: "hidung_21",
      question: "Apa penyebab paling umum dari sinusitis?",
      options: [
        "Terlalu banyak berolahraga",
        "Infeksi virus atau bakteri yang menyumbat sinus",
        "Mengonsumsi terlalu banyak air",
        "Kurang tidur",
      ],
      correctAnswer: 1,
      explanation:
        "Sinusitis biasanya terjadi karena infeksi virus atau bakteri yang menyebabkan peradangan dan penyumbatan pada sinus paranasal, sehingga lendir tertahan di dalamnya.",
    },
    // -- Manakah yang BUKAN --
    {
      id: "hidung_22",
      question: "Manakah yang BUKAN merupakan fungsi rongga hidung?",
      options: [
        "Menyaring udara dari partikel asing",
        "Menghangatkan udara yang masuk",
        "Mencerna makanan",
        "Mendeteksi bau",
      ],
      correctAnswer: 2,
      explanation:
        "Rongga hidung berfungsi menyaring udara, menghangatkannya, melembapkannya, dan mendeteksi bau. Pencernaan makanan bukan fungsi hidung melainkan fungsi sistem pencernaan.",
    },
    {
      id: "hidung_23",
      question: "Manakah yang BUKAN merupakan bagian dari rongga hidung?",
      options: [
        "Nostril (lubang hidung)",
        "Konka (turbinates)",
        "Epiglotis",
        "Septum nasi",
      ],
      correctAnswer: 2,
      explanation:
        "Epiglotis adalah bagian dari laring, bukan rongga hidung. Nostril, konka, dan septum nasi semuanya merupakan bagian dari rongga hidung.",
    },
    // -- Pernyataan Benar/Salah --
    {
      id: "hidung_24",
      question: "Pernyataan mana yang BENAR tentang rongga hidung?",
      options: [
        "Udara tidak mengalami perubahan apapun saat melewati rongga hidung",
        "Rongga hidung tidak memiliki fungsi penciuman",
        "Rongga hidung menghangatkan, melembapkan, dan menyaring udara",
        "Rongga hidung hanya terdiri dari satu ruangan besar",
      ],
      correctAnswer: 2,
      explanation:
        "Rongga hidung berfungsi untuk menghangatkan, melembapkan, dan menyaring udara sebelum udara masuk ke paru-paru. Ini adalah fungsi penting dalam sistem pernapasan.",
    },
    {
      id: "hidung_25",
      question: "Pernyataan mana yang SALAH tentang rongga hidung?",
      options: [
        "Rongga hidung memiliki konka yang memperbesar permukaan",
        "Septum membagi rongga hidung menjadi dua",
        "Rongga hidung menghasilkan 1-2 liter lendir per hari",
        "Semua udara yang kita hirup langsung masuk ke paru tanpa melalui hidung",
      ],
      correctAnswer: 3,
      explanation:
        "Udara yang kita hirup melalui hidung melewati rongga hidung terlebih dahulu. Pernyataan bahwa udara langsung masuk ke paru tanpa melalui hidung adalah salah.",
    },
    // -- Perbandingan --
    {
      id: "hidung_26",
      question: "Apa perbedaan antara bernapas melalui hidung dan melalui mulut?",
      options: [
        "Bernapas melalui mulut lebih sehat",
        "Bernapas melalui hidung lebih baik karena udara tersaring, dihangatkan, dan dilembapkan",
        "Tidak ada perbedaan sama sekali",
        "Bernapas melalui mulut menghasilkan lebih banyak oksigen",
      ],
      correctAnswer: 1,
      explanation:
        "Bernapas melalui hidung lebih baik karena udara akan melewati proses penyaringan, penghangatan, dan pelembapan, sedangkan bernapas melalui mulut tidak memiliki proses ini.",
    },
    {
      id: "hidung_27",
      question: "Jika dibandingkan dengan paru-paru, rongga hidung memiliki fungsi yang berbeda. Manakah perbedaan yang tepat?",
      options: [
        "Paru-paru menyaring udara, rongga hidung bertukar gas",
        "Rongga hidung menyaring dan mengondisikan udara, paru-paru bertukar gas",
        "Keduanya memiliki fungsi yang sama persis",
        "Rongga hidung bertukar gas, paru-paru menyaring udara",
      ],
      correctAnswer: 1,
      explanation:
        "Rongga hidung bertugas menyaring, menghangatkan, dan melembapkan udara, sedangkan paru-paru (khususnya alveolus) bertugas bertukar gas O₂ dan CO₂.",
    },
    {
      id: "hidung_28",
      question: "Apakah manusia bisa bernapas hanya melalui satu lubang hidung pada suatu waktu?",
      options: [
        "Tidak, kedua lubang hidung selalu aktif sama rata",
        "Ya, secara alami satu lubang hidung lebih dominan dan bergantian setiap beberapa jam",
        "Ya, tapi hanya saat kita sedang sakit",
        "Tidak, itu hanya mitos",
      ],
      correctAnswer: 1,
      explanation:
        "Secara alami, terjadi 'nasal cycle' di mana satu lubang hidung lebih terbuka dan dominan, sementara lubang lainnya lebih sempit. Ini bergantian setiap 2-6 jam.",
    },
  ],

  // ==========================================
  // FARING (Pharynx)
  // ==========================================
  faring: [
    // -- Fungsi --
    {
      id: "faring_1",
      question: "Apa fungsi utama faring dalam sistem pernapasan?",
      options: [
        "Menghasilkan oksigen",
        "Menjadi saluran penghubung udara dari hidung ke laring",
        "Menyaring udara dari debu",
        "Menghasilkan lendir",
      ],
      correctAnswer: 1,
      explanation:
        "Faring berfungsi sebagai saluran penghubung yang mengalirkan udara dari rongga hidung menuju laring dan selanjutnya ke paru-paru.",
    },
    {
      id: "faring_2",
      question: "Mengapa faring dikatakan memiliki fungsi ganda?",
      options: [
        "Karena faring bisa bernapas dan mencerna",
        "Karena faring menjadi jalur udara (pernapasan) dan jalur makanan (pencernaan)",
        "Karena faring menghasilkan suara dan lendir",
        "Karena faring bisa bergerak ke atas dan ke bawah",
      ],
      correctAnswer: 1,
      explanation:
        "Faring memiliki fungsi ganda yaitu sebagai saluran udara dari hidung ke laring dalam sistem pernapasan, dan sebagai saluran makanan dari mulut ke kerongkongan dalam sistem pencernaan.",
    },
    {
      id: "faring_3",
      question: "Apa fungsi epiglotis saat kita menelan makanan?",
      options: [
        "Membuka saluran napas lebih lebar",
        "Menutup saluran napas agar makanan masuk ke kerongkongan",
        "Menghasilkan suara saat menelan",
        "Menghancurkan makanan yang masuk",
      ],
      correctAnswer: 1,
      explanation:
        "Epiglotis adalah katup kecil di atas laring yang menutup saat kita menelan, sehingga makanan masuk ke kerongkongan (esofagus) dan tidak masuk ke saluran napas.",
    },
    {
      id: "faring_4",
      question: "Apa yang terjadi pada epiglotis saat kita bernapas?",
      options: [
        "Epiglotis menutup rapat saluran napas",
        "Epiglotis terbuka sehingga udara bisa lewat ke trakea",
        "Epiglotis bergetar untuk menghasilkan suara",
        "Epiglotis menghasilkan lendir",
      ],
      correctAnswer: 1,
      explanation:
        "Saat bernapas, epiglotis dalam posisi terbuka sehingga udara bisa mengalir dari faring melalui laring menuju trakea dengan lancar.",
    },
    // -- Struktur --
    {
      id: "faring_5",
      question: "Faring terdiri dari berapa bagian?",
      options: [
        "1 bagian",
        "2 bagian",
        "3 bagian",
        "4 bagian",
      ],
      correctAnswer: 2,
      explanation:
        "Faring terdiri dari 3 bagian: nasofaring (atas, terhubung ke rongga hidung), orofaring (tengah, terhubung ke mulut), dan laringofaring (bawah, terhubung ke laring).",
    },
    {
      id: "faring_6",
      question: "Bagian faring manakah yang berhubungan langsung dengan rongga hidung?",
      options: [
        "Orofaring",
        "Nasofaring",
        "Laringofaring",
        "Hipofaring",
      ],
      correctAnswer: 1,
      explanation:
        "Nasofaring adalah bagian atas faring yang terletak di belakang rongga hidung. Udara dari hidung masuk ke faring melalui bagian ini.",
    },
    {
      id: "faring_7",
      question: "Di bagian faring manakah tonsil (amandel) palatina berada?",
      options: [
        "Nasofaring",
        "Orofaring",
        "Laringofaring",
        "Trakea",
      ],
      correctAnswer: 1,
      explanation:
        "Tonsil palatina terletak di orofaring, yaitu di kedua sisi belakang tenggorokan antara lengkung palatum (langit-langit lunak).",
    },
    {
      id: "faring_8",
      question: "Apa nama jaringan limfatik yang terdapat di nasofaring?",
      options: [
        "Tonsil palatina",
        "Adenoid (tonsil faringeal)",
        "Tonsil lingual",
        "Vili",
      ],
      correctAnswer: 1,
      explanation:
        "Adenoid atau tonsil faringeal adalah jaringan limfatik yang terletak di atap nasofaring. Jaringan ini membantu melawan infeksi terutama pada anak-anak.",
    },
    // -- Fakta Angka --
    {
      id: "faring_9",
      question: "Berapa panjang faring pada manusia dewasa secara umum?",
      options: [
        "3-5 cm",
        "6-8 cm",
        "12-14 cm",
        "20-25 cm",
      ],
      correctAnswer: 2,
      explanation:
        "Faring manusia dewasa memiliki panjang sekitar 12-14 cm, membentang dari dasar tengkorak hingga ke batas bawah kartilago krikoid (laring).",
    },
    {
      id: "faring_10",
      question: "Berapa banyak jaringan tonsil yang dimiliki manusia?",
      options: [
        "1 jenis tonsil",
        "2 jenis tonsil",
        "3 jenis tonsil",
        "5 jenis tonsil",
      ],
      correctAnswer: 3,
      explanation:
        "Manusia memiliki 5 jenis tonsil yang membentuk cincin Waldeyer: 2 tonsil palatina, 1 adenoid (tonsil faringeal), 2 tonsil tubal, dan 1 tonsil lingual.",
    },
    // -- Fakta Menarik --
    {
      id: "faring_11",
      question: "Mengapa kita bisa tersedak saat makan sambil berbicara?",
      options: [
        "Karena makanan masuk ke paru-paru saat epiglotis terbuka",
        "Karena lidah menghalangi kerongkongan",
        "Karena perut tidak bisa menerima makanan",
        "Karena faring bergetar terlalu kuat",
      ],
      correctAnswer: 0,
      explanation:
        "Saat berbicara, epiglotis terbuka agar udara bisa melewati laring. Jika kita makan dalam kondisi ini, makanan bisa masuk ke saluran napas dan menyebabkan tersedak.",
    },
    {
      id: "faring_12",
      question: "Mengapa adenoid sering diangkat pada anak-anak?",
      options: [
        "Karena adenoid tidak berfungsi",
        "Karena adenoid membesar dan menyumbat saluran napas",
        "Karena adenoid menghasilkan lendir berlebih",
        "Karena adenoid adalah sel kanker",
      ],
      correctAnswer: 1,
      explanation:
        "Pada anak-anak, adenoid sering membesar karena seringnya infeksi. Pembesaran ini bisa menyumbat saluran napas dan menyebabkan gangguan pernapasan, sehingga perlu diangkat.",
    },
    {
      id: "faring_13",
      question: "Apa yang terjadi jika epiglotis tidak menutup dengan baik saat menelan?",
      options: [
        "Tidak terjadi apa-apa",
        "Makanan atau minuman bisa masuk ke saluran napas (trakea)",
        "Suara menjadi lebih jelas",
        "Hidung menjadi tersumbat",
      ],
      correctAnswer: 1,
      explanation:
        "Jika epiglotis tidak menutup dengan baik saat menelan, makanan atau minuman bisa masuk ke trakea dan menyebabkan batuk-batuk, tersedak, atau bahkan aspirasi pneumonia.",
    },
    // -- Proses --
    {
      id: "faring_14",
      question: "Bagaimana udara mengalir dari hidung menuju laring?",
      options: [
        "Hidung → trakea → faring → laring",
        "Hidung → nasofaring → orofaring → laringofaring → laring",
        "Hidung → mulut → laring",
        "Hidung → paru-paru → faring → laring",
      ],
      correctAnswer: 1,
      explanation:
        "Udara dari hidung mengalir melalui nasofaring, kemudian ke orofaring, lalu ke laringofaring, dan akhirnya masuk ke laring sebelum menuju trakea.",
    },
    {
      id: "faring_15",
      question: "Apa yang menyebabkan faring bisa menerima baik udara maupun makanan?",
      options: [
        "Karena faring memiliki dua lubang terpisah",
        "Karena ada katup epiglotis yang mengarahkan aliran",
        "Karena faring bisa berubah bentuk menjadi pipa makanan atau pipa udara",
        "Karena makanan dan udara bercampur di faring",
      ],
      correctAnswer: 1,
      explanation:
        "Katup epiglotis mengarahkan aliran: saat bernapas epiglotis terbuka untuk udara, saat menelan epiglotis menutup laring sehingga makanan masuk ke kerongkongan.",
    },
    // -- Hubungan --
    {
      id: "faring_16",
      question: "Faring berhubungan langsung dengan organ mana selain hidung dan laring?",
      options: [
        "Jantung",
        "Hati",
        "Telinga tengah (melalui tuba Eustachius)",
        "Ginjal",
      ],
      correctAnswer: 2,
      explanation:
        "Nasofaring berhubungan dengan telinga tengah melalui tuba Eustachius (trompa Eustachius). Ini sebabnya sakit tenggorokan bisa menyebabkan sakit telinga.",
    },
    {
      id: "faring_17",
      question: "Organ apa yang terletak tepat di bawah faring?",
      options: [
        "Hidung",
        "Laring (kotak suara)",
        "Paru-paru",
        "Lambung",
      ],
      correctAnswer: 1,
      explanation:
        "Laring (kotak suara) terletak tepat di bawah faring. Faring mengarahkan udara ke laring, yang kemudian mengarahkannya ke trakea.",
    },
    // -- Penyakit --
    {
      id: "faring_18",
      question: "Apa yang dimaksud dengan faringitis?",
      options: [
        "Radang pada lambung",
        "Radang pada dinding faring (tenggorokan)",
        "Radang pada paru-paru",
        "Radang pada hidung",
      ],
      correctAnswer: 1,
      explanation:
        "Faringitis adalah peradangan pada dinding faring yang menyebabkan sakit tenggorokan. Penyebabnya bisa infeksi virus atau bakteri.",
    },
    {
      id: "faring_19",
      question: "Apa gejala utama dari tonsilitis (radang tonsil)?",
      options: [
        "Sakit perut dan mual",
        "Sakit tenggorokan, tonsil membesar dan kemerahan",
        "Batuk kering berkepanjangan",
        "Sesak napas saat berlari",
      ],
      correctAnswer: 1,
      explanation:
        "Tonsilitis menyebabkan sakit tenggorokan, tonsil (amandel) membesar dan kemerahan, sulit menelan, dan kadang demam.",
    },
    // -- Manakah yang BUKAN --
    {
      id: "faring_20",
      question: "Manakah yang BUKAN merupakan bagian dari faring?",
      options: [
        "Nasofaring",
        "Orofaring",
        "Laringofaring",
        "Bronkofaring",
      ],
      correctAnswer: 3,
      explanation:
        "Faring terdiri dari 3 bagian: nasofaring, orofaring, dan laringofaring. Tidak ada bagian yang disebut 'bronkofaring'.",
    },
    {
      id: "faring_21",
      question: "Manakah yang BUKAN fungsi faring?",
      options: [
        "Saluran udara dari hidung ke laring",
        "Saluran makanan dari mulut ke kerongkongan",
        "Pertukaran gas oksigen dan karbon dioksida",
        "Tempat beradanya tonsil sebagai pertahanan imun",
      ],
      correctAnswer: 2,
      explanation:
        "Pertukaran gas O₂ dan CO₂ terjadi di alveolus paru-paru, bukan di faring. Faring hanya berfungsi sebagai saluran penghubung udara dan makanan.",
    },
    // -- Pernyataan Benar/Salah --
    {
      id: "faring_22",
      question: "Pernyataan mana yang BENAR tentang faring?",
      options: [
        "Faring hanya berfungsi untuk saluran udara saja",
        "Faring hanya berfungsi untuk saluran makanan saja",
        "Faring berfungsi sebagai saluran udara dan makanan sekaligus",
        "Faring tidak berhubungan dengan organ lain",
      ],
      correctAnswer: 2,
      explanation:
        "Faring memang berfungsi ganda: sebagai saluran udara dari rongga hidung ke laring (sistem pernapasan) dan sebagai saluran makanan dari mulut ke kerongkongan (sistem pencernaan).",
    },
    {
      id: "faring_23",
      question: "Pernyataan mana yang SALAH tentang epiglotis?",
      options: [
        "Epiglotis terbuat dari kartilago",
        "Epiglotis menutup saat kita menelan makanan",
        "Epiglotis berfungsi untuk menyaring udara dari debu",
        "Epiglotis terletak di antara faring dan laring",
      ],
      correctAnswer: 2,
      explanation:
        "Epiglotis bukan berfungsi menyaring udara dari debu, melainkan berfungsi sebagai katup yang menutup laring saat menelan makanan agar makanan tidak masuk ke saluran napas.",
    },
    // -- Perbandingan --
    {
      id: "faring_24",
      question: "Apa perbedaan antara nasofaring dan orofaring?",
      options: [
        "Nasofaring lebih pendek dari orofaring",
        "Nasofaring terhubung ke hidung, orofaring terhubung ke mulut",
        "Nasofaring tidak memiliki fungsi apapun",
        "Orofaring hanya untuk pernapasan",
      ],
      correctAnswer: 1,
      explanation:
        "Nasofaring terletak di belakang rongga hidung dan menerima udara, sedangkan orofaring terletak di belakang mulut dan menerima makanan serta udara dari mulut.",
    },
    {
      id: "faring_25",
      question: "Bagaimana faring membedakan antara udara dan makanan yang melewatinya?",
      options: [
        "Faring tidak bisa membedakan keduanya",
        "Epiglotis yang mengarahkan: terbuka untuk udara, menutup untuk makanan saat menelan",
        "Udara dan makanan selalu masuk ke tempat yang sama",
        "Otot faring memilih secara manual",
      ],
      correctAnswer: 1,
      explanation:
        "Saat bernapas, epiglotis terbuka dan udara mengalir ke laring. Saat menelan, epiglotis menutup laring sehingga makanan dialihkan ke kerongkongan.",
    },
    {
      id: "faring_26",
      question: "Jika dibandingkan dengan trakea, apa perbedaan utama faring?",
      options: [
        "Faring lebih kecil dari trakea",
        "Faring berfungsi ganda (udara dan makanan), trakea hanya untuk udara",
        "Trakea berfungsi ganda, faring hanya untuk udara",
        "Tidak ada perbedaan signifikan",
      ],
      correctAnswer: 1,
      explanation:
        "Faring berfungsi ganda sebagai saluran udara dan makanan, sedangkan trakea hanya berfungsi sebagai saluran udara menuju paru-paru.",
    },
    {
      id: "faring_27",
      question: "Mengapa tonsil dianggap penting bagi sistem kekebalan tubuh?",
      options: [
        "Karena tonsil menghasilkan oksigen",
        "Karena tonsil menghasilkan sel darah merah",
        "Karena tonsil berisi jaringan limfatik yang menangkap kuman masuk",
        "Karena tonsil membantu mencerna makanan",
      ],
      correctAnswer: 2,
      explanation:
        "Tonsil mengandung jaringan limfatik yang merupakan bagian dari sistem kekebalan tubuh. Tonsil menghasilkan sel darah putih (limfosit) dan menangkap kuman yang masuk melalui mulut dan hidung.",
    },
  ],

  // ==========================================
  // LARING (Larynx / Kotak Suara)
  // ==========================================
  laring: [
    // -- Fungsi --
    {
      id: "laring_1",
      question: "Apa nama lain dari laring?",
      options: [
        "Rongga Hidung",
        "Tenggorokan",
        "Kotak Suara",
        "Batang Tenggorokan",
      ],
      correctAnswer: 2,
      explanation:
        "Laring sering disebut kotak suara karena di dalamnya terdapat pita suara (vocal cords) yang berfungsi untuk menghasilkan suara.",
    },
    {
      id: "laring_2",
      question: "Apa yang menyebabkan kita bisa berbicara?",
      options: [
        "Paru-paru yang bergetar",
        "Getaran pita suara di laring saat udara melewatinya",
        "Hidung yang bergetar",
        "Epiglotis yang bergerak naik turun",
      ],
      correctAnswer: 1,
      explanation:
        "Kita bisa berbicara karena udara dari paru-paru melewati pita suara di laring, menyebabkan pita suara bergetar dan menghasilkan suara.",
    },
    {
      id: "laring_3",
      question: "Selain menghasilkan suara, apa fungsi lain laring?",
      options: [
        "Mencerna makanan",
        "Mengalirkan udara dan melindungi saluran napas bagian bawah",
        "Menyaring darah",
        "Menghasilkan lendir untuk paru-paru",
      ],
      correctAnswer: 1,
      explanation:
        "Selain sebagai penghasil suara, laring juga berfungsi mengalirkan udara dari faring ke trakea dan melindungi saluran napas bagian bawah dengan bantuan epiglotis.",
    },
    // -- Struktur --
    {
      id: "laring_4",
      question: "Apa nama tulang rawan besar yang membentuk tonjolan pada leher (Adam's apple)?",
      options: [
        "Kartilago krikoid",
        "Kartilago tiroid",
        "Kartilago aritenoid",
        "Kartilago epiglotis",
      ],
      correctAnswer: 1,
      explanation:
        "Kartilago tiroid adalah tulang rawan terbesar pada laring yang membentuk tonjolan pada leher, sering disebut 'Adam's apple' atau jakun.",
    },
    {
      id: "laring_5",
      question: "Berapa jumlah tulang rawan yang membentuk kerangka laring?",
      options: [
        "3 tulang rawan",
        "5 tulang rawan",
        "9 tulang rawan",
        "12 tulang rawan",
      ],
      correctAnswer: 2,
      explanation:
        "Laring terdiri dari 9 tulang rawan: 3 tunggal (tiroid, krikoid, epiglotis) dan 3 berpasangan (aritenoid, kornikulat, kuneiform).",
    },
    {
      id: "laring_6",
      question: "Apa nama celah di antara kedua pita suara?",
      options: [
        "Faring",
        "Glottis",
        "Sinus",
        "Bronkus",
      ],
      correctAnswer: 1,
      explanation:
        "Glottis adalah celah antara kedua pita suara (vocal cords). Saat bernapas, glottis terbuka. Saat berbicara, pita suara merapat dan glottis menyempit sehingga udara menyebabkan getaran.",
    },
    {
      id: "laring_7",
      question: "Dari apa pita suara (vocal cords) tersusun?",
      options: [
        "Tulang dan tulang rawan",
        "Otot polos dan ligamen elastis",
        "Jaringan lemak dan kulit",
        "Kartilago dan tulang",
      ],
      correctAnswer: 1,
      explanation:
        "Pita suara tersusun dari otot polos, ligamen elastis, dan jaringan ikat. Komposisi ini memungkinkan pita suara untuk meregang dan bergetar.",
    },
    // -- Fakta Angka --
    {
      id: "laring_8",
      question: "Seberapa cepat pita suara bisa bergetar saat berbicara?",
      options: [
        "10-50 kali per detik",
        "100-1000 kali per detik",
        "5000-10000 kali per detik",
        "1-5 kali per detik",
      ],
      correctAnswer: 1,
      explanation:
        "Pita suara manusia bisa bergetar antara 100 hingga 1000 kali per detik saat berbicara, tergantung pada nada dan jenis kelamin.",
    },
    {
      id: "laring_9",
      question: "Berapa panjang pita suara pria secara umum?",
      options: [
        "Sekitar 5-7 mm",
        "Sekitar 17-25 mm",
        "Sekitar 30-40 mm",
        "Sekitar 50-60 mm",
      ],
      correctAnswer: 1,
      explanation:
        "Pita suara pria memiliki panjang sekitar 17-25 mm, lebih panjang dari pita suara wanita yang sekitar 11-17 mm. Ini menyebabkan suara pria lebih berat.",
    },
    {
      id: "laring_10",
      question: "Berapa frekuensi suara pria dewasa saat berbicara normal?",
      options: [
        "Sekitar 85-180 Hz",
        "Sekitar 300-500 Hz",
        "Sekitar 1000-2000 Hz",
        "Sekitar 5000-10000 Hz",
      ],
      correctAnswer: 0,
      explanation:
        "Pria dewasa memiliki frekuensi suara sekitar 85-180 Hz, sedangkan wanita dewasa sekitar 165-255 Hz. Perbedaan ini karena panjang pita suara yang berbeda.",
    },
    // -- Fakta Menarik --
    {
      id: "laring_11",
      question: "Mengapa suara pria lebih berat (rendah) dibanding suara wanita?",
      options: [
        "Paru-paru pria lebih besar",
        "Pita suara pria lebih panjang dan tebal sehingga bergetar lebih lambat",
        "Hidung pria lebih besar",
        "Tenggorokan pria lebih panjang",
      ],
      correctAnswer: 1,
      explanation:
        "Pita suara pria lebih panjang dan lebih tebal dari wanita, sehingga bergetar lebih lambat dan menghasilkan frekuensi suara yang lebih rendah (nada berat).",
    },
    {
      id: "laring_12",
      question: "Mengapa suara bayi sangat tinggi dan nyaring?",
      options: [
        "Karena bayi bernapas lebih cepat",
        "Karena pita suara bayi sangat pendek dan tipis",
        "Karena paru-paru bayi sangat kecil",
        "Karena bayi tidak memiliki epiglotis",
      ],
      correctAnswer: 1,
      explanation:
        "Pita suara bayi sangat pendek dan tipis, sehingga bisa bergetar sangat cepat dan menghasilkan suara yang tinggi. Pada pubertas, pita suara memanjang dan menebal.",
    },
    {
      id: "laring_13",
      question: "Apa yang terjadi pada suara pria saat masa pubertas?",
      options: [
        "Suara menjadi lebih tinggi",
        "Suara menjadi lebih berat karena pita suara memanjang dan menebal",
        "Suara tidak berubah",
        "Suara menghilang sementara",
      ],
      correctAnswer: 1,
      explanation:
        "Pada masa pubertas, pita suara pria memanjang dan menebal akibat pengaruh hormon testosteron, sehingga suara menjadi lebih berat dan rendah.",
    },
    {
      id: "laring_14",
      question: "Mengapa kita bisa mengubah nada suara saat bernyanyi?",
      options: [
        "Karena paru-paru mengubah tekanan udara",
        "Karena otot-otot laring meregang atau merilekskan pita suara",
        "Karena epiglotis bergerak naik turun",
        "Karena lidah mengubah bentuk rongga mulut",
      ],
      correctAnswer: 1,
      explanation:
        "Otot-otot pada laring (khususnya otot krikotiroid dan otot tiroid) bisa meregang atau merilekskan pita suara, mengubah ketegangan dan panjangnya, sehingga mengubah nada suara.",
    },
    // -- Proses --
    {
      id: "laring_15",
      question: "Bagaimana proses dihasilkannya suara oleh laring?",
      options: [
        "Udara dari paru-paru menekan pita suara hingga bergetar, getaran menghasilkan gelombang suara",
        "Pita suara bergetar sendiri tanpa udara",
        "Epiglotis bergetar untuk menghasilkan suara",
        "Tulang rawan laring bergetar bersamaan",
      ],
      correctAnswer: 0,
      explanation:
        "Saat kita berbicara, udara dari paru-paru dikeluarkan dan melewati pita suara yang merapat. Tekanan udara menyebabkan pita suara bergetar dan menghasilkan gelombang suara.",
    },
    {
      id: "laring_16",
      question: "Apa yang terjadi pada pita suara saat kita bernapas normal?",
      options: [
        "Pita suara merapat rapat",
        "Pita suara terbuka lebar sehingga udara bisa lewat",
        "Pita suara bergetar perlahan",
        "Pita suara menghilang",
      ],
      correctAnswer: 1,
      explanation:
        "Saat bernapas normal, pita suara dalam keadaan terbuka (abduksi) sehingga udara bisa mengalir dari trakea ke laring dan sebaliknya tanpa hambatan.",
    },
    // -- Hubungan --
    {
      id: "laring_17",
      question: "Organ apa yang terletak tepat di atas laring?",
      options: [
        "Hidung",
        "Faring (tenggorokan)",
        "Trakea",
        "Paru-paru",
      ],
      correctAnswer: 1,
      explanation:
        "Faring terletak di atas laring. Udara dari faring mengalir ke laring sebelum masuk ke trakea.",
    },
    {
      id: "laring_18",
      question: "Organ apa yang terletak tepat di bawah laring?",
      options: [
        "Hidung",
        "Faring",
        "Trakea (batang tenggorokan)",
        "Bronkus",
      ],
      correctAnswer: 2,
      explanation:
        "Trakea terletak tepat di bawah laring. Laring mengarahkan udara ke trakea yang kemudian bercabang menjadi bronkus menuju paru-paru.",
    },
    // -- Penyakit --
    {
      id: "laring_19",
      question: "Apa yang dimaksud dengan laringitis?",
      options: [
        "Radang pada hidung",
        "Radang pada laring (kotak suara)",
        "Radang pada paru-paru",
        "Radang pada bronkus",
      ],
      correctAnswer: 1,
      explanation:
        "Laringitis adalah peradangan pada laring yang menyebabkan suara serak atau bahkan hilang suara, biasanya disebabkan oleh infeksi virus atau penggunaan suara berlebihan.",
    },
    {
      id: "laring_20",
      question: "Apa yang bisa menyebabkan suara menjadi serak?",
      options: [
        "Terlalu banyak minum air",
        "Radang pada pita suara (laringitis) atau penggunaan suara berlebihan",
        "Bernapas terlalu dalam",
        "Olahraga terlalu keras",
      ],
      correctAnswer: 1,
      explanation:
        "Suara serak bisa disebabkan oleh laringitis (radang pita suara), penggunaan suara berlebihan (berteriak), merokok, atau alergi yang menyebabkan pembengkakan pita suara.",
    },
    // -- Manakah yang BUKAN --
    {
      id: "laring_21",
      question: "Manakah yang BUKAN merupakan tulang rawan pada laring?",
      options: [
        "Kartilago tiroid",
        "Kartilago krikoid",
        "Kartilago bronkial",
        "Kartilago aritenoid",
      ],
      correctAnswer: 2,
      explanation:
        "Kartilago bronkial bukan bagian dari laring. Laring terdiri dari kartilago tiroid, krikoid, epiglotis, aritenoid, kornikulat, dan kuneiform.",
    },
    {
      id: "laring_22",
      question: "Manakah yang BUKAN fungsi laring?",
      options: [
        "Menghasilkan suara",
        "Mengalirkan udara ke trakea",
        "Bertukar gas oksigen dan karbon dioksida",
        "Melindungi saluran napas bagian bawah",
      ],
      correctAnswer: 2,
      explanation:
        "Pertukaran gas O₂ dan CO₂ terjadi di alveolus paru-paru, bukan di laring. Laring berfungsi menghasilkan suara, mengalirkan udara, dan melindungi saluran napas bagian bawah.",
    },
    // -- Pernyataan Benar/Salah --
    {
      id: "laring_23",
      question: "Pernyataan mana yang BENAR tentang pita suara?",
      options: [
        "Pita suara berfungsi seperti terompet yang menghasilkan suara",
        "Pita suara pria dan wanita memiliki ukuran yang sama",
        "Pita suara bergetar saat udara dari paru-paru melewatinya",
        "Pita suara terbuat dari tulang rawan keras",
      ],
      correctAnswer: 2,
      explanation:
        "Pita suara bergetar karena tekanan udara dari paru-paru yang melewatinya. Getaran ini menghasilkan gelombang suara yang kemudian dibentuk oleh mulut dan lidah menjadi kata.",
    },
    {
      id: "laring_24",
      question: "Pernyataan mana yang SALAH tentang laring?",
      options: [
        "Laring terdiri dari beberapa tulang rawan",
        "Laring mengandung pita suara",
        "Laring berada di antara paru-paru dan bronkus",
        "Laring memiliki epiglotis yang menutup saat menelan",
      ],
      correctAnswer: 2,
      explanation:
        "Laring tidak berada di antara paru-paru dan bronkus, melainkan berada di antara faring (atas) dan trakea (bawah). Laring terletak di leher, bukan di dalam paru-paru.",
    },
    // -- Perbandingan --
    {
      id: "laring_25",
      question: "Apa perbedaan utama antara pita suara pria dan wanita?",
      options: [
        "Pita suara pria lebih pendek dari wanita",
        "Pita suara pria lebih panjang dan tebal dari wanita",
        "Tidak ada perbedaan",
        "Pita suara wanita terbuat dari bahan yang berbeda",
      ],
      correctAnswer: 1,
      explanation:
        "Pita suara pria lebih panjang (17-25 mm) dan lebih tebal dibanding wanita (11-17 mm), sehingga bergetar lebih lambat dan menghasilkan suara yang lebih berat.",
    },
    {
      id: "laring_26",
      question: "Jika dibandingkan dengan faring, laring memiliki fungsi yang berbeda. Apa perbedaannya?",
      options: [
        "Laring berfungsi ganda, faring hanya untuk udara",
        "Laring menghasilkan suara, faring berfungsi sebagai saluran udara dan makanan",
        "Tidak ada perbedaan",
        "Faring menghasilkan suara, laring hanya mengalirkan udara",
      ],
      correctAnswer: 1,
      explanation:
        "Laring berfungsi utamanya untuk menghasilkan suara (kotak suara) dan mengalirkan udara, sedangkan faring berfungsi ganda sebagai saluran udara dan makanan.",
    },
    {
      id: "laring_27",
      question: "Saat bernyanyi nada tinggi, apa yang terjadi pada pita suara?",
      options: [
        "Pita suara kendur dan pendek",
        "Pita suara meregang dan memanjang",
        "Pita suara tidak berubah",
        "Pita suara membuka lebar",
      ],
      correctAnswer: 1,
      explanation:
        "Saat menyanyikan nada tinggi, otot-otot laring meregangkan pita suara sehingga menjadi lebih panjang dan tegang. Pita suara yang tegang bergetar lebih cepat dan menghasilkan suara lebih tinggi.",
    },
  ],

  // ==========================================
  // TRAKEA (Trachea / Batang Tenggorokan)
  // ==========================================
  trakea: [
    // -- Fungsi --
    {
      id: "trakea_1",
      question: "Apa fungsi utama trakea dalam sistem pernapasan?",
      options: [
        "Bertukar gas oksigen dan karbon dioksida",
        "Mengalirkan udara dari laring ke bronkus",
        "Menyaring makanan dari saluran napas",
        "Menghasilkan suara",
      ],
      correctAnswer: 1,
      explanation:
        "Trakea berfungsi sebagai saluran utama yang mengalirkan udara dari laring (kotak suara) ke bronkus yang menuju ke paru-paru.",
    },
    {
      id: "trakea_2",
      question: "Mengapa cincin tulang rawan pada trakea penting?",
      options: [
        "Untuk menghasilkan suara",
        "Untuk menjaga trakea tetap terbuka sehingga udara bisa mengalir",
        "Untuk menyaring udara dari kuman",
        "Untuk mencernakan makanan",
      ],
      correctAnswer: 1,
      explanation:
        "Cincin tulang rawan pada trakea berfungsi menjaga saluran tetap terbuka dan tidak kolaps, sehingga udara bisa mengalir dengan lancar ke paru-paru.",
    },
    {
      id: "trakea_3",
      question: "Apa fungsi silia pada dinding trakea?",
      options: [
        "Menghasilkan suara",
        "Menggerakkan lendir dan partikel ke atas menuju tenggorokan",
        "Menghangatkan udara",
        "Mengubah karbon dioksida menjadi oksigen",
      ],
      correctAnswer: 1,
      explanation:
        "Silia pada dinding trakea bergerak secara terkoordinasi ke atas untuk menggerakkan lendir beserta partikel asing yang tertangkap menuju tenggorokan untuk dikeluarkan.",
    },
    // -- Struktur --
    {
      id: "trakea_4",
      question: "Berapa panjang trakea pada manusia dewasa?",
      options: [
        "3-5 cm",
        "5-8 cm",
        "10-12 cm",
        "20-25 cm",
      ],
      correctAnswer: 2,
      explanation:
        "Trakea manusia dewasa memiliki panjang sekitar 10-12 cm dan berdiameter sekitar 2-2,5 cm.",
    },
    {
      id: "trakea_5",
      question: "Apa bentuk cincin tulang rawan pada dinding trakea?",
      options: [
        "Bentuk O (lingkaran penuh)",
        "Bentuk C (terbuka di belakang)",
        "Bentuk segitiga",
        "Bentuk persegi",
      ],
      correctAnswer: 1,
      explanation:
        "Cincin tulang rawan trakea berbentuk huruf C dan terbuka di bagian belakang. Bagian belakang yang terbuka dilapisi oleh otot polos dan jaringan ikat.",
    },
    {
      id: "trakea_6",
      question: "Mengapa cincin tulang rawan trakea terbuka di bagian belakang?",
      options: [
        "Agar udara bisa keluar ke belakang",
        "Agar kerongkongan (esofagus) bisa membesar saat menelan makanan",
        "Agar tulang rawan bisa diganti",
        "Agar lebih ringan",
      ],
      correctAnswer: 1,
      explanation:
        "Bagian belakang trakea yang terbuka memungkinkan kerongkongan (esofagus) yang terletak di belakangnya membesar saat menelan makanan.",
    },
    {
      id: "trakea_7",
      question: "Berapa jumlah cincin tulang rawan yang membentuk dinding trakea?",
      options: [
        "5-8 cincin",
        "10-12 cincin",
        "16-20 cincin",
        "25-30 cincin",
      ],
      correctAnswer: 2,
      explanation:
        "Dinding trakea tersusun dari 16-20 cincin tulang rawan berbentuk huruf C yang tersusun secara berurutan membentuk saluran udara.",
    },
    // -- Fakta Angka --
    {
      id: "trakea_8",
      question: "Berapa diameter trakea pada manusia dewasa?",
      options: [
        "Sekitar 0,5 cm",
        "Sekitar 1 cm",
        "Sekitar 2-2,5 cm",
        "Sekitar 5 cm",
      ],
      correctAnswer: 2,
      explanation:
        "Trakea manusia dewasa memiliki diameter sekitar 2-2,5 cm, cukup besar untuk mengalirkan udara dengan lancar ke paru-paru.",
    },
    {
      id: "trakea_9",
      question: "Berapa banyak percabangan utama yang keluar dari trakea?",
      options: [
        "1 percabangan",
        "2 percabangan",
        "3 percabangan",
        "4 percabangan",
      ],
      correctAnswer: 1,
      explanation:
        "Trakea bercabang menjadi 2 bronkus utama di bagian bawahnya: bronkus kanan menuju paru-paru kanan dan bronkus kiri menuju paru-paru kiri.",
    },
    // -- Fakta Menarik --
    {
      id: "trakea_10",
      question: "Apa yang dimaksud dengan trakeostomi?",
      options: [
        "Operasi mengangkat trakea",
        "Operasi membuat lubang di trakea untuk saluran napas darurat",
        "Operasi memperbesar trakea",
        "Operasi membersihkan lendir di trakea",
      ],
      correctAnswer: 1,
      explanation:
        "Trakeostomi adalah prosedur medis membuat lubang di trakea melalui leher dan memasukkan tabung untuk membantu pernapasan saat saluran udara atas tersumbat.",
    },
    {
      id: "trakea_11",
      question: "Apa yang dimaksud dengan mekanisme mukosiliar pada trakea?",
      options: [
        "Produksi tulang rawan baru",
        "Gerakan silia yang mengangkut lendir dan partikel ke atas",
        "Pertukaran gas di dinding trakea",
        "Pembesaran trakea saat bernapas",
      ],
      correctAnswer: 1,
      explanation:
        "Mekanisme mukosiliar adalah sistem pembersihan alami trakea di mana silia bergerak secara terkoordinasi untuk menggerakkan lendir (mucus) beserta partikel yang terperangkap ke atas menuju faring.",
    },
    {
      id: "trakea_12",
      question: "Trakea bisa membesar saat berolahraga. Mengapa hal ini terjadi?",
      options: [
        "Karena jumlah tulang rawan bertambah",
        "Karena otot polos pada dinding trakea berelaksasi",
        "Karena trakea menghasilkan lebih banyak lendir",
        "Karena tekanan udara menekan trakea dari dalam",
      ],
      correctAnswer: 1,
      explanation:
        "Saat berolahraga, otot polos pada dinding trakea berelaksasi sehingga trakea bisa sedikit membesar, memungkinkan lebih banyak udara mengalir ke paru-paru.",
    },
    // -- Proses --
    {
      id: "trakea_13",
      question: "Apa yang terjadi pada partikel asing yang masuk ke trakea?",
      options: [
        "Partikel langsung masuk ke paru-paru",
        "Partikel tertangkap lendir dan silia menggerakkannya ke atas",
        "Partikel dihancurkan oleh tulang rawan",
        "Partikel larut dalam udara",
      ],
      correctAnswer: 1,
      explanation:
        "Partikel asing yang masuk ke trakea akan menempel pada lendir yang diproduksi oleh sel goblet. Silia kemudian menggerakkan lendir beserta partikel ke atas menuju tenggorokan.",
    },
    {
      id: "trakea_14",
      question: "Dari mana trakea menerima udara dan ke mana ia mengarahkannya?",
      options: [
        "Dari paru-paru ke hidung",
        "Dari laring ke bronkus",
        "Dari bronkus ke alveolus",
        "Dari faring ke kerongkongan",
      ],
      correctAnswer: 1,
      explanation:
        "Trakea menerima udara dari laring (kotak suara) di atasnya dan mengarahkannya ke bronkus (cabang trakea) yang menuju ke paru-paru.",
    },
    // -- Hubungan --
    {
      id: "trakea_15",
      question: "Organ apa yang terletak di depan trakea?",
      options: [
        "Jantung",
        "Kelenjar tiroid (thyroid gland)",
        "Lambung",
        "Hati",
      ],
      correctAnswer: 1,
      explanation:
        "Kelenjar tiroid terletak di depan trakea di bagian leher. Kelenjar ini berbentuk kupu-kupu dan menghasilkan hormon yang mengatur metabolisme tubuh.",
    },
    {
      id: "trakea_16",
      question: "Organ apa yang terletak di belakang trakea?",
      options: [
        "Tulang belakang",
        "Kerongkongan (esofagus)",
        "Paru-paru",
        "Jantung",
      ],
      correctAnswer: 1,
      explanation:
        "Kerongkongan atau esofagus terletak di belakang trakea. Ini sebabnya cincin tulang rawan trakea terbuka di bagian belakang, agar esofagus bisa membesar saat menelan.",
    },
    // -- Penyakit --
    {
      id: "trakea_17",
      question: "Apa yang dimaksud dengan trakeitis?",
      options: [
        "Radang pada pita suara",
        "Radang pada dinding trakea",
        "Radang pada paru-paru",
        "Radang pada bronkus",
      ],
      correctAnswer: 1,
      explanation:
        "Trakeitis adalah peradangan pada dinding trakea yang bisa disebabkan oleh infeksi virus atau bakteri, menyebabkan batuk, nyeri tenggorokan, dan sesak napas.",
    },
    {
      id: "trakea_18",
      question: "Apa yang bisa terjadi jika benda asing masuk ke trakea?",
      options: [
        "Tidak terjadi apa-apa",
        "Batuk-batuk refleks untuk mengeluarkan benda asing",
        "Benda asing langsung larut",
        "Benda asing masuk ke lambung",
      ],
      correctAnswer: 1,
      explanation:
        "Jika benda asing masuk ke trakea, tubuh akan merespons dengan batuk-batuk refleks (cough reflex) untuk mengeluarkan benda tersebut agar tidak masuk ke paru-paru.",
    },
    // -- Manakah yang BUKAN --
    {
      id: "trakea_19",
      question: "Manakah yang BUKAN merupakan lapisan dinding trakea?",
      options: [
        "Lapisan mukosa dengan silia",
        "Cincin tulang rawan berbentuk C",
        "Lapisan otot polos di bagian posterior",
        "Lapisan tulang kompak keras",
      ],
      correctAnswer: 3,
      explanation:
        "Dinding trakea terdiri dari lapisan mukosa dengan silia, cincin tulang rawan berbentuk C, dan lapisan otot polos di bagian posterior (belakang). Tidak ada lapisan tulang kompak.",
    },
    {
      id: "trakea_20",
      question: "Manakah yang BUKAN fungsi trakea?",
      options: [
        "Mengalirkan udara dari laring ke bronkus",
        "Menyaring partikel asing dengan lendir dan silia",
        "Bertukar gas oksigen dan karbon dioksida",
        "Menjaga saluran napas tetap terbuka dengan tulang rawan",
      ],
      correctAnswer: 2,
      explanation:
        "Pertukaran gas O₂ dan CO₂ terjadi di alveolus paru-paru, bukan di trakea. Trakea hanya berfungsi sebagai saluran penghubung dan penyaring.",
    },
    // -- Pernyataan Benar/Salah --
    {
      id: "trakea_21",
      question: "Pernyataan mana yang BENAR tentang trakea?",
      options: [
        "Trakea berbentuk pipa lurus tanpa tulang rawan",
        "Trakea memiliki cincin tulang rawan berbentuk C yang menjaga saluran tetap terbuka",
        "Trakea berfungsi untuk bertukar gas",
        "Trakea hanya ada satu di setiap paru-paru",
      ],
      correctAnswer: 1,
      explanation:
        "Trakea memiliki 16-20 cincin tulang rawan berbentuk C yang menjaga saluran tetap terbuka. Tanpa cincin ini, trakea bisa kolaps dan menghalangi aliran udara.",
    },
    {
      id: "trakea_22",
      question: "Pernyataan mana yang SALAH tentang trakea?",
      options: [
        "Trakea menghubungkan laring dengan bronkus",
        "Dinding trakea memiliki silia yang bergerak lendir ke atas",
        "Trakea berfungsi sebagai tempat pertukaran gas",
        "Cincin tulang rawan trakea terbuka di bagian belakang",
      ],
      correctAnswer: 2,
      explanation:
        "Trakea TIDAK berfungsi sebagai tempat pertukaran gas. Pertukaran gas terjadi di alveolus paru-paru. Trakea hanya berfungsi sebagai saluran udara.",
    },
    // -- Perbandingan --
    {
      id: "trakea_23",
      question: "Apa perbedaan antara trakea dan bronkus?",
      options: [
        "Trakea lebih kecil dari bronkus",
        "Trakea adalah saluran tunggal sebelum bercabang menjadi bronkus",
        "Bronkus tidak memiliki tulang rawan",
        "Trakea tidak memiliki silia",
      ],
      correctAnswer: 1,
      explanation:
        "Trakea adalah saluran udara tunggal yang kemudian bercabang menjadi 2 bronkus utama (kiri dan kanan). Keduanya memiliki tulang rawan dan silia.",
    },
    {
      id: "trakea_24",
      question: "Apa perbedaan bentuk tulang rawan antara trakea dan bronkus?",
      options: [
        "Keduanya memiliki bentuk yang sama persis",
        "Trakea memiliki cincin tulang rawan lengkap, bronkus tidak",
        "Trakea memiliki cincin tulang rawan berbentuk C, bronkus memiliki lempengan tulang rawan yang tidak beraturan",
        "Bronkus tidak memiliki tulang rawan",
      ],
      correctAnswer: 2,
      explanation:
        "Trakea memiliki cincin tulang rawan berbentuk C yang teratur, sedangkan bronkus memiliki lempengan tulang rawan yang semakin tidak beraturan dan semakin sedikit seiring bercabang.",
    },
    {
      id: "trakea_25",
      question: "Jika trakea tersumbat, apa yang akan terjadi?",
      options: [
        "Tidak terjadi apa-apa karena bronkus bisa menggantikan",
        "Udara tidak bisa mengalir ke paru-paru dan ini merupakan keadaan darurat",
        "Paru-paru akan berfungsi lebih keras",
        "Oksigen akan diproduksi oleh tubuh",
      ],
      correctAnswer: 1,
      explanation:
        "Penyumbatan trakea adalah keadaan darurat karena menghalangi aliran udara ke paru-paru. Ini bisa menyebabkan sesak napas berat dan kegagalan pernapasan jika tidak segera ditangani.",
    },
    {
      id: "trakea_26",
      question: "Mengapa trakea bisa sedikit membesar saat kita bernapas dalam-dalam?",
      options: [
        "Karena jumlah cincin tulang rawan bertambah",
        "Karena otot polos di dinding posterior berelaksasi",
        "Karena lendir di dalam trakea menguap",
        "Karena tekanan dari paru-paru mendorong dinding trakea",
      ],
      correctAnswer: 1,
      explanation:
        "Dinding posterior trakea yang terdiri dari otot polos dan jaringan ikat bersifat fleksibel. Saat otot polos berelaksasi, trakea bisa sedikit membesar untuk mengalirkan lebih banyak udara.",
    },
  ],

  // ==========================================
  // BRONKUS (Bronchi)
  // ==========================================
  bronkus: [
    // -- Fungsi --
    {
      id: "bronkus_1",
      question: "Apa fungsi utama bronkus?",
      options: [
        "Bertukar gas oksigen dan karbon dioksida",
        "Mengalirkan udara dari trakea ke paru-paru",
        "Menghasilkan suara",
        "Mencerna makanan",
      ],
      correctAnswer: 1,
      explanation:
        "Bronkus berfungsi mengalirkan udara dari trakea ke masing-masing paru-paru. Bronkus kanan menuju paru-paru kanan, bronkus kiri menuju paru-paru kiri.",
    },
    {
      id: "bronkus_2",
      question: "Apa yang terjadi pada bronkus setelah masuk ke paru-paru?",
      options: [
        "Bronkus berhenti bercabang",
        "Bronkus terus bercabang menjadi cabang-cabang yang semakin kecil (bronkiolus)",
        "Bronkus langsung menjadi alveolus",
        "Bronkus menyatu kembali menjadi satu",
      ],
      correctAnswer: 1,
      explanation:
        "Setelah masuk ke paru-paru, bronkus terus bercabang menjadi cabang-cabang yang semakin kecil, membentuk bronkiolus yang akhirnya mengarah ke alveolus.",
    },
    {
      id: "bronkus_3",
      question: "Apa fungsi lendir pada dinding bronkus?",
      options: [
        "Menghasilkan oksigen",
        "Menangkap debu dan partikel asing yang masuk",
        "Memperbesar saluran udara",
        "Membuat suara lebih jernih",
      ],
      correctAnswer: 1,
      explanation:
        "Lendir pada dinding bronkus berfungsi untuk menangkap debu, kuman, dan partikel asing yang masuk bersama udara, mencegahnya mencapai bagian dalam paru-paru.",
    },
    // -- Struktur --
    {
      id: "bronkus_4",
      question: "Berapa jumlah bronkus utama yang keluar dari trakea?",
      options: [
        "1 bronkus",
        "2 bronkus",
        "3 bronkus",
        "4 bronkus",
      ],
      correctAnswer: 1,
      explanation:
        "Trakea bercabang menjadi 2 bronkus utama di bagian bawah (karina): bronkus kanan yang menuju paru-paru kanan dan bronkus kiri yang menuju paru-paru kiri.",
    },
    {
      id: "bronkus_5",
      question: "Apa perbedaan antara bronkus kanan dan bronkus kiri?",
      options: [
        "Bronkus kanan lebih panjang dan sempit dari bronkus kiri",
        "Bronkus kanan lebih pendek, lebih lebar, dan lebih vertikal dari bronkus kiri",
        "Keduanya memiliki ukuran yang sama persis",
        "Bronkus kiri lebih besar dari bronkus kanan",
      ],
      correctAnswer: 1,
      explanation:
        "Bronkus kanan lebih pendek (sekitar 2,5 cm), lebih lebar, dan lebih vertikal dibanding bronkus kiri (sekitar 5 cm). Ini menyebabkan benda asing lebih sering masuk ke paru-paru kanan.",
    },
    {
      id: "bronkus_6",
      question: "Apa yang menyusun dinding bronkus?",
      options: [
        "Hanya tulang rawan saja",
        "Tulang rawan, otot polos, dan selaput lendir (mukosa)",
        "Hanya otot polos saja",
        "Tulang dan tulang rawan",
      ],
      correctAnswer: 1,
      explanation:
        "Dinding bronkus tersusun dari cincin tulang rawan, otot polos di antara cincin, dan selaput lendir (mukosa) di bagian dalam yang menghasilkan lendir.",
    },
    // -- Fakta Angka --
    {
      id: "bronkus_7",
      question: "Berapa panjang bronkus kanan secara umum?",
      options: [
        "Sekitar 1 cm",
        "Sekitar 2,5 cm",
        "Sekitar 5 cm",
        "Sekitar 10 cm",
      ],
      correctAnswer: 1,
      explanation:
        "Bronkus kanan memiliki panjang sekitar 2,5 cm, lebih pendek dari bronkus kiri yang panjangnya sekitar 5 cm.",
    },
    {
      id: "bronkus_8",
      question: "Berapa kali total percabangan dari bronkus utama hingga alveolus?",
      options: [
        "Sekitar 5 kali",
        "Sekaroundar 10 kali",
        "Sekitar 23 kali",
        "Sekitar 50 kali",
      ],
      correctAnswer: 2,
      explanation:
        "Dari bronkus utama, saluran udara bercabang sekitar 23 kali hingga mencapai alveolus. Percabangan ini membentuk struktur seperti pohon yang disebut pohon bronkial.",
    },
    {
      id: "bronkus_9",
      question: "Mengapa benda asing lebih sering masuk ke paru-paru kanan?",
      options: [
        "Karena paru-paru kanan lebih besar",
        "Karena bronkus kanan lebih pendek, lebih lebar, dan lebih vertikal",
        "Karena paru-paru kanan lebih dekat ke hidung",
        "Karena hanya bronkus kanan yang memiliki tulang rawan",
      ],
      correctAnswer: 1,
      explanation:
        "Bronkus kanan lebih pendek, lebih lebar, dan lebih lurus (vertikal) dibanding bronkus kiri, sehingga benda asing yang masuk ke saluran napas cenderung 'jatuh' ke paru-paru kanan.",
    },
    // -- Fakta Menarik --
    {
      id: "bronkus_10",
      question: "Apa nama struktur pohon percabangan yang dibentuk oleh bronkus di dalam paru-paru?",
      options: [
        "Pohon akar",
        "Pohon bronkial (bronchial tree)",
        "Pohon napas",
        "Pohon oksigen",
      ],
      correctAnswer: 1,
      explanation:
        "Percabangan bronkus di dalam paru-paru membentuk struktur yang disebut pohon bronkial (bronchial tree), mirip pohon yang batangnya terbalik dengan cabang-cabang yang semakin kecil.",
    },
    {
      id: "bronkus_11",
      question: "Apa yang dimaksud dengan karina pada percabangan bronkus?",
      options: [
        "Nama lain dari bronkus",
        "Tonjolan tulang rawan di titik percabangan trakea menjadi bronkus",
        "Selaput lendir di dalam bronkus",
        "Otot polos pada dinding bronkus",
      ],
      correctAnswer: 1,
      explanation:
        "Karina adalah tonjolan tulang rawan di titik percabangan trakea menjadi dua bronkus utama. Area ini sangat sensitif terhadap rangsang dan memicu refleks batuk.",
    },
    // -- Proses --
    {
      id: "bronkus_12",
      question: "Bagaimana udara mengalir dari trakea ke paru-paru?",
      options: [
        "Trakea → alveolus → bronkus → paru-paru",
        "Trakea → bronkus kiri dan kanan → bercabang menjadi bronkiolus → alveolus",
        "Trakea → bronkiolus → bronkus → alveolus",
        "Trakea → faring → bronkus → alveolus",
      ],
      correctAnswer: 1,
      explanation:
        "Udara dari trakea masuk ke bronkus utama kiri dan kanan, kemudian bercabang menjadi bronkus yang lebih kecil, lalu ke bronkiolus, dan akhirnya mencapai alveolus.",
    },
    {
      id: "bronkus_13",
      question: "Apa yang terjadi pada silia di dalam bronkus?",
      options: [
        "Silia berdiam saja",
        "Silia bergerak terkoordinasi untuk menggerakkan lendir ke atas",
        "Silia bergerak ke bawah untuk mendorong udara",
        "Silia menghasilkan oksigen",
      ],
      correctAnswer: 1,
      explanation:
        "Silia di dalam bronkus bergerak secara terkoordinasi ke arah atas (ke arah trakea) untuk mengangkut lendir beserta partikel yang terperangkap menuju tenggorokan.",
    },
    // -- Hubungan --
    {
      id: "bronkus_14",
      question: "Organ apa yang terhubung langsung ke bronkus di atasnya?",
      options: [
        "Laring",
        "Faring",
        "Trakea",
        "Hidung",
      ],
      correctAnswer: 2,
      explanation:
        "Bronkus terhubung langsung ke trakea di atasnya. Trakea bercabang menjadi dua bronkus utama di bagian bawahnya.",
    },
    {
      id: "bronkus_15",
      question: "Apa yang terletak di ujung percabangan bronkus?",
      options: [
        "Trakea",
        "Faring",
        "Bronkiolus yang kemudian mengarah ke alveolus",
        "Laring",
      ],
      correctAnswer: 2,
      explanation:
        "Di ujung percabangan bronkus terdapat bronkiolus (cabang yang lebih kecil tanpa tulang rawan), yang kemudian mengarah ke alveolus untuk pertukaran gas.",
    },
    // -- Penyakit --
    {
      id: "bronkus_16",
      question: "Apa yang dimaksud dengan bronkitis?",
      options: [
        "Radang pada pita suara",
        "Radang pada selaput lendir bronkus",
        "Radang pada paru-paru",
        "Radang pada trakea",
      ],
      correctAnswer: 1,
      explanation:
        "Bronkitis adalah peradangan pada selaput lendir yang melapisi bronkus, biasanya disebabkan oleh infeksi virus atau iritasi (seperti asap rokok), menyebabkan batuk dan sesak napas.",
    },
    {
      id: "bronkus_17",
      question: "Apa yang bisa terjadi pada bronkus akibat merokok dalam jangka panjang?",
      options: [
        "Bronkus menjadi lebih sehat",
        "Bronkus mengalami peradangan kronis dan produksi lendir berlebihan",
        "Bronkus bertambah panjang",
        "Tidak ada dampak pada bronkus",
      ],
      correctAnswer: 1,
      explanation:
        "Merokok dalam jangka panjang menyebabkan peradangan kronis pada bronkus (bronkitis kronis), produksi lendir berlebihan, dan kerusakan silia sehingga lendir sulit dikeluarkan.",
    },
    // -- Manakah yang BUKAN --
    {
      id: "bronkus_18",
      question: "Manakah yang BUKAN merupakan ciri-ciri bronkus utama?",
      options: [
        "Memiliki cincin tulang rawan pada dindingnya",
        "Dilapisi selaput lendir (mukosa)",
        "Tidak memiliki hubungan dengan trakea",
        "Bercabang menjadi bronkiolus",
      ],
      correctAnswer: 2,
      explanation:
        "Bronkus utama terhubung langsung dengan trakea (trakea bercabang menjadi bronkus). Pernyataan bahwa bronkus tidak memiliki hubungan dengan trakea adalah salah.",
    },
    {
      id: "bronkus_19",
      question: "Manakah yang BUKAN fungsi bronkus?",
      options: [
        "Mengalirkan udara dari trakea ke paru-paru",
        "Menyaring partikel asing dengan lendir",
        "Bertukar gas oksigen dan karbon dioksida",
        "Melanjutkan percabangan ke bronkiolus",
      ],
      correctAnswer: 2,
      explanation:
        "Pertukaran gas O₂ dan CO₂ terjadi di alveolus, bukan di bronkus. Bronkus berfungsi mengalirkan udara, menyaring partikel, dan bercabang ke bronkiolus.",
    },
    // -- Pernyataan Benar/Salah --
    {
      id: "bronkus_20",
      question: "Pernyataan mana yang BENAR tentang bronkus?",
      options: [
        "Bronkus kanan lebih panjang dari bronkus kiri",
        "Bronkus tidak memiliki tulang rawan pada dindingnya",
        "Bronkus memiliki cincin tulang rawan dan dilapisi mukosa yang menghasilkan lendir",
        "Bronkus hanya bercabang sekali lalu berakhir",
      ],
      correctAnswer: 2,
      explanation:
        "Bronkus memiliki cincin tulang rawan yang menjaga saluran tetap terbuka, dan dilapisi mukosa yang menghasilkan lendir untuk menangkap partikel asing.",
    },
    {
      id: "bronkus_21",
      question: "Pernyataan mana yang SALAH tentang bronkus?",
      options: [
        "Bronkus kanan lebih pendek dari bronkus kiri",
        "Bronkus memiliki silia yang membantu membersihkan saluran napas",
        "Bronkus tidak bercabang setelah masuk ke paru-paru",
        "Bronkus berasal dari percabangan trakea",
      ],
      correctAnswer: 2,
      explanation:
        "Pernyataan bahwa bronkus tidak bercabang setelah masuk ke paru-paru adalah SALAH. Bronkus terus bercabang menjadi cabang yang semakin kecil (bronkiolus) setelah masuk ke paru-paru.",
    },
    // -- Perbandingan --
    {
      id: "bronkus_22",
      question: "Apa perbedaan utama antara bronkus kanan dan bronkus kiri?",
      options: [
        "Bronkus kiri lebih pendek dan lebih lebar",
        "Bronkus kanan lebih pendek, lebih lebar, dan lebih vertikal",
        "Tidak ada perbedaan sama sekali",
        "Bronkus kanan tidak memiliki tulang rawan",
      ],
      correctAnswer: 1,
      explanation:
        "Bronkus kanan lebih pendek (2,5 cm vs 5 cm), lebih lebar, dan lebih vertikal dibanding bronkus kiri. Karena itu, benda asing lebih mudah masuk ke paru-paru kanan.",
    },
    {
      id: "bronkus_23",
      question: "Apa perbedaan antara bronkus dan bronkiolus?",
      options: [
        "Bronkus lebih kecil dari bronkiolus",
        "Bronkus memiliki tulang rawan, bronkiolus tidak memiliki tulang rawan",
        "Bronkiolus lebih besar dari bronkus",
        "Tidak ada perbedaan",
      ],
      correctAnswer: 1,
      explanation:
        "Bronkus memiliki cincin tulang rawan pada dindingnya yang menjaga saluran tetap terbuka, sedangkan bronkiolus tidak memiliki tulang rawan dan dindingnya hanya terdiri dari otot polos.",
    },
    {
      id: "bronkus_24",
      question: "Jika dibandingkan dengan trakea, bagaimana ukuran cabang bronkus?",
      options: [
        "Bronkus lebih besar dari trakea",
        "Bronkus semakin kecil seiring bercabang",
        "Bronkus memiliki ukuran yang sama dengan trakea",
        "Bronkus hanya satu cabang besar",
      ],
      correctAnswer: 1,
      explanation:
        "Bronkus semakin kecil seiring bercabang. Dari diameter trakea sekitar 2,5 cm, cabang bronkus semakin mengecil hingga menjadi bronkiolus dengan diameter kurang dari 1 mm.",
    },
    {
      id: "bronkus_25",
      question: "Apa yang terjadi pada jumlah tulang rawan seiring bronkus bercabang?",
      options: [
        "Jumlah tulang rawan semakin bertambah",
        "Jumlah tulang rawan tetap sama",
        "Tulang rawan semakin berkurang dan menghilang di bronkiolus",
        "Tulang rawan berubah menjadi tulang keras",
      ],
      correctAnswer: 2,
      explanation:
        "Seiring bronkus bercabang, tulang rawan semakin berkurang jumlahnya dan berubah bentuk dari cincin menjadi lempengan. Di bronkiolus, tulang rawan sudah tidak ada lagi.",
    },
    {
      id: "bronkus_26",
      question: "Mengapa pada pemeriksaan medis dokter sering memeriksa paru-paru kanan lebih teliti saat ada dugaan benda asing masuk saluran napas?",
      options: [
        "Karena paru-paru kanan lebih penting",
        "Karena paru-paru kiri tidak memiliki bronkus",
        "Karena bronkus kanan lebih pendek, lebar, dan vertikal sehingga benda asing lebih sering masuk ke sana",
        "Karena paru-paru kanan lebih besar",
      ],
      correctAnswer: 2,
      explanation:
        "Karena bronkus kanan yang lebih pendek, lebih lebar, dan lebih vertikal, benda asing yang masuk melalui trakea cenderung masuk ke bronkus kanan dan paru-paru kanan.",
    },
  ],

  // ==========================================
  // BRONKIOLUS (Bronchioles)
  // ==========================================
  bronkiolus: [
    // -- Fungsi --
    {
      id: "bronkiolus_1",
      question: "Apa fungsi utama bronkiolus?",
      options: [
        "Bertukar gas oksigen dan karbon dioksida",
        "Mengalirkan udara ke bagian terkecil paru-paru menuju alveolus",
        "Menghasilkan suara",
        "Menyaring makanan dari saluran napas",
      ],
      correctAnswer: 1,
      explanation:
        "Bronkiolus berfungsi mengalirkan udara dari bronkus ke kantong-kantong udara kecil (alveolus) di ujung saluran napas.",
    },
    {
      id: "bronkiolus_2",
      question: "Apa yang memungkinkan bronkiolus mengubah diameternya?",
      options: [
        "Tulang rawan yang bisa diregangkan",
        "Otot polos pada dinding bronkiolus yang bisa berkontraksi dan berelaksasi",
        "Lendir yang mengisi dinding bronkiolus",
        "Epiglotis yang menekan bronkiolus",
      ],
      correctAnswer: 1,
      explanation:
        "Dinding bronkiolus memiliki otot polos yang bisa berkontraksi (menyempitkan bronkiolus) dan berelaksasi (melebarkan bronkiolus) untuk mengatur aliran udara.",
    },
    {
      id: "bronkiolus_3",
      question: "Apa fungsi bronkiolus terminal?",
      options: [
        "Menghasilkan lendir",
        "Menjadi cabang terakhir sebelum bronkiolus respiratorius dan alveolus",
        "Menyaring udara dari bakteri",
        "Menghasilkan oksigen",
      ],
      correctAnswer: 1,
      explanation:
        "Bronkiolus terminal adalah cabang terakhir dari bronkiolus yang tidak berpartisipasi dalam pertukaran gas, sebelum bercabang lagi menjadi bronkiolus respiratorius yang mengarah ke alveolus.",
    },
    // -- Struktur --
    {
      id: "bronkiolus_4",
      question: "Apa perbedaan utama antara bronkiolus dan bronkus?",
      options: [
        "Bronkiolus lebih besar dari bronkus",
        "Bronkiolus tidak memiliki tulang rawan pada dindingnya",
        "Bronkiolus memiliki lebih banyak tulang rawan",
        "Bronkiolus berada di luar paru-paru",
      ],
      correctAnswer: 1,
      explanation:
        "Berbeda dengan bronkus yang memiliki cincin tulang rawan, bronkiolus tidak memiliki tulang rawan sama sekali. Dindingnya hanya terdiri dari otot polos dan jaringan elastis.",
    },
    {
      id: "bronkiolus_5",
      question: "Berapa diameter bronkiolus secara umum?",
      options: [
        "Sekitar 2-3 cm",
        "Sekitar 5-10 mm",
        "Kurang dari 1 mm (sekitar 0,5-1 mm)",
        "Sekitar 1-2 mm",
      ],
      correctAnswer: 2,
      explanation:
        "Bronkiolus memiliki diameter kurang dari 1 mm, sekitar 0,5-1 mm. Diameter ini semakin mengecil seiring percabangan menuju alveolus.",
    },
    {
      id: "bronkiolus_6",
      question: "Apa yang tersusun di dinding bronkiolus?",
      options: [
        "Tulang rawan dan otot polos",
        "Otot polos, jaringan elastis, dan epitelium",
        "Tulang dan tulang rawan",
        "Lendir dan tulang rawan",
      ],
      correctAnswer: 1,
      explanation:
        "Dinding bronkiolus tersusun dari otot polos (yang bisa berkontraksi dan berelaksasi), jaringan elastis, dan epitelium pipih. Tidak ada tulang rawan.",
    },
    // -- Fakta Angka --
    {
      id: "bronkiolus_7",
      question: "Jika semua bronkiolus direntangkan dan disambungkan, berapa panjangnya?",
      options: [
        "Sekitar 100 meter",
        "Sekitar 10 km",
        "Lebih dari 2.400 km",
        "Sekitar 500 km",
      ],
      correctAnswer: 2,
      explanation:
        "Jika semua bronkiolus direntangkan dan disambungkan, panjangnya bisa mencapai lebih dari 2.400 km! Ini menunjukkan betapa kompleksnya sistem pernapasan manusia.",
    },
    {
      id: "bronkiolus_8",
      question: "Berapa perubahan diameter bronkiolus dari cabang terbesar hingga terkecil?",
      options: [
        "Dari 10 mm ke 5 mm",
        "Dari sekitar 1 mm ke sekitar 0,5 mm atau kurang",
        "Dari 5 cm ke 1 cm",
        "Tetap sama",
      ],
      correctAnswer: 1,
      explanation:
        "Diameter bronkiolus berkurang dari sekitar 1 mm pada cabang terbesar menjadi sekitar 0,5 mm atau kurang pada cabang terkecil menuju alveolus.",
    },
    {
      id: "bronkiolus_9",
      question: "Berapa jumlah cabang bronkiolus yang dimiliki manusia secara keseluruhan?",
      options: [
        "Sekitar 100 cabang",
        "Sekitar 1.000 cabang",
        "Ratusan ribu hingga jutaan cabang",
        "Sekitar 50 cabang",
      ],
      correctAnswer: 2,
      explanation:
        "Sistem bronkiolus memiliki ratusan ribu hingga jutaan cabang yang bercabang dari bronkus utama. Jumlah yang sangat banyak ini memastikan udara terdistribusi ke seluruh alveolus.",
    },
    // -- Fakta Menarik --
    {
      id: "bronkiolus_10",
      question: "Mengapa asma menyebabkan sesak napas?",
      options: [
        "Karena alveolus membeku",
        "Karena otot polos bronkiolus berkontraksi sehingga menyempit",
        "Karena trakea tersumbat",
        "Karena pita suara membengkak",
      ],
      correctAnswer: 1,
      explanation:
        "Pada serangan asma, otot polos pada dinding bronkiolus berkontraksi secara berlebihan, menyebabkan bronkiolus menyempit. Selain itu, dinding bronkiolus juga membengkak dan menghasilkan lendir berlebihan.",
    },
    {
      id: "bronkiolus_11",
      question: "Apa nama penyakit peradangan bronkiolus yang sering menyerang anak-anak?",
      options: [
        "Bronkitis",
        "Bronkiolitis",
        "Trakeitis",
        "Faringitis",
      ],
      correctAnswer: 1,
      explanation:
        "Bronkiolitis adalah peradangan pada bronkiolus yang sering disebabkan oleh virus RSV (Respiratory Syncytial Virus) dan umumnya menyerang anak-anak di bawah 2 tahun.",
    },
    {
      id: "bronkiolus_12",
      question: "Apa keuntungan bronkiolus tidak memiliki tulang rawan?",
      options: [
        "Tidak ada keuntungannya",
        "Bronkiolus bisa lebih fleksibel dan berubah ukuran sesuai kebutuhan",
        "Bronkiolus menjadi lebih kuat",
        "Bronkiolus bisa menghasilkan lebih banyak lendir",
      ],
      correctAnswer: 1,
      explanation:
        "Ketiadaan tulang rawan memungkinkan bronkiolus untuk berubah ukuran (menyempit dan melebar) sesuai kebutuhan tubuh, seperti saat berolahraga atau saat ada iritan.",
    },
    // -- Proses --
    {
      id: "bronkiolus_13",
      question: "Bagaimana bronkiolus mengatur jumlah udara yang masuk ke alveolus?",
      options: [
        "Dengan menghasilkan lebih banyak tulang rawan",
        "Dengan berkontraksi dan berelaksasi otot polos pada dindingnya",
        "Dengan mengubah suhu udara",
        "Dengan menambah jumlah lendir",
      ],
      correctAnswer: 1,
      explanation:
        "Otot polos pada dinding bronkiolus bisa berkontraksi (menyempitkan saluran) atau berelaksasi (melebarkan saluran) untuk mengatur jumlah udara yang masuk ke alveolus.",
    },
    {
      id: "bronkiolus_14",
      question: "Apa yang terjadi pada bronkiolus saat tubuh membutuhkan lebih banyak oksigen?",
      options: [
        "Bronkiolus menyempit",
        "Bronkiolus melebar untuk mengalirkan lebih banyak udara",
        "Bronkiolus berhenti berfungsi",
        "Bronkiolus menghasilkan lendir lebih banyak",
      ],
      correctAnswer: 1,
      explanation:
        "Saat tubuh membutuhkan lebih banyak oksigen (seperti saat berolahraga), otot polos bronkiolus berelaksasi sehingga bronkiolus melebar dan lebih banyak udara bisa mengalir ke alveolus.",
    },
    // -- Hubungan --
    {
      id: "bronkiolus_15",
      question: "Apa yang terletak di ujung bronkiolus?",
      options: [
        "Trakea",
        "Bronkus",
        "Kantong udara kecil yang disebut alveolus",
        "Faring",
      ],
      correctAnswer: 2,
      explanation:
        "Di ujung bronkiolus terdapat kumpulan kantong udara kecil yang disebut alveolus. Di sinilah pertukaran gas oksigen dan karbon dioksida terjadi.",
    },
    {
      id: "bronkiolus_16",
      question: "Apa yang terletak di awal bronkiolus?",
      options: [
        "Alveolus",
        "Bronkus (cabang dari trakea)",
        "Trakea",
        "Laring",
      ],
      correctAnswer: 1,
      explanation:
        "Bronkiolus berasal dari cabang bronkus. Setelah bronkus masuk ke paru-paru dan bercabang, cabang yang sudah tidak memiliki tulang rawan disebut bronkiolus.",
    },
    // -- Penyakit --
    {
      id: "bronkiolus_17",
      question: "Apa gejala utama dari bronkiolitis pada anak-anak?",
      options: [
        "Demam tinggi dan ruam kulit",
        "Batuk, sesak napas, dan napas cepat",
        "Sakit perut dan muntah",
        "Sakit kepala dan pusing",
      ],
      correctAnswer: 1,
      explanation:
        "Bronkiolitis menyebabkan gejala batuk, sesak napas, napas yang cepat dan dangkal, mengi (suara bersiul saat bernapas), dan kadang sulit makan pada bayi.",
    },
    {
      id: "bronkiolus_18",
      question: "Pada penyakit COPD (Penyakit Paru Obstruktif Kronik), apa yang terjadi pada bronkiolus?",
      options: [
        "Bronkiolus menjadi lebih besar",
        "Bronkiolus menyempit secara permanen sehingga sulit mengeluarkan napas",
        "Bronkiolus menghilang",
        "Tidak ada perubahan pada bronkiolus",
      ],
      correctAnswer: 1,
      explanation:
        "Pada COPD, bronkiolus menjadi meradang dan menyempit secara permanen, menyebabkan penghalang aliran udara (obstruksi) dan kesulitan mengeluarkan napas.",
    },
    // -- Manakah yang BUKAN --
    {
      id: "bronkiolus_19",
      question: "Manakah yang BUKAN merupakan ciri-ciri bronkiolus?",
      options: [
        "Dinding terdiri dari otot polos",
        "Diameter kurang dari 1 mm",
        "Memiliki cincin tulang rawan",
        "Tidak memiliki silia di bagian terkecil",
      ],
      correctAnswer: 2,
      explanation:
        "Bronkiolus TIDAK memiliki tulang rawan. Tulang rawan ada pada bronkus tetapi menghilang pada cabang yang sudah menjadi bronkiolus.",
    },
    {
      id: "bronkiolus_20",
      question: "Manakah yang BUKAN fungsi bronkiolus?",
      options: [
        "Mengalirkan udara ke alveolus",
        "Mengatur diameter saluran udara",
        "Bertukar gas oksigen dan karbon dioksida secara langsung",
        "Bercabang menjadi saluran yang lebih kecil",
      ],
      correctAnswer: 2,
      explanation:
        "Pertukaran gas O₂ dan CO₂ terjadi di alveolus, bukan langsung di bronkiolus. Bronkiolus hanya mengalirkan udara ke alveolus.",
    },
    // -- Pernyataan Benar/Salah --
    {
      id: "bronkiolus_21",
      question: "Pernyataan mana yang BENAR tentang bronkiolus?",
      options: [
        "Bronkiolus memiliki tulang rawan yang kuat",
        "Bronkiolus bisa berubah diameter karena memiliki otot polos",
        "Bronkiolus berfungsi untuk bertukar gas",
        "Bronkiolus hanya ada satu di setiap paru-paru",
      ],
      correctAnswer: 1,
      explanation:
        "Bronkiolus bisa berubah diameter (menyempit dan melebar) karena dindingnya memiliki otot polos yang bisa berkontraksi dan berelaksasi.",
    },
    {
      id: "bronkiolus_22",
      question: "Pernyataan mana yang SALAH tentang bronkiolus?",
      options: [
        "Bronkiolus tidak memiliki tulang rawan",
        "Bronkiolus memiliki diameter kurang dari 1 mm",
        "Bronkiolus berfungsi sebagai tempat utama pertukaran gas",
        "Bronkiolus bercabang dari bronkus",
      ],
      correctAnswer: 2,
      explanation:
        "Bronkiolus bukan tempat utama pertukaran gas. Pertukaran gas terjadi di alveolus yang terletak di ujung bronkiolus. Bronkiolus hanya berfungsi sebagai saluran penghubung.",
    },
    // -- Perbandingan --
    {
      id: "bronkiolus_23",
      question: "Apa perbedaan utama antara bronkiolus dan bronkus?",
      options: [
        "Bronkiolus lebih besar dari bronkus",
        "Bronkus memiliki tulang rawan, bronkiolus tidak",
        "Bronkus tidak memiliki silia, bronkiolus memiliki silia",
        "Keduanya sama saja",
      ],
      correctAnswer: 1,
      explanation:
        "Perbedaan utama adalah bronkus memiliki cincin tulang rawan pada dindingnya, sedangkan bronkiolus tidak memiliki tulang rawan. Hal ini memungkinkan bronkiolus lebih fleksibel.",
    },
    {
      id: "bronkiolus_24",
      question: "Apa perbedaan antara bronkiolus terminal dan bronkiolus respiratorius?",
      options: [
        "Bronkiolus terminal lebih besar",
        "Bronkiolus respiratorius sudah mulai memiliki alveolus di dindingnya",
        "Keduanya sama saja",
        "Bronkiolus terminal sudah bertukar gas",
      ],
      correctAnswer: 1,
      explanation:
        "Bronkiolus respiratorius sudah mulai memiliki beberapa alveolus di dindingnya dan mulai berpartisipasi dalam pertukaran gas, sedangkan bronkiolus terminal belum.",
    },
    {
      id: "bronkiolus_25",
      question: "Jika dibandingkan dengan trakea, bagaimana struktur bronkiolus?",
      options: [
        "Bronkiolus lebih besar dan memiliki lebih banyak tulang rawan",
        "Bronkiolus jauh lebih kecil, tidak memiliki tulang rawan, dan jauh lebih banyak jumlahnya",
        "Bronkiolus identik dengan trakea",
        "Bronkiolus hanya ada dua seperti trakea bercabang dua",
      ],
      correctAnswer: 1,
      explanation:
        "Berbeda dari trakea yang besar dan memiliki tulang rawan, bronkiolus sangat kecil (kurang dari 1 mm), tidak memiliki tulang rawan, dan jumlahnya ratusan ribu hingga jutaan.",
    },
    {
      id: "bronkiolus_26",
      question: "Mengapa obat asma (inhaler) bisa membantu penderita asma bernapas?",
      options: [
        "Karena inhaler menghasilkan oksigen",
        "Karena obat dalam inhaler merelaksasi otot polos bronkiolus sehingga saluran melebar",
        "Karena inhaler membersihkan lendir dari paru-paru",
        "Karena inhaler menghancurkan tulang rawan",
      ],
      correctAnswer: 1,
      explanation:
        "Obat asma (seperti bronkodilator) bekerja dengan merelaksasi otot polos pada dinding bronkiolus, sehingga bronkiolus melebar dan udara bisa mengalir dengan lebih mudah.",
    },
    {
      id: "bronkiolus_27",
      question: "Apakah bagian terkecil bronkiolus masih memiliki silia?",
      options: [
        "Ya, semua bronkiolus memiliki silia",
        "Tidak, bagian terkecil bronkiolus sudah tidak memiliki silia",
        "Silia muncul hanya saat sakit",
        "Hanya bronkus yang memiliki silia",
      ],
      correctAnswer: 1,
      explanation:
        "Bronkiolus yang lebih besar masih memiliki silia, tetapi pada bagian terkecil (mendekati alveolus), silia sudah tidak ada lagi. Pembersihan di bagian ini dilakukan oleh makrofag alveolar.",
    },
  ],

  // ==========================================
  // ALVEOLUS (Alveoli)
  // ==========================================
  alveolus: [
    // -- Fungsi --
    {
      id: "alveolus_1",
      question: "Apa fungsi utama alveolus?",
      options: [
        "Menyaring udara dari debu",
        "Tempat pertukaran oksigen (O₂) dan karbon dioksida (CO₂)",
        "Menghasilkan suara",
        "Mencerna makanan",
      ],
      correctAnswer: 1,
      explanation:
        "Alveolus adalah kantong udara kecil di ujung bronkiolus yang merupakan tempat terjadinya pertukaran gas: O₂ masuk dari udara ke darah, dan CO₂ keluar dari darah ke udara.",
    },
    {
      id: "alveolus_2",
      question: "Bagaimana oksigen berpindah dari alveolus ke dalam darah?",
      options: [
        "Oksigen dipompa oleh jantung ke alveolus",
        "Oksigen menyebar melalui difusi sederhana melewati dinding alveolus yang tipis",
        "Oksigen dikeluarkan oleh sel darah merah",
        "Oksigen masuk melalui saluran pencernaan",
      ],
      correctAnswer: 1,
      explanation:
        "Oksigen berpindah dari alveolus ke dalam kapiler darah melalui proses difusi sederhana, yaitu berpindah dari area konsentrasi tinggi (alveolus) ke area konsentrasi rendah (darah).",
    },
    {
      id: "alveolus_3",
      question: "Apa fungsi surfaktan pada alveolus?",
      options: [
        "Menghasilkan oksigen",
        "Mencegah alveolus kolaps (mengecil) saat menghembuskan napas",
        "Menyaring debu dari udara",
        "Menghasilkan karbon dioksida",
      ],
      correctAnswer: 1,
      explanation:
        "Surfaktan adalah zat berlemak yang melapisi permukaan dalam alveolus. Surfaktan mengurangi tegangan permukaan dan mencegah alveolus kolaps saat kita menghembuskan napas.",
    },
    // -- Struktur --
    {
      id: "alveolus_4",
      question: "Berapa ketebalan dinding alveolus?",
      options: [
        "Sekitar 1 cm",
        "Sekitar 1 mm",
        "Sangat tipis, hanya setebal 1 sel (satu lapisan sel)",
        "Sekitar 0,5 cm",
      ],
      correctAnswer: 2,
      explanation:
        "Dinding alveolus sangat tipis, hanya terdiri dari satu lapisan sel epitelium pipih. Ketebalan ini memungkinkan pertukaran gas berlangsung dengan cepat dan efisien.",
    },
    {
      id: "alveolus_5",
      question: "Apa yang membungkus setiap alveolus?",
      options: [
        "Tulang rawan",
        "Otot polos",
        "Jaringan kapiler darah yang sangat halus",
        "Lendir tebal",
      ],
      correctAnswer: 2,
      explanation:
        "Setiap alveolus dibungkus oleh jaringan pembuluh darah kapiler yang sangat halus. Kapiler ini memiliki dinding yang juga sangat tipis, memudahkan pertukaran gas.",
    },
    {
      id: "alveolus_6",
      question: "Berapa diameter satu alveolus secara umum?",
      options: [
        "Sekitar 5 cm",
        "Sekitar 1 mm",
        "Sekitar 0,2 mm",
        "Sekitar 0,01 mm",
      ],
      correctAnswer: 2,
      explanation:
        "Setiap alveolus memiliki diameter sangat kecil, sekitar 0,2 mm (200 mikrometer). Meskipun sangat kecil, jumlahnya yang ratusan juta membuat total luas permukaannya sangat besar.",
    },
    // -- Fakta Angka --
    {
      id: "alveolus_7",
      question: "Berapa jumlah alveolus yang dimiliki manusia?",
      options: [
        "Sekitar 100 ribu",
        "Sekitar 1 juta",
        "Sekitar 300-500 juta",
        "Sekitar 1 miliar",
      ],
      correctAnswer: 2,
      explanation:
        "Manusia memiliki sekitar 300-500 juta alveolus di kedua paru-paru. Jumlah yang sangat besar ini memastikan pertukaran gas berlangsung efisien.",
    },
    {
      id: "alveolus_8",
      question: "Berapa luas permukaan total seluruh alveolus jika direntangkan?",
      options: [
        "Sekitar 1 m²",
        "Sekitar 10 m²",
        "Sekitar 70 m² (setengah lapangan bulu tangkis)",
        "Sekitar 500 m²",
      ],
      correctAnswer: 2,
      explanation:
        "Jika seluruh alveolus direntangkan, total luas permukaannya mencapai sekitar 70 m², setara dengan luas setengah lapangan bulu tangkis. Luas yang besar ini memaksimalkan pertukaran gas.",
    },
    {
      id: "alveolus_9",
      question: "Berapa banyak oksigen yang bisa ditransfer oleh alveolus setiap menit saat istirahat?",
      options: [
        "Sekitar 10 ml",
        "Sekitar 100 ml",
        "Sekitar 250 ml",
        "Sekitar 1 liter",
      ],
      correctAnswer: 2,
      explanation:
        "Pada kondisi istirahat, alveolus mentransfer sekitar 250 ml oksigen dari udara ke darah setiap menit. Saat berolahraga, jumlah ini bisa meningkat drastis.",
    },
    // -- Fakta Menarik --
    {
      id: "alveolus_10",
      question: "Mengapa alveolus berbentuk seperti anggur (kumpulan kantong kecil)?",
      options: [
        "Untuk menghemat ruang",
        "Untuk memaksimalkan luas permukaan pertukaran gas",
        "Karena bentuknya tidak memiliki pengaruh",
        "Untuk memperkuat paru-paru",
      ],
      correctAnswer: 1,
      explanation:
        "Bentuk alveolus yang seperti kumpulan anggur (grape-like clusters) memaksimalkan luas permukaan untuk pertukaran gas. Semakin besar luas permukaan, semakin efisien pertukaran gas.",
    },
    {
      id: "alveolus_11",
      question: "Apa yang dimaksud dengan difusi pada proses pertukaran gas di alveolus?",
      options: [
        "Pompa yang mendorong gas",
        "Perpindahan molekul gas dari area konsentrasi tinggi ke konsentrasi rendah",
        "Reaksi kimia yang menghasilkan gas baru",
        "Proses penguapan gas",
      ],
      correctAnswer: 1,
      explanation:
        "Difusi adalah perpindahan molekul dari area konsentrasi tinggi ke konsentrasi rendah. Oksigen berdifusi dari alveolus (konsentrasi tinggi) ke darah (konsentrasi rendah), dan CO₂ berdifusi sebaliknya.",
    },
    {
      id: "alveolus_12",
      question: "Apa nama sel khusus yang membersihkan alveolus dari partikel asing?",
      options: [
        "Sel darah merah",
        "Makrofag alveolar",
        "Selia",
        "Trombosit",
      ],
      correctAnswer: 1,
      explanation:
        "Makrofag alveolar (sel debu) adalah sel kekebalan khusus di alveolus yang menelan dan mencerna partikel asing seperti debu dan bakteri yang masuk ke alveolus.",
    },
    // -- Proses --
    {
      id: "alveolus_13",
      question: "Apa yang terjadi pada oksigen setelah masuk ke dalam kapiler darah di alveolus?",
      options: [
        "Oksigen langsung dikeluarkan kembali",
        "Oksigen diikat oleh hemoglobin dalam sel darah merah dan diedarkan ke seluruh tubuh",
        "Oksigen berubah menjadi karbon dioksida",
        "Oksigen disimpan di paru-paru",
      ],
      correctAnswer: 1,
      explanation:
        "Setelah masuk ke kapiler darah, oksigen diikat oleh hemoglobin dalam sel darah merah (eritrosit) dan diedarkan oleh jantung ke seluruh tubuh untuk proses metabolisme sel.",
    },
    {
      id: "alveolus_14",
      question: "Dari mana karbon dioksida (CO₂) yang dikeluarkan melalui alveolus berasal?",
      options: [
        "Dari udara yang kita hirup",
        "Dari hasil metabolisme sel-sel tubuh yang dibawa oleh darah",
        "Dari makanan yang kita makan",
        "Dari air yang kita minum",
      ],
      correctAnswer: 1,
      explanation:
        "CO₂ dihasilkan oleh sel-sel tubuh sebagai hasil metabolisme (pembakaran makanan untuk energi). CO² dibawa oleh darah ke paru-paru, lalu berdifusi ke alveolus untuk dikeluarkan saat kita menghembuskan napas.",
    },
    {
      id: "alveolus_15",
      question: "Mengapa alveolus dikelilingi oleh banyak kapiler darah?",
      options: [
        "Untuk menjaga alveolus tetap dingin",
        "Untuk memaksimalkan area pertukaran gas antara udara dan darah",
        "Untuk mencegah alveolus kolaps",
        "Untuk menyaring lendir",
      ],
      correctAnswer: 1,
      explanation:
        "Kapiler darah yang banyak mengelilingi alveolus memperbesar area kontak antara udara di alveolus dan darah di kapiler, sehingga pertukaran gas berlangsung lebih efisien.",
    },
    // -- Hubungan --
    {
      id: "alveolus_16",
      question: "Organ apa yang terletak tepat sebelum alveolus?",
      options: [
        "Bronkus",
        "Bronkiolus (cabang terkecil)",
        "Trakea",
        "Faring",
      ],
      correctAnswer: 1,
      explanation:
        "Bronkiolus adalah saluran udara terkecil yang mengarah ke alveolus. Di ujung bronkiolus terdapat kumpulan alveolus seperti buah anggur.",
    },
    {
      id: "alveolus_17",
      question: "Apa hubungan antara alveolus dan sistem peredaran darah?",
      options: [
        "Tidak ada hubungan",
        "Kapiler darah mengelilingi alveolus untuk bertukar O₂ dan CO₂",
        "Alveolus memompa darah ke jantung",
        "Darah mengisi alveolus seperti balon",
      ],
      correctAnswer: 1,
      explanation:
        "Alveolus dan sistem peredaran darah memiliki hubungan erat. Kapiler darah yang mengelilingi alveolus menerima O₂ dari alveolus dan melepas CO₂ ke alveolus.",
    },
    // -- Penyakit --
    {
      id: "alveolus_18",
      question: "Apa yang dimaksud dengan emfisema?",
      options: [
        "Radang pada trakea",
        "Kerusakan dinding alveolus sehingga alveolus membesar dan berkurang jumlahnya",
        "Radang pada pita suara",
        "Penyumbatan bronkus",
      ],
      correctAnswer: 1,
      explanation:
        "Emfisema adalah kondisi di mana dinding antar-alveolus rusak dan pecah, menyebabkan alveolus membesar dan berkurang jumlahnya. Ini mengurangi luas permukaan pertukaran gas. Penyebab utamanya adalah merokok.",
    },
    {
      id: "alveolus_19",
      question: "Apa yang terjadi pada alveolus penderita pneumonia?",
      options: [
        "Alveolus membesar",
        "Alveolus terisi cairan atau nanah yang menghalangi pertukaran gas",
        "Alveolus bertambah jumlahnya",
        "Alveolus berfungsi normal",
      ],
      correctAnswer: 1,
      explanation:
        "Pada pneumonia, alveolus terisi oleh cairan atau nanah akibat infeksi (bakteri atau virus). Ini menghalangi pertukaran gas sehingga penderita merasa sesak napas.",
    },
    // -- Manakah yang BUKAN --
    {
      id: "alveolus_20",
      question: "Manakah yang BUKAN terdapat di dalam alveolus?",
      options: [
        "Udara yang mengandung oksigen",
        "Kapiler darah",
        "Tulang rawan",
        "Surfaktan",
      ],
      correctAnswer: 2,
      explanation:
        "Alveolus tidak memiliki tulang rawan. Tulang rawan terdapat pada trakea dan bronkus. Alveolus tersusun dari sel epitelium tipis, kapiler darah, dan surfaktan.",
    },
    {
      id: "alveolus_21",
      question: "Manakah yang BUKAN merupakan proses yang terjadi di alveolus?",
      options: [
        "Oksigen berdifusi dari alveolus ke darah",
        "Karbon dioksida berdifusi dari darah ke alveolus",
        "Makanan dicerna menjadi nutrisi",
        "Hemoglobin mengikat oksigen",
      ],
      correctAnswer: 2,
      explanation:
        "Pencernaan makanan bukan proses yang terjadi di alveolus, melainkan di sistem pencernaan (lambung dan usus). Di alveolus hanya terjadi pertukaran gas.",
    },
    // -- Pernyataan Benar/Salah --
    {
      id: "alveolus_22",
      question: "Pernyataan mana yang BENAR tentang alveolus?",
      options: [
        "Alveolus berdinding tebal untuk melindungi paru-paru",
        "Alveolus berdiameter sangat besar, sekitar 5 cm",
        "Dinding alveolus sangat tipis (1 sel) untuk memudahkan pertukaran gas",
        "Alveolus berjumlah sekitar 100 ribu di setiap paru-paru",
      ],
      correctAnswer: 2,
      explanation:
        "Dinding alveolus sangat tipis, hanya setebal satu sel, sehingga gas (O₂ dan CO₂) bisa berdifusi dengan mudah dan cepat antara udara di alveolus dan darah di kapiler.",
    },
    {
      id: "alveolus_23",
      question: "Pernyataan mana yang SALAH tentang alveolus?",
      options: [
        "Alveolus dikelilingi oleh kapiler darah",
        "Alveolus menghasilkan surfaktan untuk mencegah kolaps",
        "Pertukaran gas di alveolus terjadi melalui difusi",
        "Alveolus berfungsi menyaring debu dari udara yang masuk",
      ],
      correctAnswer: 3,
      explanation:
        "Penyaringan debu bukan fungsi alveolus. Penyaringan dilakukan oleh silia dan lendir di hidung, trakea, dan bronkus. Alveolus berfungsi untuk pertukaran gas.",
    },
    // -- Perbandingan --
    {
      id: "alveolus_24",
      question: "Apa perbedaan antara alveolus dan bronkiolus?",
      options: [
        "Alveolus lebih besar dari bronkiolus",
        "Bronkiolus adalah saluran udara, alveolus adalah kantong udara tempat pertukaran gas",
        "Tidak ada perbedaan",
        "Bronkiolus bertukar gas, alveolus hanya saluran udara",
      ],
      correctAnswer: 1,
      explanation:
        "Bronkiolus adalah saluran penghubung yang mengalirkan udara, sedangkan alveolus adalah kantong udara di ujung bronkiolus tempat pertukaran gas O₂ dan CO₂ terjadi.",
    },
    {
      id: "alveolus_25",
      question: "Jika dibandingkan dengan trakea, apa perbedaan utama alveolus?",
      options: [
        "Alveolus lebih besar dan memiliki tulang rawan",
        "Trakea adalah saluran penghubung, alveolus adalah tempat pertukaran gas",
        "Keduanya memiliki fungsi yang sama",
        "Trakea bertukar gas, alveolus mengalirkan udara",
      ],
      correctAnswer: 1,
      explanation:
        "Trakea hanya berfungsi sebagai saluran udara dari laring ke bronkus, sedangkan alveolus adalah tempat utama pertukaran gas O₂ dan CO₂ antara udara dan darah.",
    },
    {
      id: "alveolus_26",
      question: "Mengapa bayi prematur sering mengalami kesulitan bernapas (RDS)?",
      options: [
        "Karena paru-paru bayi terlalu kecil",
        "Karena surfaktan belum diproduksi cukup sehingga alveolus mudah kolaps",
        "Karena bayi prematur tidak memiliki alveolus",
        "Karena bronkus bayi tersumbat",
      ],
      correctAnswer: 1,
      explanation:
        "Surfaktan mulai diproduksi secara memadai pada minggu ke-34 kehamilan. Bayi prematur belum memiliki cukup surfaktan, sehingga alveolus mudah kolaps dan menyebabkan Respiratory Distress Syndrome (RDS).",
    },
    {
      id: "alveolus_27",
      question: "Apa yang terjadi pada tekanan udara di dalam alveolus saat kita menarik napas?",
      options: [
        "Tekanan di alveolus meningkat",
        "Tekanan di alveolus menurun sehingga udara dari luar masuk",
        "Tekanan tetap sama",
        "Udara keluar dari alveolus",
      ],
      correctAnswer: 1,
      explanation:
        "Saat menarik napas, otot diafragma berkontraksi dan rongga dada membesar. Ini menyebabkan tekanan di dalam alveolus menurun, sehingga udara dari luar mengalir masuk ke alveolus.",
    },
    {
      id: "alveolus_28",
      question: "Gas apa yang memiliki konsentrasi tertinggi di udara yang kita hembuskan dibandingkan udara yang kita hirup?",
      options: [
        "Oksigen (O₂)",
        "Nitrogen (N₂)",
        "Karbon dioksida (CO₂)",
        "Hidrogen (H₂)",
      ],
      correctAnswer: 2,
      explanation:
        "Konsentrasi CO₂ lebih tinggi di udara yang kita hembuskan (sekitar 4%) dibandingkan udara yang kita hirup (sekitar 0,04%). CO₂ ini merupakan hasil sisa metabolisme tubuh.",
    },
  ],
};

// ==========================================
// UTILITY FUNCTIONS
// ==========================================

/**
 * Fisher-Yates shuffle algorithm - shuffles an array in place.
 */
function shuffleArray<T>(array: T[]): T[] {
  const shuffled = [...array];
  for (let i = shuffled.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [shuffled[i], shuffled[j]] = [shuffled[j], shuffled[i]];
  }
  return shuffled;
}

/**
 * Shuffles the options of a question and updates the correctAnswer index accordingly.
 * Returns a NEW Question object - does not modify the original.
 */
export function shuffleOptions(question: Question): Question {
  // Create indexed array to track which option was correct
  const indexed = question.options.map((option, index) => ({
    option,
    wasCorrect: index === question.correctAnswer,
  }));

  // Shuffle the indexed array
  const shuffled = shuffleArray(indexed);

  // Find new position of correct answer
  const newCorrectAnswer = shuffled.findIndex((item) => item.wasCorrect);

  return {
    ...question,
    options: shuffled.map((item) => item.option),
    correctAnswer: newCorrectAnswer,
  };
}

/**
 * Returns a random question for the given organ that isn't in the excludeIds list.
 * If all questions are exhausted, resets and picks from the full bank.
 * Always shuffles options before returning.
 */
export function getRandomQuestion(organId: string, excludeIds: string[]): Question {
  const organQuestions = BANK[organId];

  if (!organQuestions || organQuestions.length === 0) {
    throw new Error(`No questions found for organ: ${organId}`);
  }

  // Filter out already used questions
  const available = organQuestions.filter((q) => !excludeIds.includes(q.id));

  // If all questions exhausted, reset (use full bank)
  const pool = available.length > 0 ? available : organQuestions;

  // Pick a random question from the pool
  const randomIndex = Math.floor(Math.random() * pool.length);
  const selectedQuestion = pool[randomIndex];

  // Shuffle options before returning
  return shuffleOptions(selectedQuestion);
}

// ==========================================
// HELPER: Get total question count per organ
// ==========================================
export function getQuestionCount(organId: string): number {
  return BANK[organId]?.length ?? 0;
}

export function getTotalQuestionCount(): number {
  return Object.values(BANK).reduce((sum, questions) => sum + questions.length, 0);
}

export function getAvailableOrgans(): string[] {
  return Object.keys(BANK);
}
